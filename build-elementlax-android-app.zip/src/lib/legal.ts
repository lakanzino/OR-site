export const APP_NAME = "Element.Lax";
export const APP_VERSION = "1.0.0";
export const DEVELOPER = "محمدرضا لک (mohamadreza.lak)";
export const PURPOSE = "این اپلیکیشن جهت آموزش به نوجوانان و جوانان ایران عزیز ساخته شده است.";
export const DISCLAIMER = "اطلاعات علمی با دقت از منابع معتبر تهیه شده اما مسئولیت استفاده نهایی با کاربر است.";
export const COPYRIGHT = "Copyright (c) 2025 mohamadreza.lak";

export const MIT_TEXT = `MIT License

Copyright (c) 2025 mohamadreza.lak

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.`;
