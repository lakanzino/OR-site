import { useCallback, useEffect, useState } from "react";
import { BottomNav } from "./components/BottomNav";
import { ToastHost } from "./components/Toast";
import { useRoute } from "./lib/router";
import { useStore } from "./lib/store";
import { About } from "./screens/About";
import { ElementScreen } from "./screens/ElementScreen";
import { LockScreen, Onboarding, Splash } from "./screens/Gates";
import { Home } from "./screens/Home";
import { Library } from "./screens/Library";
import { Settings } from "./screens/Settings";
import { Study } from "./screens/Study";

export default function App() {
  const route = useRoute();
  const { onboarded, pin } = useStore();
  const [splash, setSplash] = useState(true);
  const [unlocked, setUnlocked] = useState(false);
  const endSplash = useCallback(() => setSplash(false), []);
  const unlock = useCallback(() => setUnlocked(true), []);

  useEffect(() => {
    document.title = "Element.Lax | جدول تناوبی";
    if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
      navigator.serviceWorker.register("./sw.js").catch(() => undefined);
    }
  }, []);

  const [screen, arg] = route;
  const tab = screen === undefined || screen === "" ? "" : screen;
  const showNav = ["", "study", "library", "settings"].includes(tab);

  if (splash) return <Splash onDone={endSplash} />;
  if (pin && !unlocked) return <LockScreen pin={pin} onUnlock={unlock} />;
  if (!onboarded) return <Onboarding />;

  return (
    <div className="h-dvh w-full flex flex-col overflow-hidden bg-bg text-fg">
      <main className="flex-1 min-h-0 relative">
        {/* Home stays mounted so scroll position, search and filters are preserved */}
        <div className={"absolute inset-0 " + (tab === "" ? "" : "hidden")}>
          <Home />
        </div>
        {tab === "e" && <div className="absolute inset-0 z-10 bg-bg"><ElementScreen z={Number(arg)} /></div>}
        {tab === "study" && <div className="absolute inset-0"><Study /></div>}
        {tab === "library" && <div className="absolute inset-0"><Library /></div>}
        {tab === "settings" && <div className="absolute inset-0"><Settings /></div>}
        {tab === "about" && <div className="absolute inset-0 z-10 bg-bg"><About /></div>}
      </main>
      {showNav && <BottomNav active={tab} />}
      <ToastHost />
    </div>
  );
}
