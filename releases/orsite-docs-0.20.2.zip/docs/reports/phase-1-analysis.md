# گزارش فاز اجرایی ۱ — آنالیز کامل قالب والد

- **ورودی:** `patient-or-7.zip` (از Google Drive، 236,228 بایت)
- **محتوای واقعی ZIP:** پوشه `sarzaminaryan/` — قالب **کلاسیک** وردپرس «Sarzamin Aryan» نسخه 1.1.0
- **وضعیت دروازه:** ✅ **سبز** — همه تست‌های این فاز پاس شدند (جدول انتهای گزارش)

---

## ۱. فهرست و ساختار (۴۵ فایل)

| بخش | فایل‌ها | حجم/تعداد |
|------|---------|-----------|
| قالب‌های اصلی PHP | `index, single, page, archive, search, 404, comments, header, footer, sidebar, searchform` | ۱۱ فایل |
| اجزای قالب | `template-parts/content{,-page,-single,-search,-none}.php` | ۵ فایل |
| منطق (`inc/`) | `customizer.php, sanitization.php, template-functions.php, template-tags.php` | ۴ فایل + `functions.php` |
| استایل | `style.css` (فقط هدر+کامنت)، `assets/css/{main,main-rtl,fonts,editor-style}.css` | ‏main.css ‏۴۸۸ خط |
| اسکریپت | `assets/js/main.js` | ۵۰ خط، بدون jQuery |
| فونت | Vazirmatn ‏Regular/Medium/Bold ‏(woff2، ‏self-hosted، لایسنس OFL) | ۳ فایل ≈۵۰KB |
| زبان | `languages/fa_IR.po` + `fa_IR.mo` | ۳۷ رشته |
| متفرقه | `screenshot.png` ‏(1200×900)، `readme.txt`، `CHANGELOG.md` | — |

مجموع PHP بررسی‌شده: **۲۱ فایل، حدود ۱۰۷۷ خط** (با CSS/JS کل پروژه ≈۱۶۶۹ خط).

## ۲. هدر و مشخصات قالب (`style.css`)
- Theme Name: ‏Sarzamin Aryan — نسخه 1.1.0 — Requires WP 6.4 / PHP 7.4 — Tested up to 7.1
- Text Domain: ‏`sarzaminaryan`، ‏Domain Path: ‏`/languages`
- توضیح قالب درباره «دانشنامه سفر ایران» است → **ناهماهنگ با پروژه اتاق عمل** (در فاز ۲ خنثی شد، متن پزشکی ساخته نشد)
- تگ‌ها: rtl-language-support, accessibility-ready, translation-ready و…

## ۳. معماری و هوک‌ها (`functions.php` و `inc/`)
- `sarzaminaryan_setup()` روی `after_setup_theme`: ترجمه، title-tag، thumbnails، custom-logo (‏240×80 انعطاف‌پذیر)، HTML5، responsive-embeds، align-wide، wp-block-styles، editor-styles، دو منو (primary/footer)
- سایز تصویر: hero ‏1200×675 + کارت `sarzaminaryan-card` ‏600×338
- `$content_width = 1200` ✅
- دارایی‌ها: fonts ← main (با `rtl: append`) ← style.css؛ اسکریپت با `strategy: defer`؛ preload فقط Vazirmatn-Regular؛ `comment-reply` فقط هنگام نیاز ✅
- Customizer: بخش `sarzaminaryan_options` + تنظیم `sarzaminaryan_footer_text` (در قالب قبلی استفاده نمی‌شد، در 1.1.0 اصلاح شده) ✅
- Template tags: متای تاریخ/نویسنده و فوتر نوشته با escaping کامل

## ۴. یافته‌های مثبت (حفظ شوند)
1. بدون jQuery، بدون CDN و بدون درخواست خارجی؛ فونت کاملاً محلی (OFL)
2. CSS با ویژگی‌های منطقی (logical properties) — RTL/LTR بدون هک دوبرابر (main-rtl.css فقط ۲ قانون)
3. دسترس‌پذیری: skip-link استاندارد، `.screen-reader-text` صحیح، ‏`:focus-visible` واضح، اهداف لمسی ۴۴px، ‏`prefers-reduced-motion`، بستن منو/جستجو با Escape و مدیریت فوکوس
4. کنتراست اندازه‌گیری‌شده روی سفید: متن ‏14.76، ‏primary ‏(#0e7490) ‏5.36، ‏primary-dark ‏7.27، ‏muted ‏5.80 — همه ≥ ‏WCAG AA برای متن عادی (4.5)
5. امنیت: هیچ `$_GET/$_POST` مستقیمی نیست؛ خروجی‌ها `esc_html/esc_url/esc_attr` شده‌اند؛ گارد `ABSPATH` در فایل‌های اصلی
6. عملکرد: lazy برای تصاویر کارت، eager+fetchpriority برای hero، ‏aspect-ratio ‏16/9 (ضد CLS)

## ۵. یافته‌ها و مشکلات (به ترتیب اهمیت)

| # | شدت | یافته | اثر / ارجاع به قوانین |
|---|------|-------|------------------------|
| F1 | 🔴 بالا | قالب **کلاسیک** است: هیچ `theme.json`، قالب بلاکی (HTML) یا Pattern ندارد | با قانون E1 و فازهای ۲–۳ منبع ناسازگار؛ تبدیل معماری کار جداگانه است (ADR-001) |
| F2 | 🔴 بالا | هویت قالب «سفر ایران» است (توضیح، نشان «س»، کامنت‌ها) ولی پروژه «آموزش اتاق عمل» است | در فاز ۲ فقط خنثی‌سازی شد؛ محتوای جدید با تیم محتوا (C1/C2) |
| F3 | 🟡 متوسط | سه تابع `sarzaminaryan_sanitize_{checkbox,select,color}` تعریف شده‌اند اما هیچ‌جا استفاده نمی‌شوند (فقط تعریف + گارد) | کد مرده — خلاف E4؛ در فاز ۲ **حذف نشدند** تا «بدون تغییر رفتار» حفظ شود، اما برای فاز پاک‌سازی بعدی ثبت شدند |
| F4 | 🟡 متوسط | بلاک‌های اجباری قانون C3 (سلب مسئولیت پزشکی / بازبینی‌شده توسط) در هیچ قالبی نیست | وظیفه فازهای ۴–۵ نقشه‌راه (قالب مقاله)، نه قالب والد فعلی |
| F5 | 🟢 پایین | `searchform.php`: مقدار `value` با `get_search_query()` بدون `esc_attr()` صریح چاپ می‌شود (تابع به‌صورت پیش‌فرض escape می‌کند، اما صریح‌نویسی استانداردتر است) | ثبت برای فاز اصلاح؛ در تغییر نام دست نخورد |
| F6 | 🟢 پایین | فایل‌های `inc/*.php` و `template-parts/*` گارد مستقیم `ABSPATH` ندارند (رویه رایج در قالب‌های کلاسیک است) | ریسک پایین؛ ثبت شد |
| F7 | 🟢 پایین | ‏`.po` هدر قدیمی دارد و باید پس از تغییر دامنه بازکامپایل شود | در فاز ۲ انجام شد |
| F8 | 🟢 اطلاع | رنگ accent نارنجی (#c2410c، کنتراست 5.18) در پالت است؛ برای موضوع پزشکیِ آرام باید در فاز ۲ نقشه‌راه بازبینی شود | دست نخورد — تغییر پالت یعنی تغییر ظاهر، خارج از دامنه تغییر نام |

## ۶. نتایج تست دروازه این فاز

| تست | روش | نتیجه |
|------|------|--------|
| نحوی PHP | `php -l` (PHP 8.4) روی ۲۱ فایل | ✅ ۲۱/۲۱ بدون خطا |
| نحوی JS | `node --check assets/js/main.js` | ✅ سالم |
| توازن CSS | شمارش `{` و `}` در ۴ فایل | ✅ متعادل (‏71/71 در main.css) |
| دارایی‌های ارجاع‌شده | استخراج `url()` از CSS و بررسی وجود فایل | ✅ ۳/۳ فونت موجود |
| اسکن سوپرگلوبال | جستجوی `$_GET/$_POST/$_REQUEST` | ✅ صفر مورد |
| وابستگی خارجی | جستجوی CDN/Google Fonts/jQuery | ✅ صفر مورد |
| پوشش ترجمه | مقایسه رشته‌های i18n کد با `.po` | ✅ ۳۶ رشته یکتا در کد، پوشش فایل زبان برقرار |
| تصویر بندانگشتی | `screenshot.png` | ✅ 1200×900 RGB |

## ۷. مشکلات باز و ریسک‌ها
- تبدیل به Block Theme (فازهای ۲–۳ نقشه‌راه) بزرگ‌ترین کار باز است و نباید با تغییر نام اشتباه گرفته شود.
- حذف توابع sanitization بلااستفاده و اصلاح F5/F6 بهتر است در یک فاز «پاک‌سازی» جداگانه با تست خودش انجام شود.
- پس از تغییر نام، قالب فرزند قبلی (`sarzaminaryan-child`) دیگر به این والد وصل نمی‌شود (Template name عوض شده) — Breaking Change آگاهانه (ADR-002).

## ۸. پیشنهاد فاز بعد
ورود به **فاز اجرایی ۲ — تغییر نام به `lax-theme`** طبق جدول نگاشت سند اصلی، با دروازه: صفر ارجاع اجرایی به نام قدیمی + تکرار همه تست‌های این فاز روی نسخه جدید.
