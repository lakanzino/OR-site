# همیار پزشک‌ها (hamyar-doctors)

افزونهٔ مستقل «پزشک‌ها» برای سایت همیار جراحی: نوع محتوای `doctor` با taxonomyهای تخصص و شهر، زمینه‌های نمایه با JSON محلی ACF (بدون Sync دستی) و نقش «پزشک» که فقط به نمایهٔ خودش دسترسی دارد. مستقل از قالب فرزند است و در حالت عادی حتی یک خط به `debug.log` نمی‌نویسد.

## ساختار (بخش‌ها)

| بخش | فایل | محتوا |
| --- | --- | --- |
| ۱ | `hamyar-doctors.php` | helperها (`hj_doctors_path/url`، `hj_to_en_digits`، `hj_doctors_default_photo_url` همگی با نگهبان `function_exists`) + کلاس اصلی و قلاب فعال/غیرفعال |
| ۲ | `includes/taxonomies.php` + `includes/cpt.php` | چهار taxonomy طرح واقعی: `specialty_type`، `specialty` (متا `hj_specialty_type_id`)، `province`، `city` (متا `hj_province_id`) + نوع محتوای `doctor` با `map_meta_cap` روشن |
| ۳ | `includes/acf-fields.php` + `acf-json/group_hj_doctor_profile.json` | گروه زمینهٔ «اطلاعات پزشک» فقط به‌صورت JSON محلی؛ این فایل مسیرهای save/load را نشانه می‌گیرد و روی ذخیره سانیتایز می‌کند |
| ۴ | `includes/roles.php` + `includes/security.php` + `includes/dashboard.php` | کلاس `HJ_Doctors_Roles` (نقش پزشک بدون edit_posts، capهای سطح مدیر به‌صورت پویا برای دارندگان `manage_options`، مالکیت = نویسنده یا متا `hj_doctor_post_id`، قفل پیشخوان به نفع `/my-profile/`، سقف نوع/حجم/تعداد بارگذاری) + primitiveهای `hj_sec_*` + صفحهٔ ناحیه پزشک و شورت‌کد شروع |
| ۵ | `includes/auth-google.php` | پل ورود/ثبت‌نام با گوگل روی Nextend Social Login: کوکی نیت امضاشده (`hj_doc_intent`، HMAC با `wp_salt`، ۳۰ دقیقه)، ورودی پزشکان `/?hj_google_start=1`، هوک‌های `nsl_register_new_user`/`nsl_login` + آداپتور عمومی `hj_doctors_google_user_ready`، شورت‌کد `[hj_google_login]` و صفحهٔ وضعیت فقط-مدیر `admin-post.php?action=hj_auth_status` |
| ۶ | `includes/dashboard.php` + `assets/js/dashboard.js` + `assets/css/dashboard.css` | داشبورد مینیمال `/my-profile/`: فرم پنج‌بلوکی دوزبانه، ذخیرهٔ AJAX با خطای زیر همان فیلد، پیش‌نمایش زنده، نوار تکمیل، «ارسال برای بررسی» و گردش تأیید مدیر، عکس پروفایل و مدارک خصوصی در `uploads/hj-private/p<ID>/` |
| دارایی | `assets/img/doctor-default.jpg` | عکس پیش‌فرض نمایه که `hj_doctors_default_photo_url()` برمی‌گرداند |

## زمینه‌های نمایه (طرح دوزبانهٔ بخش ۶)

`name_fa`/`name_en`، `specialty_fa`/`specialty_en`، `bio_fa`/`bio_en`، `medical_license` (ارقام فارسی/عربی خودکار به لاتین)، `experience_years`، `education`، `surgeries_performed`، `phone_clinic`، `phone_mobile`، `address_clinic`، `address_hospital`، `map_link` (فقط https از گوگل‌مپ/نشان/بلد)، `profile_photo` (شناسهٔ پیوست) و تکرارشوندهٔ `working_hours` (زیرفیلدهای `day_of_week`، `is_closed`، `start_time`، `end_time`).
خواندن در قالب: `hj_doctors_field( 'phone_clinic', $post_id )` و تصویر: `hj_doctors_photo_url( $post_id )` — بدون ACF هم خطا نمی‌دهند.

## داشبورد /my-profile/ (بخش ۶)

- پنج بلوک فرم (اطلاعات پایه دوزبانه، تخصص و سوابق، تماس و نشانی، ساعات کاری، مدارک) + ستون کناری (پیش‌نمایش زنده، وضعیت/تکمیل، امتیاز فقط‌خواندنی).
- ذخیره/عکس/مدرک/ارسال همه AJAX با نانس `hj_dash_nonce` و ریت‌لیمیت به ازای کاربر؛ خطاها فقط زیر همان فیلد.
- اولین ذخیره، پست `doctor` پیش‌نویس می‌سازد و `post_author` + متای کاربر `hj_doctor_post_id` را ثبت می‌کند.
- گردش تأیید: پزشک → `pending`؛ مدیر از لیست پزشکان «تأیید و انتشار» / «نیازمند اصلاح» (ستون «وضعیت پروفایل» هم هست).
- مدارک در `uploads/hj-private/p<ID>/` نگهداری می‌شوند؛ دانلود از طریق افزونه به نانس و مجوز نیاز دارد. اما `.htaccess` فقط در Apache با تنظیم مناسب مؤثر است و در Nginx به‌تنهایی محافظت نمی‌کند. پیش از بارگذاری مدارک واقعی، مسدود بودن دسترسی مستقیم HTTP به کل مسیر خصوصی را روی سرور و CDN بررسی کنید؛ برای Nginx قانون deny لازم است. مدارک قبلی نیز باید بررسی و محافظت شوند.
- صفحهٔ وضعیت مدیر: `wp-admin/admin-post.php?action=hj_dash_status` (ساختار جدول آرا، کلیدهای متای قدیمی، مقادیر روزهای هفته).
- هوک‌های توسعه: `hj_doctor_dashboard_appointments`، `hj_doctor_dashboard_widgets`، `hj_dash_days`، `hj_dash_max_specialties`، `hj_dash_max_docs`، `hj_doctors_map_hosts`.

## نصب و فعال‌سازی

1. پوشهٔ `hamyar-doctors` را در `wp-content/plugins/` بگذارید (یا از ZIP ریلیز نصب کنید).
2. افزونه را فعال کنید: نقش `doctor` ساخته می‌شود (با hash-check، بدون نوشتن cap در نقش مدیر)، صفحهٔ `/my-profile/` در صورت نبودن ساخته و rewriteها flush می‌شوند. در ارتقا به ۰٫۱٫۱ نیز برگهٔ گم‌شده ساخته می‌شود. اگر برگهٔ هم‌نام وجود داشته باشد، محتوایش تغییر نمی‌کند؛ آن را منتشر کنید و در صورت نبودن، شورت‌کد `[hj_doctors_dashboard]` را خودتان در آن قرار دهید. اگر قبلاً برگهٔ ثبت‌شده نامک دیگری داشته باشد، همان برگه و پیوند آن حفظ می‌شود.
3. کاربر می‌تواند در برگهٔ ناحیه پزشک ثبت‌نام را تأیید کند یا از جریان Google پزشکان وارد شود. نخستین ذخیره پروفایل پیش‌نویس می‌سازد؛ پس از تکمیل موارد لازم، پزشک آن را برای بررسی ارسال می‌کند و مدیر باید انتشار را تأیید کند. همچنین مدیر می‌تواند کاربر و نوشته را دستی بسازد. نقش‌های مدیریتی و ویرایشی تنزل داده نمی‌شوند.

## ورود با گوگل (بخش ۵)

- بدون Nextend Social Login، فایل بی‌خطر غیرفعال می‌ماند و فقط در لاگ یادداشت می‌شود.
- کوکی نیت امضاشده تعیین می‌کند چه کسی «قصد پزشک‌شدن» داشته: بیمارِ بدون کوکی همان `subscriber` می‌ماند؛ ادمین/ویراستار هرگز تنزل نمی‌گیرند (`hj_doctors_assign_doctor_role`).
- سقف ثبت‌نام: ۱۰ در ساعت **به ازای IP** (آرگومان چهارم `hj_sec_rate_limit`)؛ اگر سقف پر شود کاربر می‌ماند و نقش در ورود بعدی با متا `hj_role_pending` داده می‌شود.
- اتصال: Nextend Social Login را نصب و فعال کنید، Google provider را با تنظیمات Google Cloud پیکربندی و در Nextend Verify و Enable کنید؛ Redirect URI را دقیقاً از صفحهٔ تنظیمات Nextend برای همین سایت بردارید (بسته به تنظیمات proxy ممکن است متفاوت باشد). خطاهای consent، URI، دامنه یا محدودیت حالت Testing را در Google Cloud/Nextend بررسی کنید. اطلاعات محرمانه را به دیگران ارسال نکنید. صرف به‌روزرسانی قالب این افزونه یا OAuth را نصب و پیکربندی نمی‌کند.
- عیب‌یابی بدون ترمینال: `wp-admin/admin-post.php?action=hj_auth_status` (فقط مدیر، خروجی متن سادهٔ OK/MISSING).
- escape hatch: `define( 'HJ_DOCTORS_SAFE_MODE', true );` در `wp-config.php` همهٔ ماژول‌ها را لود نمی‌کند.

## Rollback

- فقط زمینه‌ها: حذف/rename کردن `includes/acf-fields.php` + پوشهٔ `acf-json/` کافی است (گروه زمینه فقط آنجا زندگی می‌کند).
- فقط قفل پیشخوان: `add_filter( 'hj_doctors_block_wp_admin', '__return_false' );` در یک mu-plugin یا قالب.
- کل افزونه: غیرفعال‌سازی داده‌ها را نگه می‌دارد؛ برای پاک‌سازی نقش: `remove_role( 'doctor' )` و حذف گزینه‌های `hj_doctors_roles_hash`، `hj_doctors_role_caps_added`، `hj_doctors_log` و `hj_doctors_dashboard_page`.

## چک‌لیست بعد از جایگذاری روی سرور

- فروش/نوبت‌دهی دستی لازم نیست؛ Sync های ACF فقط در `acf-json/` پایین می‌آیند، نه قالب فرزند.
- Purge All LiteSpeed بعد از جایگذاری و خروج دائمی برگهٔ داشبورد، `/?hj_google_start=1`، مسیرهای ورود، callback گوگل و admin-ajax از cache در همهٔ لایه‌ها (از جمله CDN). عدم ذخیرهٔ داشبورد را برای کاربران مختلف آزمایش کنید.
- تست ویرایش یک پزشک نمونه (همهٔ تب‌ها) و یک کاربر با نقش پزشک: باید فقط نمایهٔ خودش را ببیند و پیشخوان به `profile.php` برگردد.
- `debug.log` باید خالی بماند.
- فهرست کاری برای مدیر: ساخت تخصص/شهر، افزودن پزشک، بررسی بایگانی `/doctors/`.

## آزمون‌ها

محیط گیت‌هاب باینری PHP ندارد؛ مثل بقیهٔ پروژه با `tools/php-check.py` (بررسی توازن پرانتز/رشته/تگ) و `python3 -m json.tool` برای JSON بررسی می‌شود:

```bash
python3 tools/php-check.py plugins/hamyar-doctors/*.php plugins/hamyar-doctors/includes/*.php
python3 -m json.tool plugins/hamyar-doctors/acf-json/group_hj_doctor_profile.json > /dev/null
```

### آزمون یکپارچه در وردپرس موقت

روی نصب آزمایشی و دورریختنی با افزونهٔ فعال: `wp eval-file tests/integration/doctors-wp.php` از ریشهٔ مخزن. این آزمون نقش‌ها، هوک‌های Nextend و حفظ برگه را بررسی می‌کند؛ اتصال واقعی OAuth و تنظیمات سرور زنده را اثبات نمی‌کند.
