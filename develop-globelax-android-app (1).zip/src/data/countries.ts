// Globe.Lax – embedded, offline country dataset (195 countries:
// 193 UN member states + Vatican City + State of Palestine, the two UN observer states).
//
// Sources cross-checked: UN World Population Prospects 2024 (mid-2024 estimates, rounded),
// UN Statistics Division (area), CIA World Factbook, ISO 3166-1 / ISO 4217, World Bank.
// Population is stored in THOUSANDS in the raw table; areas are total area in km².
// Continent follows common geographic/educational convention (Cyprus → Europe, Turkey/Georgia/Armenia/
// Azerbaijan/Kazakhstan → Asia, Russia → Europe, Central America & Caribbean → North America).

import { CONTINENTS, CURRENCIES, LANGS, type Continent } from "./dictionaries";
import { FACTS, NOTES } from "./facts";

type Row = [
  iso: string, fa: string, en: string, capFa: string, capEn: string,
  cur: string, popK: number, area: number, langs: string, cont: Continent,
];

const RAW: Row[] = [
  // ───────── Asia ─────────
  ["AF", "افغانستان", "Afghanistan", "کابل", "Kabul", "AFN", 42240, 652230, "ps,prs", "AS"],
  ["AM", "ارمنستان", "Armenia", "ایروان", "Yerevan", "AMD", 2990, 29743, "hy", "AS"],
  ["AZ", "جمهوری آذربایجان", "Azerbaijan", "باکو", "Baku", "AZN", 10420, 86600, "az", "AS"],
  ["BH", "بحرین", "Bahrain", "منامه", "Manama", "BHD", 1570, 765, "ar", "AS"],
  ["BD", "بنگلادش", "Bangladesh", "داکا", "Dhaka", "BDT", 173000, 147570, "bn", "AS"],
  ["BT", "بوتان", "Bhutan", "تیمپو", "Thimphu", "BTN", 790, 38394, "dz", "AS"],
  ["BN", "برونئی", "Brunei", "بندر سری بگاوان", "Bandar Seri Begawan", "BND", 460, 5765, "ms", "AS"],
  ["KH", "کامبوج", "Cambodia", "پنوم‌پن", "Phnom Penh", "KHR", 16950, 181035, "km", "AS"],
  ["CN", "چین", "China", "پکن", "Beijing", "CNY", 1419000, 9596960, "zh", "AS"],
  ["GE", "گرجستان", "Georgia", "تفلیس", "Tbilisi", "GEL", 3810, 69700, "ka", "AS"],
  ["IN", "هند", "India", "دهلی نو", "New Delhi", "INR", 1450000, 3287263, "hi,en", "AS"],
  ["ID", "اندونزی", "Indonesia", "جاکارتا", "Jakarta", "IDR", 283000, 1904569, "id", "AS"],
  ["IR", "ایران", "Iran", "تهران", "Tehran", "IRR", 91600, 1648195, "fa", "AS"],
  ["IQ", "عراق", "Iraq", "بغداد", "Baghdad", "IQD", 46000, 438317, "ar,ku", "AS"],
  ["IL", "اسرائیل", "Israel", "بیت‌المقدس (اعلام‌شده)", "Jerusalem (declared)", "ILS", 9400, 21937, "he", "AS"],
  ["JP", "ژاپن", "Japan", "توکیو", "Tokyo", "JPY", 123800, 377915, "ja", "AS"],
  ["JO", "اردن", "Jordan", "امان", "Amman", "JOD", 11550, 89342, "ar", "AS"],
  ["KZ", "قزاقستان", "Kazakhstan", "آستانه", "Astana", "KZT", 20600, 2724900, "kk,ru", "AS"],
  ["KW", "کویت", "Kuwait", "شهر کویت", "Kuwait City", "KWD", 4900, 17818, "ar", "AS"],
  ["KG", "قرقیزستان", "Kyrgyzstan", "بیشکک", "Bishkek", "KGS", 7160, 199951, "ky,ru", "AS"],
  ["LA", "لائوس", "Laos", "وینتیان", "Vientiane", "LAK", 7800, 236800, "lo", "AS"],
  ["LB", "لبنان", "Lebanon", "بیروت", "Beirut", "LBP", 5800, 10452, "ar", "AS"],
  ["MY", "مالزی", "Malaysia", "کوالالامپور", "Kuala Lumpur", "MYR", 35600, 330803, "ms", "AS"],
  ["MV", "مالدیو", "Maldives", "ماله", "Malé", "MVR", 515, 298, "dv", "AS"],
  ["MN", "مغولستان", "Mongolia", "اولان‌باتور", "Ulaanbaatar", "MNT", 3500, 1564116, "mn", "AS"],
  ["MM", "میانمار", "Myanmar", "نایپیداو", "Naypyidaw", "MMK", 54500, 676578, "my", "AS"],
  ["NP", "نپال", "Nepal", "کاتماندو", "Kathmandu", "NPR", 29650, 147181, "ne", "AS"],
  ["KP", "کره شمالی", "North Korea", "پیونگ‌یانگ", "Pyongyang", "KPW", 26500, 120538, "ko", "AS"],
  ["OM", "عمان", "Oman", "مسقط", "Muscat", "OMR", 5200, 309500, "ar", "AS"],
  ["PK", "پاکستان", "Pakistan", "اسلام‌آباد", "Islamabad", "PKR", 251000, 796095, "ur,en", "AS"],
  ["PS", "فلسطین", "Palestine", "رام‌الله (مقر اداری)", "Ramallah (administrative seat)", "ILS", 5500, 6020, "ar", "AS"],
  ["PH", "فیلیپین", "Philippines", "مانیل", "Manila", "PHP", 115800, 300000, "fil,en", "AS"],
  ["QA", "قطر", "Qatar", "دوحه", "Doha", "QAR", 3000, 11586, "ar", "AS"],
  ["SA", "عربستان سعودی", "Saudi Arabia", "ریاض", "Riyadh", "SAR", 35300, 2149690, "ar", "AS"],
  ["SG", "سنگاپور", "Singapore", "سنگاپور", "Singapore", "SGD", 6000, 734, "en,ms,zh,ta", "AS"],
  ["KR", "کره جنوبی", "South Korea", "سئول", "Seoul", "KRW", 51700, 100210, "ko", "AS"],
  ["LK", "سری‌لانکا", "Sri Lanka", "سری جایاواردنه‌پورا کوته", "Sri Jayawardenepura Kotte", "LKR", 23100, 65610, "si,ta", "AS"],
  ["SY", "سوریه", "Syria", "دمشق", "Damascus", "SYP", 24000, 185180, "ar", "AS"],
  ["TJ", "تاجیکستان", "Tajikistan", "دوشنبه", "Dushanbe", "TJS", 10600, 144100, "tg", "AS"],
  ["TH", "تایلند", "Thailand", "بانکوک", "Bangkok", "THB", 71700, 513120, "th", "AS"],
  ["TL", "تیمور شرقی", "Timor-Leste", "دیلی", "Dili", "USD", 1400, 14874, "pt,tet", "AS"],
  ["TR", "ترکیه", "Türkiye", "آنکارا", "Ankara", "TRY", 87500, 783562, "tr", "AS"],
  ["TM", "ترکمنستان", "Turkmenistan", "عشق‌آباد", "Ashgabat", "TMT", 7500, 488100, "tk", "AS"],
  ["AE", "امارات متحده عربی", "United Arab Emirates", "ابوظبی", "Abu Dhabi", "AED", 11000, 83600, "ar", "AS"],
  ["UZ", "ازبکستان", "Uzbekistan", "تاشکند", "Tashkent", "UZS", 36400, 447400, "uz", "AS"],
  ["VN", "ویتنام", "Vietnam", "هانوی", "Hanoi", "VND", 101000, 331212, "vi", "AS"],
  ["YE", "یمن", "Yemen", "صنعا", "Sanaa", "YER", 40600, 527968, "ar", "AS"],

  // ───────── Europe ─────────
  ["AL", "آلبانی", "Albania", "تیرانا", "Tirana", "ALL", 2800, 28748, "sq", "EU"],
  ["AD", "آندورا", "Andorra", "آندورا لا ویا", "Andorra la Vella", "EUR", 80, 468, "ca", "EU"],
  ["AT", "اتریش", "Austria", "وین", "Vienna", "EUR", 9100, 83871, "de", "EU"],
  ["BY", "بلاروس", "Belarus", "مینسک", "Minsk", "BYN", 9100, 207600, "be,ru", "EU"],
  ["BE", "بلژیک", "Belgium", "بروکسل", "Brussels", "EUR", 11800, 30528, "nl,fr,de", "EU"],
  ["BA", "بوسنی و هرزگوین", "Bosnia and Herzegovina", "سارایوو", "Sarajevo", "BAM", 3200, 51197, "bs,hr,sr", "EU"],
  ["BG", "بلغارستان", "Bulgaria", "صوفیه", "Sofia", "EUR", 6500, 110879, "bg", "EU"],
  ["HR", "کرواسی", "Croatia", "زاگرب", "Zagreb", "EUR", 3850, 56594, "hr", "EU"],
  ["CY", "قبرس", "Cyprus", "نیکوزیا", "Nicosia", "EUR", 1370, 9251, "el,tr", "EU"],
  ["CZ", "چک", "Czechia", "پراگ", "Prague", "CZK", 10700, 78867, "cs", "EU"],
  ["DK", "دانمارک", "Denmark", "کپنهاگ", "Copenhagen", "DKK", 5980, 43094, "da", "EU"],
  ["EE", "استونی", "Estonia", "تالین", "Tallinn", "EUR", 1370, 45228, "et", "EU"],
  ["FI", "فنلاند", "Finland", "هلسینکی", "Helsinki", "EUR", 5600, 338145, "fi,sv", "EU"],
  ["FR", "فرانسه", "France", "پاریس", "Paris", "EUR", 66550, 643801, "fr", "EU"],
  ["DE", "آلمان", "Germany", "برلین", "Berlin", "EUR", 84550, 357022, "de", "EU"],
  ["GR", "یونان", "Greece", "آتن", "Athens", "EUR", 10050, 131957, "el", "EU"],
  ["HU", "مجارستان", "Hungary", "بوداپست", "Budapest", "HUF", 9600, 93028, "hu", "EU"],
  ["IS", "ایسلند", "Iceland", "ریکیاویک", "Reykjavík", "ISK", 395, 103000, "is", "EU"],
  ["IE", "ایرلند", "Ireland", "دوبلین", "Dublin", "EUR", 5300, 70273, "ga,en", "EU"],
  ["IT", "ایتالیا", "Italy", "رم", "Rome", "EUR", 59300, 301340, "it", "EU"],
  ["LV", "لتونی", "Latvia", "ریگا", "Riga", "EUR", 1860, 64589, "lv", "EU"],
  ["LI", "لیختن‌اشتاین", "Liechtenstein", "فادوتس", "Vaduz", "CHF", 40, 160, "de", "EU"],
  ["LT", "لیتوانی", "Lithuania", "ویلنیوس", "Vilnius", "EUR", 2900, 65300, "lt", "EU"],
  ["LU", "لوکزامبورگ", "Luxembourg", "شهر لوکزامبورگ", "Luxembourg City", "EUR", 670, 2586, "lb,fr,de", "EU"],
  ["MT", "مالت", "Malta", "والتا", "Valletta", "EUR", 540, 316, "mt,en", "EU"],
  ["MD", "مولداوی", "Moldova", "کیشینف", "Chișinău", "MDL", 3000, 33851, "ro", "EU"],
  ["MC", "موناکو", "Monaco", "موناکو", "Monaco", "EUR", 38, 2.02, "fr", "EU"],
  ["ME", "مونته‌نگرو", "Montenegro", "پودگوریتسا", "Podgorica", "EUR", 620, 13812, "cnr,sr", "EU"],
  ["NL", "هلند", "Netherlands", "آمستردام", "Amsterdam", "EUR", 18000, 41850, "nl", "EU"],
  ["MK", "مقدونیه شمالی", "North Macedonia", "اسکوپیه", "Skopje", "MKD", 1830, 25713, "mk,sq", "EU"],
  ["NO", "نروژ", "Norway", "اسلو", "Oslo", "NOK", 5550, 385207, "no", "EU"],
  ["PL", "لهستان", "Poland", "ورشو", "Warsaw", "PLN", 38500, 312696, "pl", "EU"],
  ["PT", "پرتغال", "Portugal", "لیسبون", "Lisbon", "EUR", 10400, 92090, "pt", "EU"],
  ["RO", "رومانی", "Romania", "بخارست", "Bucharest", "RON", 19000, 238397, "ro", "EU"],
  ["RU", "روسیه", "Russia", "مسکو", "Moscow", "RUB", 144000, 17098246, "ru", "EU"],
  ["SM", "سن‌مارینو", "San Marino", "سن‌مارینو", "San Marino", "EUR", 34, 61, "it", "EU"],
  ["RS", "صربستان", "Serbia", "بلگراد", "Belgrade", "RSD", 6700, 88361, "sr", "EU"],
  ["SK", "اسلواکی", "Slovakia", "براتیسلاوا", "Bratislava", "EUR", 5420, 49035, "sk", "EU"],
  ["SI", "اسلوونی", "Slovenia", "لیوبلیانا", "Ljubljana", "EUR", 2120, 20273, "sl", "EU"],
  ["ES", "اسپانیا", "Spain", "مادرید", "Madrid", "EUR", 48400, 505990, "es", "EU"],
  ["SE", "سوئد", "Sweden", "استکهلم", "Stockholm", "SEK", 10600, 450295, "sv", "EU"],
  ["CH", "سوئیس", "Switzerland", "برن", "Bern", "CHF", 8900, 41284, "de,fr,it,rm", "EU"],
  ["UA", "اوکراین", "Ukraine", "کیف", "Kyiv", "UAH", 37900, 603550, "uk", "EU"],
  ["GB", "بریتانیا", "United Kingdom", "لندن", "London", "GBP", 69100, 242495, "en", "EU"],
  ["VA", "واتیکان", "Vatican City", "شهر واتیکان", "Vatican City", "EUR", 0.8, 0.49, "it,la", "EU"],

  // ───────── Africa ─────────
  ["DZ", "الجزایر", "Algeria", "الجزیره", "Algiers", "DZD", 46800, 2381741, "ar,ber", "AF"],
  ["AO", "آنگولا", "Angola", "لوآندا", "Luanda", "AOA", 37000, 1246700, "pt", "AF"],
  ["BJ", "بنین", "Benin", "پورتو نوو", "Porto-Novo", "XOF", 14500, 112622, "fr", "AF"],
  ["BW", "بوتسوانا", "Botswana", "گابورون", "Gaborone", "BWP", 2500, 581730, "en,tn", "AF"],
  ["BF", "بورکینافاسو", "Burkina Faso", "اوآگادوگو", "Ouagadougou", "XOF", 23500, 272967, "fr", "AF"],
  ["BI", "بوروندی", "Burundi", "گیتگا", "Gitega", "BIF", 14000, 27830, "rn,fr,en", "AF"],
  ["CV", "کیپ ورد", "Cabo Verde", "پرایا", "Praia", "CVE", 525, 4033, "pt", "AF"],
  ["CM", "کامرون", "Cameroon", "یائونده", "Yaoundé", "XAF", 29000, 475440, "fr,en", "AF"],
  ["CF", "جمهوری آفریقای مرکزی", "Central African Republic", "بانگی", "Bangui", "XAF", 5300, 622984, "fr,sg", "AF"],
  ["TD", "چاد", "Chad", "انجامنا", "N'Djamena", "XAF", 20300, 1284000, "fr,ar", "AF"],
  ["KM", "کومور", "Comoros", "مورونی", "Moroni", "KMF", 870, 2235, "zdj,ar,fr", "AF"],
  ["CG", "جمهوری کنگو", "Republic of the Congo", "برازاویل", "Brazzaville", "XAF", 6300, 342000, "fr", "AF"],
  ["CD", "جمهوری دموکراتیک کنگو", "DR Congo", "کینشاسا", "Kinshasa", "CDF", 105000, 2344858, "fr", "AF"],
  ["CI", "ساحل عاج", "Côte d'Ivoire", "یاموسوکرو", "Yamoussoukro", "XOF", 31900, 322463, "fr", "AF"],
  ["DJ", "جیبوتی", "Djibouti", "جیبوتی", "Djibouti", "DJF", 1150, 23200, "fr,ar", "AF"],
  ["EG", "مصر", "Egypt", "قاهره", "Cairo", "EGP", 114500, 1002000, "ar", "AF"],
  ["GQ", "گینه استوایی", "Equatorial Guinea", "مالابو", "Malabo", "XAF", 1800, 28051, "es,fr,pt", "AF"],
  ["ER", "اریتره", "Eritrea", "اسمره", "Asmara", "ERN", 3500, 117600, "ti,ar,en", "AF"],
  ["SZ", "اسواتینی", "Eswatini", "مبابانه", "Mbabane", "SZL", 1240, 17364, "ss,en", "AF"],
  ["ET", "اتیوپی", "Ethiopia", "آدیس‌آبابا", "Addis Ababa", "ETB", 132000, 1104300, "am", "AF"],
  ["GA", "گابن", "Gabon", "لیبرویل", "Libreville", "XAF", 2500, 267668, "fr", "AF"],
  ["GM", "گامبیا", "Gambia", "بانجول", "Banjul", "GMD", 2800, 11300, "en", "AF"],
  ["GH", "غنا", "Ghana", "آکرا", "Accra", "GHS", 34100, 238533, "en", "AF"],
  ["GN", "گینه", "Guinea", "کوناکری", "Conakry", "GNF", 14800, 245857, "fr", "AF"],
  ["GW", "گینه بیسائو", "Guinea-Bissau", "بیسائو", "Bissau", "XOF", 2200, 36125, "pt", "AF"],
  ["KE", "کنیا", "Kenya", "نایروبی", "Nairobi", "KES", 56400, 580367, "sw,en", "AF"],
  ["LS", "لسوتو", "Lesotho", "ماسرو", "Maseru", "LSL", 2300, 30355, "st,en", "AF"],
  ["LR", "لیبریا", "Liberia", "مونروویا", "Monrovia", "LRD", 5500, 111369, "en", "AF"],
  ["LY", "لیبی", "Libya", "طرابلس", "Tripoli", "LYD", 7400, 1759540, "ar", "AF"],
  ["MG", "ماداگاسکار", "Madagascar", "آنتاناناریوو", "Antananarivo", "MGA", 31000, 587041, "mg,fr", "AF"],
  ["MW", "مالاوی", "Malawi", "لیلانگوه", "Lilongwe", "MWK", 21700, 118484, "en,ny", "AF"],
  ["ML", "مالی", "Mali", "باماکو", "Bamako", "XOF", 24500, 1240192, "fr", "AF"],
  ["MR", "موریتانی", "Mauritania", "نواکشوط", "Nouakchott", "MRU", 5200, 1030700, "ar", "AF"],
  ["MU", "موریس", "Mauritius", "پورت‌لوئیس", "Port Louis", "MUR", 1260, 2040, "en,fr", "AF"],
  ["MA", "مراکش", "Morocco", "رباط", "Rabat", "MAD", 38000, 446550, "ar,ber", "AF"],
  ["MZ", "موزامبیک", "Mozambique", "ماپوتو", "Maputo", "MZN", 34600, 799380, "pt", "AF"],
  ["NA", "نامیبیا", "Namibia", "ویندهوک", "Windhoek", "NAD", 3030, 825615, "en", "AF"],
  ["NE", "نیجر", "Niger", "نیامی", "Niamey", "XOF", 27200, 1267000, "fr", "AF"],
  ["NG", "نیجریه", "Nigeria", "ابوجا", "Abuja", "NGN", 232700, 923768, "en", "AF"],
  ["RW", "رواندا", "Rwanda", "کیگالی", "Kigali", "RWF", 14300, 26338, "rw,en,fr,sw", "AF"],
  ["ST", "سائوتومه و پرنسیپ", "São Tomé and Príncipe", "سائوتومه", "São Tomé", "STN", 235, 964, "pt", "AF"],
  ["SN", "سنگال", "Senegal", "داکار", "Dakar", "XOF", 18500, 196722, "fr", "AF"],
  ["SC", "سیشل", "Seychelles", "ویکتوریا", "Victoria", "SCR", 130, 457, "crs,en,fr", "AF"],
  ["SL", "سیرالئون", "Sierra Leone", "فری‌تاون", "Freetown", "SLE", 8600, 71740, "en", "AF"],
  ["SO", "سومالی", "Somalia", "موگادیشو", "Mogadishu", "SOS", 19000, 637657, "so,ar", "AF"],
  ["ZA", "آفریقای جنوبی", "South Africa", "پرتوریا (اجرایی)", "Pretoria (executive)", "ZAR", 64000, 1219090, "en,zu,xh,af", "AF"],
  ["SS", "سودان جنوبی", "South Sudan", "جوبا", "Juba", "SSP", 11900, 644329, "en", "AF"],
  ["SD", "سودان", "Sudan", "خارطوم", "Khartoum", "SDG", 50000, 1861484, "ar,en", "AF"],
  ["TZ", "تانزانیا", "Tanzania", "دودوما", "Dodoma", "TZS", 68600, 947300, "sw,en", "AF"],
  ["TG", "توگو", "Togo", "لومه", "Lomé", "XOF", 9500, 56785, "fr", "AF"],
  ["TN", "تونس", "Tunisia", "تونس", "Tunis", "TND", 12200, 163610, "ar", "AF"],
  ["UG", "اوگاندا", "Uganda", "کامپالا", "Kampala", "UGX", 50000, 241038, "en,sw", "AF"],
  ["ZM", "زامبیا", "Zambia", "لوساکا", "Lusaka", "ZMW", 21300, 752612, "en", "AF"],
  ["ZW", "زیمبابوه", "Zimbabwe", "هراره", "Harare", "ZWG", 16600, 390757, "en,sn,nd", "AF"],

  // ───────── North America (incl. Central America & Caribbean) ─────────
  ["AG", "آنتیگوا و باربودا", "Antigua and Barbuda", "سنت جانز", "Saint John's", "XCD", 94, 442, "en", "NA"],
  ["BS", "باهاما", "Bahamas", "ناسائو", "Nassau", "BSD", 400, 13943, "en", "NA"],
  ["BB", "باربادوس", "Barbados", "بریج‌تاون", "Bridgetown", "BBD", 282, 430, "en", "NA"],
  ["BZ", "بلیز", "Belize", "بلموپان", "Belmopan", "BZD", 410, 22966, "en", "NA"],
  ["CA", "کانادا", "Canada", "اتاوا", "Ottawa", "CAD", 40100, 9984670, "en,fr", "NA"],
  ["CR", "کاستاریکا", "Costa Rica", "سن‌خوسه", "San José", "CRC", 5200, 51100, "es", "NA"],
  ["CU", "کوبا", "Cuba", "هاوانا", "Havana", "CUP", 11000, 109884, "es", "NA"],
  ["DM", "دومینیکا", "Dominica", "روسو", "Roseau", "XCD", 66, 751, "en", "NA"],
  ["DO", "جمهوری دومینیکن", "Dominican Republic", "سانتو دومینگو", "Santo Domingo", "DOP", 11500, 48671, "es", "NA"],
  ["SV", "السالوادور", "El Salvador", "سن‌سالوادور", "San Salvador", "USD", 6300, 21041, "es", "NA"],
  ["GD", "گرنادا", "Grenada", "سنت جورجز", "St. George's", "XCD", 117, 344, "en", "NA"],
  ["GT", "گواتمالا", "Guatemala", "شهر گواتمالا", "Guatemala City", "GTQ", 18400, 108889, "es", "NA"],
  ["HT", "هائیتی", "Haiti", "پورتوپرنس", "Port-au-Prince", "HTG", 11900, 27750, "fr,ht", "NA"],
  ["HN", "هندوراس", "Honduras", "تگوسیگالپا", "Tegucigalpa", "HNL", 10700, 112492, "es", "NA"],
  ["JM", "جامائیکا", "Jamaica", "کینگستون", "Kingston", "JMD", 2800, 10991, "en", "NA"],
  ["MX", "مکزیک", "Mexico", "مکزیکوسیتی", "Mexico City", "MXN", 130900, 1964375, "es", "NA"],
  ["NI", "نیکاراگوئه", "Nicaragua", "ماناگوئه", "Managua", "NIO", 7000, 130370, "es", "NA"],
  ["PA", "پاناما", "Panama", "شهر پاناما", "Panama City", "PAB", 4500, 75417, "es", "NA"],
  ["KN", "سنت کیتس و نویس", "Saint Kitts and Nevis", "باستر", "Basseterre", "XCD", 48, 261, "en", "NA"],
  ["LC", "سنت لوسیا", "Saint Lucia", "کاستریز", "Castries", "XCD", 180, 616, "en", "NA"],
  ["VC", "سنت وینسنت و گرنادین‌ها", "Saint Vincent and the Grenadines", "کینگزتاون", "Kingstown", "XCD", 110, 389, "en", "NA"],
  ["TT", "ترینیداد و توباگو", "Trinidad and Tobago", "پورت آو اسپین", "Port of Spain", "TTD", 1500, 5130, "en", "NA"],
  ["US", "ایالات متحده آمریکا", "United States", "واشینگتن دی‌سی", "Washington, D.C.", "USD", 345400, 9833517, "en", "NA"],

  // ───────── South America ─────────
  ["AR", "آرژانتین", "Argentina", "بوئنوس آیرس", "Buenos Aires", "ARS", 45700, 2780400, "es", "SA"],
  ["BO", "بولیوی", "Bolivia", "سوکره (قانونی)", "Sucre (constitutional)", "BOB", 12400, 1098581, "es,qu,ay", "SA"],
  ["BR", "برزیل", "Brazil", "برازیلیا", "Brasília", "BRL", 211100, 8515767, "pt", "SA"],
  ["CL", "شیلی", "Chile", "سانتیاگو", "Santiago", "CLP", 19800, 756102, "es", "SA"],
  ["CO", "کلمبیا", "Colombia", "بوگوتا", "Bogotá", "COP", 52900, 1141748, "es", "SA"],
  ["EC", "اکوادور", "Ecuador", "کیتو", "Quito", "USD", 18100, 283561, "es", "SA"],
  ["GY", "گویان", "Guyana", "جورج‌تاون", "Georgetown", "GYD", 830, 214969, "en", "SA"],
  ["PY", "پاراگوئه", "Paraguay", "آسونسیون", "Asunción", "PYG", 6900, 406752, "es,gn", "SA"],
  ["PE", "پرو", "Peru", "لیما", "Lima", "PEN", 34200, 1285216, "es,qu,ay", "SA"],
  ["SR", "سورینام", "Suriname", "پاراماریبو", "Paramaribo", "SRD", 635, 163820, "nl", "SA"],
  ["UY", "اروگوئه", "Uruguay", "مونته‌ویدئو", "Montevideo", "UYU", 3400, 176215, "es", "SA"],
  ["VE", "ونزوئلا", "Venezuela", "کاراکاس", "Caracas", "VES", 28400, 916445, "es", "SA"],

  // ───────── Oceania ─────────
  ["AU", "استرالیا", "Australia", "کانبرا", "Canberra", "AUD", 27200, 7692024, "en", "OC"],
  ["FJ", "فیجی", "Fiji", "سوآ", "Suva", "FJD", 930, 18274, "en,fj,hif", "OC"],
  ["KI", "کیریباتی", "Kiribati", "تاراوای جنوبی", "South Tarawa", "AUD", 135, 811, "en,gil", "OC"],
  ["MH", "جزایر مارشال", "Marshall Islands", "ماجورو", "Majuro", "USD", 38, 181, "mh,en", "OC"],
  ["FM", "میکرونزی", "Micronesia", "پالیکیر", "Palikir", "USD", 115, 702, "en", "OC"],
  ["NR", "نائورو", "Nauru", "یارن (عملاً)", "Yaren (de facto)", "AUD", 12.7, 21, "na,en", "OC"],
  ["NZ", "نیوزیلند", "New Zealand", "ولینگتون", "Wellington", "NZD", 5300, 268838, "en,mi", "OC"],
  ["PW", "پالائو", "Palau", "انگرولمود", "Ngerulmud", "USD", 18, 459, "pau,en", "OC"],
  ["PG", "پاپوآ گینه نو", "Papua New Guinea", "پورت مورزبی", "Port Moresby", "PGK", 10600, 462840, "en,tpi,ho", "OC"],
  ["WS", "ساموآ", "Samoa", "آپیا", "Apia", "WST", 215, 2831, "sm,en", "OC"],
  ["SB", "جزایر سلیمان", "Solomon Islands", "هونیارا", "Honiara", "SBD", 740, 28896, "en", "OC"],
  ["TO", "تونگا", "Tonga", "نوکوالوفا", "Nukuʻalofa", "TOP", 100, 747, "to,en", "OC"],
  ["TV", "تووالو", "Tuvalu", "فونافوتی", "Funafuti", "AUD", 11, 26, "tvl,en", "OC"],
  ["VU", "وانواتو", "Vanuatu", "پورت ویلا", "Port Vila", "VUV", 335, 12189, "bi,en,fr", "OC"],
];

// Latin is not in the main dictionary (only Vatican uses it) – add it here.
const EXTRA_LANGS: Record<string, [string, string]> = { la: ["لاتین", "Latin"] };

export interface Country {
  isoCode: string;
  nameFa: string;
  nameEn: string;
  capitalFa: string;
  capitalEn: string;
  currencyCode: string;
  currencyNameFa: string;
  currencyNameEn: string;
  population: number;
  areaKm2: number;
  languagesFa: string;
  languagesEn: string;
  continent: Continent;
  continentFa: string;
  continentEn: string;
  flagEmoji: string;
  shortFactFa?: string;
  noteFa?: string;
  /** lower-cased, normalised haystack used by search */
  searchKey: string;
  popRank: number;
  areaRank: number;
}

/** Normalise Persian/Arabic variants so that search is forgiving. */
export function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[\u064A\u0649]/g, "ی")
    .replace(/\u0643/g, "ک")
    .replace(/[\u064B-\u065F\u0670\u200c\u200f]/g, "")
    .replace(/[آأإ]/g, "ا")
    .replace(/\u00e9|\u00e8/g, "e")
    .replace(/[^\p{L}\p{N} ]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Unicode regional-indicator flag emoji from ISO alpha-2 code. */
function emojiFlag(iso: string): string {
  return String.fromCodePoint(...[...iso].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

const built: Country[] = RAW.map(([iso, fa, en, capFa, capEn, cur, popK, area, langs, cont]) => {
  const l = langs.split(",").map((k) => LANGS[k] ?? EXTRA_LANGS[k]);
  const c = CURRENCIES[cur];
  const country: Country = {
    isoCode: iso,
    nameFa: fa,
    nameEn: en,
    capitalFa: capFa,
    capitalEn: capEn,
    currencyCode: cur,
    currencyNameFa: c[0],
    currencyNameEn: c[1],
    population: Math.round(popK * 1000),
    areaKm2: area,
    languagesFa: l.map((x) => x[0]).join("، "),
    languagesEn: l.map((x) => x[1]).join(", "),
    continent: cont,
    continentFa: CONTINENTS[cont].fa,
    continentEn: CONTINENTS[cont].en,
    flagEmoji: emojiFlag(iso),
    shortFactFa: FACTS[iso],
    noteFa: NOTES[iso],
    searchKey: "",
    popRank: 0,
    areaRank: 0,
  };
  country.searchKey = normalize(
    [fa, en, capFa, capEn, c[0], c[1], cur, iso, country.languagesFa, country.languagesEn].join(" "),
  );
  return country;
});

// Global ranks (1 = largest)
[...built].sort((a, b) => b.population - a.population).forEach((c, i) => (c.popRank = i + 1));
[...built].sort((a, b) => b.areaKm2 - a.areaKm2).forEach((c, i) => (c.areaRank = i + 1));

/** All countries, alphabetical by English name (stable, deterministic). */
export const COUNTRIES: Country[] = built.sort((a, b) => a.nameEn.localeCompare(b.nameEn, "en"));
export const COUNTRY_MAP: Record<string, Country> = Object.fromEntries(COUNTRIES.map((c) => [c.isoCode, c]));
