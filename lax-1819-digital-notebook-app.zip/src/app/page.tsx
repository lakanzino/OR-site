const fa = (n: number | string) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

const features = [
  ["📅", "تقویم جلالی بومی", "تقویم شمسی کامل با نام ماه‌ها، دکمه‌ی «امروز» و نقطه‌ی روزهای دارای برگه؛ بدون هیچ وابستگی خارجی."],
  ["🗂️", "چند برگه برای هر روز", "برگه‌های مستقل، کپی از روز قبل، قالب‌های ذخیره‌شده، جستجو و کشیدن برای حذف/تکثیر با امکان بازگردانی."],
  ["🧩", "ستون‌های کاملاً پویا", "نام، محصول، خدمات، تاریخ تولید/انقضا، ساعت‌ها، مقدار با واحد، هزینه، بیعانه، اقساط، یادداشت، وضعیت رنگی و ستون سفارشی."],
  ["🔒", "مدیریت ستون", "سوییچ نمایش، قفل، تغییر نام، کشیدن و رها کردن برای ترتیب، و حالت‌های سریع مغازه / خدمات / شخصی / اقساطی."],
  ["💰", "عدد، ریال و تومان", "جداکننده‌ی هزارگان زنده هنگام تایپ (۱٬۲۳۴٬۵۶۷)، ارقام فارسی، سوییچ ریال ↔ تومان با تبدیل اختیاری ×۱۰ / ÷۱۰."],
  ["🧾", "اقساط و جمع هوشمند", "تعداد + مبلغ هر قسط + پرداخت‌شده ← مانده‌ی خودکار. نوار جمع پایین فقط موارد مرتبط را نشان می‌دهد."],
  ["💾", "پشتیبان و بازیابی", "پشتیبان کامل JSON و ZIP (با پایگاه داده) از طریق Storage Access Framework، خروجی CSV برای اکسل و بازیابی با تأیید."],
  ["🛡️", "قفل رمز و اثر انگشت", "قفل ۴ تا ۸ رقمی با هش نمکی و Biometric؛ حذف کامل داده با تأیید قوی و یادآوری پشتیبان."],
  ["📖", "راهنمای کامل", "معرفی ۴ صفحه‌ای و راهنمای دائمی با توضیح هر ستون و نکته‌هایی برای هر شغل."],
  ["📴", "کاملاً آفلاین", "بدون مجوز اینترنت. Room + DataStore؛ داده با بستن اپ، Force Stop و ریبوت از بین نمی‌رود."],
  ["✨", "ظاهر شیشه‌ای ۳بعدی", "کارت‌های Glass، سایه‌های چندلایه (۲/۶/۱۲dp)، بلور واقعی در API 31+ و پالت گرم کهربایی، تم روشن و تاریک."],
  ["⚡", "حداکثر کارایی", "R8 + shrinkResources، Baseline Profile، LazyColumn با key/contentType، کوئری‌های ایندکس‌دار و minSdk 21."],
] as const;

const days = Array.from({ length: 30 }, (_, i) => i + 1);

const Code = ({ children }: { children: string }) => (
  <pre dir="ltr" className="overflow-x-auto rounded-2xl bg-[#2b2016] p-4 text-left text-sm leading-7 text-[#f6ebdd]">
    <code>{children}</code>
  </pre>
);

function PhoneMock() {
  return (
    <div className="relative mx-auto w-[290px] rounded-[42px] border-[8px] border-[#3b2a1a] bg-[#fff8ec] p-3 shadow-[0_30px_60px_rgba(59,42,26,0.35)]">
      <div className="mb-3 flex items-center gap-2">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/app-logo.svg" alt="Lax-1819" className="h-10 w-10" />
        <div>
          <div className="text-sm font-bold">Lax-1819</div>
          <div className="text-[10px] text-[#6b5440]">دفتر روزانه‌ی هوشمند و ساده</div>
        </div>
      </div>
      <div className="glass p-3">
        <div className="mb-2 text-center text-sm font-bold">مهر {fa(1404)}</div>
        <div className="grid grid-cols-7 gap-1 text-center text-[10px]">
          {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d, i) => (
            <div key={d} className={i === 6 ? "text-red-700" : "text-[#6b5440]"}>
              {d}
            </div>
          ))}
          {days.map((d) => (
            <div
              key={d}
              className={`rounded-lg py-1 ${d === 15 ? "gradient-btn !rounded-lg !shadow-none" : ""} ${(d + 1) % 7 === 0 && d !== 15 ? "text-red-700" : ""}`}
            >
              {fa(d)}
            </div>
          ))}
        </div>
      </div>
      <div className="glass mt-3 border-r-[6px] !border-r-[#2e9e5b] p-3 text-xs">
        <div className="flex justify-between"><span className="text-[#6b5440]">نام کامل</span><b>آقای رضایی</b></div>
        <div className="flex justify-between"><span className="text-[#6b5440]">محصول</span><b>برنج ایرانی</b></div>
        <div className="flex justify-between"><span className="text-[#6b5440]">هزینه</span><b>{fa("1٬250٬000")} تومان</b></div>
      </div>
      <div className="glass mt-3 flex justify-around p-2 text-center text-[10px]">
        <div><div className="text-[#6b5440]">تعداد</div><b className="text-sm">{fa(3)}</b></div>
        <div><div className="text-[#6b5440]">جمع هزینه</div><b className="text-sm">{fa("2٬430٬000")}</b></div>
        <div><div className="text-[#6b5440]">بیعانه</div><b className="text-sm">{fa("500٬000")}</b></div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <main className="relative overflow-hidden">
      <div className="blob -top-20 -right-20 h-96 w-96 bg-[#ffb74d]" />
      <div className="blob top-[60%] -left-24 h-96 w-96 bg-[#ff8a65]" />

      {/* Hero */}
      <section className="relative mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-2">
        <div>
          <div className="mb-4 flex flex-wrap gap-2 text-xs font-bold">
            {["minSdk 21 (Android 5.0+)", "MIT License", `v${fa("1.0.0")}`, "Kotlin + Compose + Material 3"].map((b) => (
              <span key={b} className="glass !rounded-full px-3 py-1" dir="ltr">{b}</span>
            ))}
          </div>
          <h1 className="text-4xl font-bold leading-tight md:text-5xl">
            Lax-1819
            <span className="block text-2xl text-[#9a5b00] md:text-3xl">دفتر روزانه‌ی جلالی، ساده و کاملاً آفلاین</span>
          </h1>
          <p className="mt-5 text-lg leading-8 text-[#6b5440]">
            برای هر روز، یک یا چند برگه‌ی مستقل با ستون‌های کاملاً قابل تنظیم؛ مناسب مغازه‌دار، آرایشگاه و کلینیک، تعمیرکار،
            فروش اقساطی، کالای دارای انقضا و هزینه‌های شخصی. پروژه‌ی کامل Android Studio آماده‌ی ساخت است.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="/downloads/Lax-1819.zip" download className="gradient-btn px-7 py-4 text-lg">
              ⬇ دانلود پروژه‌ی کامل (ZIP)
            </a>
            <a href="#build" className="glass px-7 py-4 text-lg font-bold">ساخت و انتشار</a>
          </div>
          <p className="mt-4 text-sm text-[#6b5440]">طراحی و توسعه: <b>mohamadreza.lak</b> · مجوز MIT · Copyright © ۲۰۲۵</p>
        </div>
        <PhoneMock />
      </section>

      {/* Features */}
      <section className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="mb-6 text-2xl font-bold">امکانات</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(([icon, title, body]) => (
            <div key={title} className="glass p-5">
              <div className="mb-2 text-3xl">{icon}</div>
              <h3 className="mb-1 text-lg font-bold">{title}</h3>
              <p className="text-sm leading-7 text-[#6b5440]">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Architecture */}
      <section className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="mb-6 text-2xl font-bold">معماری و کتابخانه‌ها</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="glass p-5 text-sm leading-8">
            <ul className="list-disc space-y-1 pr-5">
              <li>Jetpack Compose + Material 3، MVVM + Repository + Flow/StateFlow</li>
              <li>Hilt (KSP)، Navigation Compose، Room، DataStore، kotlinx.serialization</li>
              <li><b>تقویم جلالی:</b> هسته‌ی خالص Kotlin در <code dir="ltr">util/Jalali.kt</code> (پورت الگوریتم jalaali-js، MIT) – بدون وابستگی، سازگار با API 21، تست‌شده با تاریخ‌های مرجع</li>
              <li>جداکننده‌ی هزارگان: <code dir="ltr">VisualTransformation</code> با نگاشت دقیق مکان‌نما</li>
              <li>کشیدن و رها کردن ستون‌ها: Reorderable (Calvin-LL)</li>
              <li>فونت وزیرمتن (OFL) داخل برنامه</li>
            </ul>
          </div>
          <div className="glass p-5 text-sm leading-8">
            <ul className="list-disc space-y-1 pr-5">
              <li>R8 کامل: <code dir="ltr">minifyEnabled + shrinkResources</code></li>
              <li>Baseline Profile + ProfileInstaller برای استارت سریع‌تر</li>
              <li>LazyColumn با <code dir="ltr">key</code> و <code dir="ltr">contentType</code>، انیمیشن‌های فنری، <code dir="ltr">animateItem</code></li>
              <li>همه‌ی کارهای دیتابیس خارج از Main Thread؛ کوئری‌های ایندکس‌دار</li>
              <li>بلور واقعی با <code dir="ltr">RenderEffect</code> در API 31+ و جایگزین گرادیان/آلفا/سایه در نسخه‌های قدیمی</li>
              <li>بدون مجوز اینترنت، بدون ردیابی، بازیابی پس از Process Death</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Build */}
      <section id="build" className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="mb-6 text-2xl font-bold">ساخت APK امضاشده (Release)</h2>
        <div className="glass space-y-3 p-6 leading-8">
          <ol className="list-decimal space-y-2 pr-5">
            <li>پروژه را در <b>Android Studio</b> (Ladybug یا جدیدتر، JDK 17) باز کنید و Gradle Sync را اجرا کنید.</li>
            <li>منوی <b dir="ltr">Build → Generate Signed Bundle / APK…</b> را بزنید و <b>APK</b> را انتخاب کنید.</li>
            <li>با <b dir="ltr">Create new…</b> یک Keystore بسازید (مسیر، رمز، alias، اعتبار ۲۵ سال) و Next را بزنید.</li>
            <li>نوع ساخت <b dir="ltr">release</b> و تیک‌های V1 و V2 را انتخاب کنید و Finish را بزنید.</li>
            <li>خروجی در <code dir="ltr">app/release/app-release.apk</code> است. Keystore را حتماً پشتیبان بگیرید.</li>
          </ol>
          <p className="text-sm text-[#6b5440]">ساخت از ترمینال: فایل <code dir="ltr">keystore.properties</code> را در ریشه بسازید (در .gitignore است) و اجرا کنید:</p>
          <Code>{`# keystore.properties
storeFile=my-release-key.jks
storePassword=******
keyAlias=lax1819
keyPassword=******

./gradlew assembleRelease   # APK
./gradlew bundleRelease     # AAB`}</Code>
        </div>
      </section>

      {/* GitHub */}
      <section className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="mb-6 text-2xl font-bold">انتشار در GitHub (مخزن Lax-1819)</h2>
        <div className="glass space-y-3 p-6">
          <p className="leading-8">در GitHub یک مخزن خالی با نام <b dir="ltr">Lax-1819</b> بسازید (بدون README و License؛ هر دو داخل پروژه هست)، سپس:</p>
          <Code>{`cd Lax-1819
git init
git add .
git commit -m "Lax-1819 v1.0.0 - initial release (MIT)"
git branch -M main
git remote add origin https://github.com/<USERNAME>/Lax-1819.git
git push -u origin main
git tag v1.0.0 && git push origin v1.0.0`}</Code>
          <p className="text-sm leading-7 text-[#6b5440]">
            فایل LICENSE (MIT، Copyright © 2025 mohamadreza.lak) در ریشه است و GitHub آن را خودکار نمایش می‌دهد. APK امضاشده را از
            Releases ← Draft a new release پیوست کنید. پیش از انتشار، ایمیل/تلگرام/آدرس GitHub را در <code dir="ltr">AppInfo.kt</code> به‌روز کنید.
          </p>
        </div>
      </section>

      {/* Checklist */}
      <section className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="mb-6 text-2xl font-bold">تأییدیه‌ی نهایی</h2>
        <div className="glass grid gap-2 p-6 text-sm leading-7 sm:grid-cols-2">
          {[
            "minSdk 21 (Android 5.0) و targetSdk/compileSdk 35",
            "مجوز MIT – فایل LICENSE، README، صفحه‌ی درباره و تنظیمات",
            "طراح و توسعه‌دهنده: mohamadreza.lak در همه‌ی بخش‌ها",
            "ماندگاری کامل داده با Room + DataStore (بدون هیچ مجوز شبکه)",
            "ستون‌ها: قفل، تغییر نام، پنهان، جابه‌جایی و ستون سفارشی",
            "جداکننده‌ی هزارگان زنده + ریال/تومان با تبدیل اختیاری",
            "جلالی، راست‌به‌چپ و فارسی کامل با ارقام فارسی",
            "آفلاین ۱۰۰٪؛ R8، Baseline Profile و بهینه‌سازی Compose",
            "ظاهر شیشه‌ای مدرن با عمق سه‌بعدی و پالت گرم",
          ].map((t) => (
            <div key={t} className="flex gap-2"><span>✅</span><span>{t}</span></div>
          ))}
        </div>
        <p className="mt-4 rounded-2xl bg-[#fff0b3] p-4 text-sm leading-7">
          نکته‌ی صادقانه: این پروژه در محیط ابری بدون Android SDK نوشته شد، بنابراین کامپایل نهایی با Gradle در این محیط انجام نشده است. منطق تقویم جلالی با تست عددی
          و منابع/رشته‌ها با اسکریپت بررسی شده‌اند. اولین Sync در Android Studio را اجرا کنید؛ در صورت هر هشدار نسخه‌ای، Android Studio راه‌حل پیشنهاد می‌دهد.
        </p>
      </section>

      <footer className="relative border-t border-[#e6d3b8] py-8 text-center text-sm text-[#6b5440]">
        <p>Lax-1819 · طراحی و توسعه: <b>mohamadreza.lak</b> · <a className="underline" href="/downloads/Lax-1819.zip">دانلود ZIP</a> · MIT License</p>
      </footer>
    </main>
  );
}
