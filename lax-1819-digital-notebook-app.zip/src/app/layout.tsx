import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lax-1819 | دفتر روزانه‌ی جلالی – پروژه‌ی اندروید",
  description:
    "Lax-1819: اپلیکیشن اندروید آفلاین و منبع‌باز (MIT) با Kotlin + Jetpack Compose برای ثبت روزانه با تقویم جلالی. طراحی و توسعه: mohamadreza.lak",
  icons: { icon: "/app-logo.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
