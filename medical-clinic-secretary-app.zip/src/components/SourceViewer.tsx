import { useMemo, useState } from "react";

// Pull every Android project file in as raw text at build time
const files = import.meta.glob("/android-app/**/*.{kt,kts,xml,properties,md}", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

export default function SourceViewer() {
  const paths = useMemo(
    () => Object.keys(files).map((p) => p.replace("/android-app/", "")).sort(),
    []
  );
  const [current, setCurrent] = useState(paths.find((p) => p === "README.md") ?? paths[0]);
  const [copied, setCopied] = useState(false);
  const content = files["/android-app/" + current] ?? "";

  const copy = async () => {
    await navigator.clipboard?.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="mx-auto max-w-6xl p-4">
      <h2 className="text-xl font-bold text-blue-700">کد پروژه اندروید (Kotlin + Room)</h2>
      <p className="mb-3 text-sm text-slate-600">
        پوشهٔ <code dir="ltr">android-app</code> را در Android Studio باز کنید. فایل‌های پروژه:
      </p>
      <div className="grid gap-4 md:grid-cols-[320px_1fr]">
        <ul dir="ltr" className="max-h-[60vh] overflow-auto rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs">
          {paths.map((p) => (
            <li key={p}>
              <button
                onClick={() => setCurrent(p)}
                className={`w-full rounded px-2 py-1.5 text-left font-mono ${
                  p === current ? "bg-blue-700 text-white" : "hover:bg-blue-100"
                }`}
              >
                {p}
              </button>
            </li>
          ))}
        </ul>
        <div className="min-w-0 rounded-xl border border-slate-200">
          <div dir="ltr" className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-3 py-2">
            <span className="truncate font-mono text-xs">{current}</span>
            <button onClick={copy} className="rounded-lg bg-blue-700 px-3 py-1 text-xs text-white">
              {copied ? "Copied ✓" : "Copy"}
            </button>
          </div>
          <pre dir="ltr" className="max-h-[60vh] overflow-auto bg-slate-900 p-4 text-left text-xs leading-relaxed text-slate-100">
            <code>{content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
