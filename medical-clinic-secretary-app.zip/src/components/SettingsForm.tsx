import { useState } from "react";
import { AppSettings, parseNumber } from "../lib/store";

const input =
  "w-full min-h-14 rounded-xl border border-slate-300 bg-white px-4 text-lg outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-200";

export default function SettingsForm({
  settings,
  onSave,
}: {
  settings: AppSettings;
  onSave: (s: AppSettings) => void;
}) {
  const [name, setName] = useState(settings.doctorName);
  const [spec, setSpec] = useState(settings.specialty);
  const [fee, setFee] = useState(String(settings.defaultFee));
  const [saved, setSaved] = useState(false);

  return (
    <form
      className="mx-auto max-w-xl space-y-5 p-4"
      onSubmit={(e) => {
        e.preventDefault();
        onSave({ doctorName: name.trim(), specialty: spec.trim(), defaultFee: parseNumber(fee) ?? 0 });
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }}
    >
      <h2 className="text-xl font-bold text-blue-700">تنظیمات</h2>
      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">نام پزشک</span>
        <input className={input} value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">تخصص پزشک</span>
        <input className={input} value={spec} onChange={(e) => setSpec(e.target.value)} />
      </label>
      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">مبلغ پیش‌فرض ویزیت</span>
        <input inputMode="numeric" dir="ltr" className={input + " text-center"} value={fee} onChange={(e) => setFee(e.target.value)} />
      </label>
      <button type="submit" className="h-16 w-full rounded-xl bg-blue-700 text-lg font-bold text-white shadow active:bg-blue-800">
        ذخیره تنظیمات
      </button>
      {saved && <p className="text-center font-semibold text-green-600">تنظیمات ذخیره شد</p>}
    </form>
  );
}
