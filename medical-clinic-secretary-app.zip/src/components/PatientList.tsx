import { useState } from "react";
import { COLUMNS, ColumnKey, Patient, faDigits, money, useLocal } from "../lib/store";

// Grid column widths, same idea as the weights in the Android layouts
const WIDTH: Record<ColumnKey, string> = {
  name: "minmax(110px,2fr)",
  insurance: "minmax(90px,1.6fr)",
  supp: "minmax(60px,1.2fr)",
  reason: "minmax(140px,2.4fr)",
  time: "minmax(60px,1fr)",
  date: "minmax(90px,1.6fr)",
  fee: "minmax(90px,1.6fr)",
};

export default function PatientList({
  patients,
  onDelete,
}: {
  patients: Patient[];
  onDelete: (id: number) => void;
}) {
  // Visible columns are remembered (SharedPreferences on Android)
  const [visible, setVisible] = useLocal<ColumnKey[]>(
    "visibleColumns",
    COLUMNS.map((c) => c.key)
  );
  const [selected, setSelected] = useState<Patient | null>(null);

  const cols = COLUMNS.filter((c) => visible.includes(c.key));
  const template = cols.map((c) => WIDTH[c.key]).join(" ");
  const toggle = (k: ColumnKey) =>
    setVisible((v) => (v.includes(k) ? v.filter((x) => x !== k) : [...v, k]));

  const cell = (p: Patient, k: ColumnKey) => {
    switch (k) {
      case "name": return <b>{p.name}</b>;
      case "insurance": return p.insuranceType;
      case "supp": return p.hasSupplemental ? "دارد" : "ندارد";
      case "reason": return p.reason || "—";
      case "time": return faDigits(p.visitTime);
      case "date": return faDigits(p.visitDate);
      case "fee": return money(p.fee);
    }
  };

  return (
    <div className="mx-auto max-w-5xl">
      <div className="px-4 pt-3 text-sm text-slate-600">ستون‌های نمایش:</div>
      <div className="flex gap-2 overflow-x-auto px-3 py-2">
        {COLUMNS.map((c) => {
          const on = visible.includes(c.key);
          return (
            <button
              key={c.key}
              onClick={() => toggle(c.key)}
              className={`h-12 shrink-0 rounded-full border px-5 text-base ${
                on ? "border-blue-700 bg-blue-100 font-semibold text-blue-800" : "border-slate-300 bg-white text-slate-500"
              }`}
            >
              {on && "✓ "}
              {c.label}
            </button>
          );
        })}
      </div>

      <div className="p-3 font-bold text-blue-700">
        تعداد بیماران: {faDigits(patients.length)} &nbsp;|&nbsp; جمع مبلغ:{" "}
        {money(patients.reduce((s, p) => s + p.fee, 0))}
      </div>

      <div className="grid bg-blue-50 px-2 py-3 text-sm font-bold text-blue-700" style={{ gridTemplateColumns: template }}>
        {cols.map((c) => (
          <div key={c.key} className="px-1">{c.label}</div>
        ))}
      </div>

      {patients.length === 0 && (
        <div className="py-16 text-center text-lg text-slate-500">هنوز بیماری ثبت نشده است</div>
      )}

      {patients.map((p) => (
        <button
          key={p.id}
          onClick={() => setSelected(p)}
          className="grid min-h-14 w-full border-b border-slate-200 px-2 py-3 text-start text-sm hover:bg-blue-50 active:bg-blue-100"
          style={{ gridTemplateColumns: template }}
        >
          {cols.map((c) => (
            <div key={c.key} className="px-1 break-words">{cell(p, c.key)}</div>
          ))}
        </button>
      ))}

      {selected && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/40 p-4" onClick={() => setSelected(null)}>
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-3 text-xl font-bold">{selected.name}</h3>
            <dl className="space-y-1 text-base text-slate-700">
              <div>بیمه: {selected.insuranceType}</div>
              <div>مکمل: {selected.hasSupplemental ? "دارد" : "ندارد"}</div>
              <div>علت مراجعه: {selected.reason || "—"}</div>
              <div>ساعت: {faDigits(selected.visitTime)}</div>
              <div>تاریخ: {faDigits(selected.visitDate)}</div>
              <div>مبلغ: {money(selected.fee)}</div>
            </dl>
            <div className="mt-5 flex gap-3">
              <button className="h-12 flex-1 rounded-xl bg-blue-700 font-bold text-white" onClick={() => setSelected(null)}>
                بستن
              </button>
              <button
                className="h-12 flex-1 rounded-xl border border-red-300 font-bold text-red-600"
                onClick={() => {
                  if (confirm("این بیمار حذف شود؟")) {
                    onDelete(selected.id);
                    setSelected(null);
                  }
                }}
              >
                حذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
