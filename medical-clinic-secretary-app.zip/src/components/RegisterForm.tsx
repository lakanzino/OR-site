import { useState } from "react";
import {
  AppSettings, INSURANCE_TYPES, Patient, nowTime, parseNumber, persianToday,
} from "../lib/store";

const input =
  "w-full min-h-14 rounded-xl border border-slate-300 bg-white px-4 text-lg outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-200";

export default function RegisterForm({
  settings,
  onSave,
}: {
  settings: AppSettings;
  onSave: (p: Omit<Patient, "id">) => void;
}) {
  const [name, setName] = useState("");
  const [insurance, setInsurance] = useState(INSURANCE_TYPES[0]);
  const [supp, setSupp] = useState(false);
  const [reason, setReason] = useState("");
  const [time, setTime] = useState(nowTime());
  const [fee, setFee] = useState(String(settings.defaultFee));
  const [error, setError] = useState("");
  const [toast, setToast] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("نام بیمار الزامی است");
      return;
    }
    setError("");
    onSave({
      name: name.trim(),
      insuranceType: insurance,
      hasSupplemental: supp,
      reason: reason.trim(),
      visitTime: time,
      visitDate: persianToday().short,
      fee: parseNumber(fee) ?? settings.defaultFee,
    });
    // Clear the form for the next patient
    setName("");
    setInsurance(INSURANCE_TYPES[0]);
    setSupp(false);
    setReason("");
    setTime(nowTime());
    setFee(String(settings.defaultFee));
    setToast(true);
    setTimeout(() => setToast(false), 2000);
  };

  return (
    <form onSubmit={submit} className="mx-auto max-w-xl space-y-5 p-4">
      <h2 className="text-xl font-bold text-blue-700">ثبت بیمار جدید</h2>

      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">نام بیمار *</span>
        <input
          className={input + (error ? " !border-red-500" : "")}
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        {error && <span className="mt-1 block text-sm text-red-600">{error}</span>}
      </label>

      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">نوع بیمه</span>
        <select className={input} value={insurance} onChange={(e) => setInsurance(e.target.value)}>
          {INSURANCE_TYPES.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </label>

      <label className="flex min-h-14 cursor-pointer items-center gap-3 text-lg">
        <input
          type="checkbox"
          className="size-6 accent-blue-700"
          checked={supp}
          onChange={(e) => setSupp(e.target.checked)}
        />
        بیمه مکمل
      </label>

      <label className="block">
        <span className="mb-1 block text-sm text-slate-600">علت مراجعه</span>
        <textarea
          rows={3}
          className={input + " py-3"}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        />
      </label>

      <div className="grid grid-cols-2 gap-4">
        <label className="block">
          <span className="mb-1 block text-sm text-slate-600">ساعت مراجعه</span>
          <input type="time" dir="ltr" className={input + " text-center"} value={time} onChange={(e) => setTime(e.target.value)} />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm text-slate-600">مبلغ ویزیت</span>
          <input
            inputMode="numeric"
            dir="ltr"
            className={input + " text-center"}
            value={fee}
            onChange={(e) => setFee(e.target.value)}
          />
        </label>
      </div>

      <button
        type="submit"
        className="h-16 w-full rounded-xl bg-blue-700 text-lg font-bold text-white shadow active:bg-blue-800"
      >
        ذخیره بیمار
      </button>

      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 rounded-full bg-slate-800 px-6 py-3 text-white shadow-lg">
          بیمار با موفقیت ثبت شد
        </div>
      )}
    </form>
  );
}
