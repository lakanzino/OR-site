import { useEffect, useState } from "react";
import RegisterForm from "./components/RegisterForm";
import PatientList from "./components/PatientList";
import SettingsForm from "./components/SettingsForm";
import SourceViewer from "./components/SourceViewer";
import { AppSettings, DEFAULT_SETTINGS, persianToday, useLocal, usePatients } from "./lib/store";

type Tab = "register" | "patients" | "settings" | "source";

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: "register", label: "ثبت بیمار", icon: "＋" },
  { key: "patients", label: "لیست بیماران", icon: "☰" },
  { key: "settings", label: "تنظیمات", icon: "⚙" },
  { key: "source", label: "کد اندروید", icon: "</>" },
];

export default function App() {
  const [tab, setTab] = useState<Tab>("register");
  const [settings, setSettings] = useLocal<AppSettings>("settings", DEFAULT_SETTINGS);
  const { patients, add, remove } = usePatients();
  const [date, setDate] = useState(persianToday().long);

  // Keep the date fresh (midnight rollover)
  useEffect(() => {
    const t = setInterval(() => setDate(persianToday().long), 60_000);
    return () => clearInterval(t);
  }, []);

  return (
    <div dir="rtl" className="flex min-h-screen flex-col bg-white text-slate-900" style={{ fontFamily: "Vazirmatn, Tahoma, 'Segoe UI', sans-serif" }}>
      {/* Header: doctor name, specialty, Shamsi date */}
      <header className="bg-blue-700 p-4 text-white">
        <div className="mx-auto max-w-5xl">
          <div className="text-2xl font-bold">{settings.doctorName}</div>
          <div className="text-blue-100">{settings.specialty}</div>
          <div className="mt-2">{date}</div>
        </div>
      </header>

      <main className="flex-1 pb-24">
        {tab === "register" && <RegisterForm key={settings.defaultFee} settings={settings} onSave={add} />}
        {tab === "patients" && <PatientList patients={patients} onDelete={remove} />}
        {tab === "settings" && <SettingsForm settings={settings} onSave={setSettings} />}
        {tab === "source" && <SourceViewer />}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-10 flex border-t border-slate-200 bg-white">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex h-16 flex-1 flex-col items-center justify-center gap-0.5 text-sm ${
              tab === t.key ? "font-bold text-blue-700" : "text-slate-500"
            }`}
          >
            <span className={`rounded-full px-5 py-0.5 text-lg leading-6 ${tab === t.key ? "bg-blue-100" : ""}`} dir="ltr">
              {t.icon}
            </span>
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
