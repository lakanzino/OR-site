import { useCallback, useEffect, useState } from "react";

/** Same data model as the Android Room entities. */
export interface Patient {
  id: number;
  name: string;
  insuranceType: string;
  hasSupplemental: boolean;
  reason: string;
  visitTime: string; // "14:30"
  visitDate: string; // Shamsi "1403/05/12"
  fee: number;
}

export interface AppSettings {
  doctorName: string;
  specialty: string;
  defaultFee: number;
}

export const INSURANCE_TYPES = ["تامین اجتماعی", "خدمات درمانی", "آزاد", "سایر"];

export const COLUMNS = [
  { key: "name", label: "نام" },
  { key: "insurance", label: "بیمه" },
  { key: "supp", label: "مکمل" },
  { key: "reason", label: "علت مراجعه" },
  { key: "time", label: "ساعت" },
  { key: "date", label: "تاریخ" },
  { key: "fee", label: "مبلغ" },
] as const;
export type ColumnKey = (typeof COLUMNS)[number]["key"];

const FA = "۰۱۲۳۴۵۶۷۸۹";
export const faDigits = (s: string | number) =>
  String(s).replace(/[0-9]/g, (d) => FA[Number(d)]);

export const normalizeDigits = (s: string) =>
  s
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));

export const parseNumber = (s: string): number | null => {
  const n = normalizeDigits(s).replace(/\D/g, "");
  return n ? Number(n) : null;
};

export const money = (n: number) => faDigits(n.toLocaleString("en-US")).replace(/,/g, "٬");

/** Gregorian -> Shamsi (same algorithm as android-app/util/PersianDate.kt). */
const WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

export function persianToday(d = new Date()) {
  const gy = d.getFullYear();
  const gm = d.getMonth() + 1;
  const gd = d.getDate();
  const cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days =
    355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) + gd + cum[gm - 1];
  let jy = -1595 + 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  const weekday = WEEKDAYS[d.getDay()];
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    short: `${jy}/${pad(jm)}/${pad(jd)}`,
    long: `${weekday} ${faDigits(jd)} ${MONTHS[jm - 1]} ${faDigits(jy)}`,
  };
}

export const nowTime = () => {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

/** useState that persists to localStorage (stands in for SQLite/Room in the web preview). */
export function useLocal<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);
  return [value, setValue] as const;
}

export const DEFAULT_SETTINGS: AppSettings = {
  doctorName: "دکتر مریم احمدی",
  specialty: "متخصص داخلی",
  defaultFee: 300000,
};

export function usePatients() {
  const [patients, setPatients] = useLocal<Patient[]>("patients", []);
  const add = useCallback(
    (p: Omit<Patient, "id">) =>
      setPatients((list) => [{ ...p, id: (list[0]?.id ?? 0) + 1 }, ...list]),
    [setPatients]
  );
  const remove = useCallback(
    (id: number) => setPatients((list) => list.filter((p) => p.id !== id)),
    [setPatients]
  );
  return { patients, add, remove };
}
