const features = [
  "کاملاً مستقل؛ بازنویسی یا جایگزینی هیچ افزونهٔ موجودی انجام نشده است",
  "فارسی، راست‌به‌چپ، تاریخ شمسی (تبدیل داخلی بدون وابستگی) و منطقهٔ زمانی وردپرس",
  "سازگار با PHP ۸.۱ تا ۸.۴، وردپرس ۶+ و MariaDB/InnoDB؛ رابط موبایل تک‌ستونی و لمسی",
  "بدون وابستگی به ACF (رایگان/Pro)، درگاه پرداخت یا پیامک",
  "پیشوند اختصاصی hsb_ برای همهٔ جداول، توابع، کلاس‌ها و تنظیمات",
  "غیرفعال‌سازی داده را حفظ می‌کند؛ حذف فقط با تصمیم صریح مدیر هنگام uninstall",
];

const security = [
  {
    title: "رزرو امن در برابر هم‌زمانی",
    body: "تراکنش InnoDB + قفل SELECT … FOR UPDATE روی ردیفِ برنامهٔ همان پزشک/روز هفته (نقطهٔ سریال‌سازی مشترک)، بازبینی ظرفیت پس از گرفتن قفل، سپس درج. ROLLBACK در هر خطا؛ تلاش مجدد خودکار تا ۳ بار روی deadlock و قطعی اتصال MariaDB؛ نوشتن خارج از قفل/تراکنش هرگز رخ نمی‌دهد.",
  },
  {
    title: "تکرار امن درخواست (Idempotency)",
    body: "برای هر تلاش رزرو یک UUID از سمت مرورگر ساخته و در ستون یکتای idempotency_key ذخیره می‌شود؛ اگر پاسخ ثبت به کاربر نرسد، تلاش دوباره همان نوبت را برمی‌گرداند و نوبت تکراری نمی‌سازد. اگر نتیجهٔ COMMIT نامعلوم باشد، پاسخ صادقانهٔ «نامشخص» داده می‌شود — نه موفقیت کاذب.",
  },
  {
    title: "حریم خصوصی",
    body: "تقویم عمومی فقط «ظرفیت و زمان» را نشان می‌دهد؛ نام، موبایل، کد ملی و توضیح بیمار هرگز در URL، کوکی، حافظهٔ عمومی مرورگر، کش عمومی یا لاگ ذخیره نمی‌شود. دسترسی به دادهٔ بیمار فقط برای خود بیمار، پزشک/منشیِ مجازِ همان پزشک و مدیر است.",
  },
  {
    title: "کنترل‌های استاندارد وردپرس",
    body: "nonce در تمام عملیات REST، $wpdb->prepare برای همهٔ پرس‌وجوها، پاک‌سازی ورودی، escape خروجی، بررسی مالکیت و نقش سمت سرور، و محدودیت نرخ (پیش‌فرض ۱۰ ثبت نوبت در ساعت برای هر کاربر/IP).",
  },
];

const statuses = [
  ["requested", "در انتظار تأیید مطب", "درخواست ثبت شد؛ نوبت هنوز نهایی نیست"],
  ["confirmed", "تأییدشده", "مطب نوبت را تأیید کرده است"],
  ["cancelled_patient", "لغوشده توسط بیمار", "طبق سیاست لغو (پیش‌فرض ۲۴ ساعت)"],
  ["cancelled_clinic", "لغوشده توسط مطب", "—"],
  ["completed", "انجام‌شده", "—"],
  ["no_show", "عدم مراجعه", "—"],
];

const tables = [
  ["hsb_schedules", "برنامهٔ هفتگی هر پزشک؛ یک ردیف یکتا به‌ازای هر پزشک+روز هفته (۰=شنبه … ۶=جمعه) — همان ردیفی که برای قفل تراکنشی استفاده می‌شود. طول بازه پیش‌فرض ۳۰ دقیقه و ظرفیت پیش‌فرض ۱."],
  ["hsb_overrides", "استثنای یک تاریخ مشخص: تعطیلی کامل یا ساعت/ظرفیت خاص + دلیل (مثلاً مرخصی، تعطیلی رسمی، تغییر موقت ساعت)."],
  ["hsb_appointments", "نوبت‌ها: کد پیگیری یکتا و غیرقابل‌حدس (CSPRNG)، دادهٔ بیمار، نوع خدمت (مشاوره/ویزیت/جراحی)، تاریخ/ساعت، وضعیت، idempotency_key یکتا."],
];

const testsPassed = [
  "تبدیل جلالی↔میلادی (از جمله چرخهٔ کبیسهٔ ۳۳ ساله) و نام روزهای هفته",
  "اعتبارسنجی موبایل (قالب فارسی/بین‌المللی)، کد ملی با رقم کنترل، حد ۵۰۰ نویسه‌ای توضیح، نوع خدمت",
  "ساخت بازه‌ها، ترکیب برنامه با استثنای تعطیل/ساعت خاص، وضعیت روز با برچسب‌های مجزا (تعطیل ≠ تکمیل؛ ۱–۳ زرد؛ >۳ سبز)",
  "ثبت موفق نوبت + اثبات ترتیب «قفل برنامهٔ پزشک قبل از شمارش ظرفیت»",
  "آخرین جای خالی: دومین درخواست روی بازهٔ ظرفیتِ ۱ رد می‌شود (slot_full)",
  "تکرار امن: همان Idempotency-Key نوبت تکراری نمی‌سازد و همان کد پیگیری برمی‌گردد",
  "deadlock: تراکنش به‌صورت خودکار تکرار و با موفقیت کامیت می‌شود",
  "شکست COMMIT: پاسخ «نامعلوم» صادقانه گزارش می‌شود، نه موفقیت کاذب",
  "لغو توسط بیمار (موفق)؛ لغو دوباره (رد)؛ لغو توسط دیگری (forbidden)؛ مهلت لغو پس از سررسید (رد)",
  "روز تعطیل (override) قابل رزرو نیست؛ ورودی‌های نامعتبر رد می‌شوند",
  "تقویم عمومی: ۱۴ روز تولید می‌شود و هیچ کلید دادهٔ بیماری در پاسخ نیست",
];

const notTested = [
  "هم‌زمانی واقعی چند فرایند HTTP روی MariaDB (اینجا با wpdb تقلبی و سناریوهای رقابتی آزموده شد — تست نهایی باید روی استیجینگ با apachebench/JMeter انجام شود)",
  "تست مرورگر و موبایل واقعی روی قالب نهایی سایت",
  "ورود با Googleِ Nextend — بدون آزمایش واقعی ادعای تست نمی‌کنیم؛ طراحی فقط به صفحهٔ ورود وردپرس وابسته است",
  "ارسال واقعی ایمیل — پیش‌فرض خاموش است و دکمهٔ «تست واقعی ارسال» در تنظیمات قرار دارد",
  "چرخهٔ نصب/فعال‌سازی روی وردپرس واقعی (ساختار استاندارد و readme.txt رعایت شده)",
];

const questions = [
  "رابطهٔ حساب کاربری با پروفایل پزشک دقیقاً کجا نگهداری می‌شود؟ (post_author یا نام دقیق کلید متا)",
  "نام دقیق post type پزشک‌ها چیست؟ (پیش‌فرض فرض‌شده: doctor)",
  "آیا یک کاربر ممکن است بیش از یک پروفایل پزشک داشته باشد؟",
  "منشی‌ها چه نقش وردپرسی دارند و آیا به پیشخوان دسترسی دارند؟",
  "آیا لینک فعلی «تماس/واتساپ» در صفحهٔ پزشک باید کنار فرم رزرو بماند؟ (افزونه آن‌ها را دست نمی‌زند)",
];

const roadmap = [
  "شیفت‌های چندگانهٔ روزانه (صبح/عصر جدا) و بافر زمانی بین نوبت‌ها",
  "سقف روزانهٔ مجزا از مجموع ظرفیت بازه‌ها",
  "رزرو مجدد یک‌مرحله‌ای (فعلاً لغو + ثبت جدید)",
  "اتصال درگاه پرداخت برای بیعانه (هوک‌های hsb_appointment_created / hsb_appointment_status_changed آماده‌اند)",
  "پیامک/OTP پس از مشخص‌شدن ارائه‌دهنده",
];

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto w-full max-w-4xl px-5 py-10 sm:px-8">
      <h2 className="mb-6 border-r-4 border-sky-600 pr-4 text-2xl font-extrabold text-slate-900">{title}</h2>
      {children}
    </section>
  );
}

export default function HomePage() {
  return (
    <main className="min-h-screen">
      {/* سربرگ */}
      <header className="border-b border-slate-200 bg-gradient-to-b from-sky-50 to-slate-100">
        <div className="mx-auto flex w-full max-w-4xl flex-col gap-6 px-5 py-14 sm:px-8">
          <div>
            <p className="mb-3 inline-block rounded-full bg-sky-600 px-4 py-1 text-sm font-bold text-white">
              بستهٔ تحویل — نسخهٔ ۱.۰.۰
            </p>
            <h1 className="text-3xl font-black leading-snug text-slate-900 sm:text-4xl">
              افزونهٔ مستقل نوبت‌دهی وردپرس
              <span className="mt-1 block text-sky-700"> برای سایت «همیار جراحی»</span>
            </h1>
            <p className="mt-4 max-w-2xl leading-8 text-slate-600">
              فارسی و راست‌به‌چپ با تاریخ شمسی؛ رزرو امن با تراکنش و قفل ردیف در برابر درخواست‌های
              هم‌زمان؛ کد پیگیری غیرقابل‌حدس؛ بدون هیچ وابستگی به ACF، درگاه پرداخت یا پیامک.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <a
              href="/downloads/hamyar-surgery-booking-1.0.0.zip"
              className="rounded-xl bg-sky-600 px-7 py-4 text-lg font-bold text-white shadow-lg shadow-sky-600/25 transition hover:bg-sky-700"
            >
              دانلود ZIP قابل نصب (نسخهٔ ۱.۰.۰)
            </a>
            <a
              href="/downloads/HSB-GUIDE.fa.md"
              className="rounded-xl border-2 border-sky-600 bg-white px-7 py-4 text-lg font-bold text-sky-700 transition hover:bg-sky-50"
            >
              راهنمای فارسی کامل (Markdown)
            </a>
          </div>
          <ul className="grid gap-2 text-sm text-slate-600 sm:grid-cols-2">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <span className="mt-1.5 inline-block h-2 w-2 shrink-0 rounded-full bg-sky-500" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </header>

      {/* معماری */}
      <Section id="architecture" title="معماری و منبع حقیقت">
        <div className="grid gap-4">
          {tables.map(([name, desc]) => (
            <div key={name} className="rounded-2xl border border-slate-200 bg-white p-5">
              <code className="text-base font-bold text-sky-700" dir="ltr">
                wp_{name}
              </code>
              <p className="mt-2 leading-8 text-slate-600">{desc}</p>
            </div>
          ))}
        </div>
        <p className="mt-5 rounded-xl bg-slate-200/70 p-4 text-sm leading-7 text-slate-700">
          اسکیما با <code dir="ltr">dbDelta()</code> ساخته و با کلید <code dir="ltr">hsb_schema_version</code> نسخه‌بندی
          می‌شود؛ ارتقاها تکرارپذیر و غیرمخرب‌اند. دادهٔ نمایشی ACF هرگز جایگزین برنامه‌های ذخیره‌شده در جداول افزونه
          نمی‌شود.
        </p>
      </Section>

      {/* وضعیت‌ها */}
      <Section id="statuses" title="وضعیت‌های نوبت — بدون ابهام">
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-right text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-500">
                <th className="p-3 font-semibold">وضعیت داخلی</th>
                <th className="p-3 font-semibold">برچسب فارسی</th>
                <th className="p-3 font-semibold">معنا</th>
              </tr>
            </thead>
            <tbody>
              {statuses.map(([key, label, meaning]) => (
                <tr key={key} className="border-t border-slate-100">
                  <td className="p-3">
                    <code dir="ltr" className="rounded bg-slate-100 px-2 py-0.5 text-xs">
                      {key}
                    </code>
                  </td>
                  <td className="p-3 font-bold text-slate-800">{label}</td>
                  <td className="p-3 text-slate-600">{meaning}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-sm text-slate-500">
          «ثبت درخواست» (پاسخ فنی موفق) با «در انتظار تأیید مطب» (وضعیت) و «تأییدشده» هرگز با هم اشتباه نمی‌شوند؛ بیمار
          صریحاً خلاصهٔ نهایی را می‌بیند و تأیید یا انصراف می‌کند.
        </p>
      </Section>

      {/* امنیت */}
      <Section id="security" title="درستی، امنیت و حریم خصوصی">
        <div className="grid gap-4 sm:grid-cols-2">
          {security.map((s) => (
            <div key={s.title} className="rounded-2xl border border-slate-200 bg-white p-5">
              <h3 className="mb-2 font-bold text-slate-900">{s.title}</h3>
              <p className="text-sm leading-7 text-slate-600">{s.body}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* اتصال پزشکان */}
      <Section id="integration" title="اتصال به پزشکان موجود — بدون حدس">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 leading-8 text-slate-600">
          <p>
            افزونه شناسهٔ کاربر را معادل شناسهٔ پروفایل فرض نمی‌کند. از تنظیمات، لایهٔ اتصال را مشخص می‌کنید:
            <b> CPT</b> (post type + رابطهٔ <code dir="ltr">post_author</code> یا کلید متا) یا{" "}
            <b>کاربران با نقش انتخابی</b>. نقش تکراری ساخته نمی‌شود و شورت‌کدها/امکانات فعلی سایت دست نمی‌خورند. اگر
            رزرو داخلی پزشکی غیرفعال باشد، پیام روشن نمایش داده می‌شود و لینک تماس/واتساپ موجود بدون تغییر می‌ماند.
          </p>
          <p className="mt-4 font-bold text-slate-800">پرسش‌های ضروری پیش از پیکربندی نهایی:</p>
          <ul className="mt-2 grid gap-2">
            {questions.map((q) => (
              <li key={q} className="flex items-start gap-2 text-sm">
                <span className="mt-2 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500" />
                <span>{q}</span>
              </li>
            ))}
          </ul>
          <div className="mt-5 rounded-xl bg-sky-50 p-4 text-sm">
            شورت‌کدها: <code dir="ltr">[hsb_booking doctor_id="auto"]</code> (فرم رزرو)،{" "}
            <code dir="ltr">[hsb_my_appointments]</code> (نوبت‌های من + لغو)،{" "}
            <code dir="ltr">[hsb_schedule_manager doctor_id="123"]</code> (مدیریت برنامه برای پزشک/منشی مجاز).
          </div>
        </div>
      </Section>

      {/* تست‌ها */}
      <Section id="tests" title="نتایج آزمایش — ۲۳/۲۳ موفق">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-6">
          <p className="mb-4 text-sm font-bold text-emerald-800">
            تست‌های واحد/یکپارچهٔ منطق با PHP 8.4.23 واقعی اجرا شدند (هارنس tests/run.php داخل بسته):
          </p>
          <ul className="grid gap-2">
            {testsPassed.map((t) => (
              <li key={t} className="flex items-start gap-2 text-sm leading-7 text-emerald-900">
                <span className="mt-2 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-600" />
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-6">
          <p className="mb-4 text-sm font-bold text-amber-800">
            صادقانه انجام‌نشده (نیازمند محیط وردپرس + MariaDB واقعیِ آزمایشی):
          </p>
          <ul className="grid gap-2">
            {notTested.map((t) => (
              <li key={t} className="flex items-start gap-2 text-sm leading-7 text-amber-900">
                <span className="mt-2 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-amber-600" />
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* محدودیت‌ها */}
      <Section id="limits" title="محدودیت‌های آگاهانهٔ نسخهٔ ۱ و مسیر توسعه">
        <ul className="grid gap-2 rounded-2xl border border-slate-200 bg-white p-6">
          {roadmap.map((t) => (
            <li key={t} className="flex items-start gap-2 text-sm leading-7 text-slate-600">
              <span className="mt-2 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-slate-400" />
              <span>{t}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm leading-7 text-slate-500">
          راهنمای کامل نصب، پیکربندی، پشتیبان‌گیری، ارتقا و بازگشت در فایل{" "}
          <code dir="ltr">docs/GUIDE.fa.md</code> داخل بسته (و لینک دانلود بالای صفحه) آمده است. این افزونه بدون
          هماهنگی روی سایت زنده نصب/فعال نشده و هیچ تغییری در داده‌های واقعی نداده است.
        </p>
      </Section>

      <footer className="border-t border-slate-200 py-8 text-center text-xs text-slate-400">
        HSB — hamyar-surgery-booking «1.0.0» | ساخته‌شده برای وردپرس ۶+ / PHP ۸.۴ / MariaDB
      </footer>
    </main>
  );
}
