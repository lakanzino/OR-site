import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "HSB — افزونهٔ نوبت‌دهی همیار جراحی | تحویل نسخهٔ ۱.۰.۰",
  description:
    "افزونهٔ مستقل وردپرس برای نوبت‌دهی فارسی: تاریخ شمسی، ظرفیت‌بندی بازه‌ها، رزرو امن تراکنشی، بدون وابستگی به ACF یا درگاه پرداخت.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
