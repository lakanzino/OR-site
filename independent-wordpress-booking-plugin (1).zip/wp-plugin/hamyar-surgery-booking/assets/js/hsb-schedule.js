/**
 * HSB — ویرایشگر برنامهٔ هفتگی و استثناهای تاریخ (برای پیشخوان و شورت‌کد مدیریت برنامه).
 * ذخیره اتمی سمت سرور است؛ تعارض‌های ناشی از کاهش ظرفیت/تعطیلی به‌صورت هشدار روشن نمایش داده می‌شود.
 */
(function () {
	"use strict";

	var DATA = window.HSB_SCHEDULE || {};

	function el(tag, attrs, children) {
		var node = document.createElement(tag);
		attrs = attrs || {};
		Object.keys(attrs).forEach(function (k) {
			if (k === "text") node.textContent = attrs[k];
			else node.setAttribute(k, attrs[k]);
		});
		(children || []).forEach(function (c) { if (c) node.appendChild(c); });
		return node;
	}

	function api(path, options) {
		options = options || {};
		options.headers = Object.assign({ "X-WP-Nonce": DATA.nonce || "" }, options.headers || {});
		return fetch(DATA.restUrl + path, options).then(function (res) { return res.json(); });
	}

	function box(type, text) {
		var cls = type === "error" ? "hsb-msg-err" : (type === "warn" ? "hsb-msg-warn" : "hsb-msg-ok");
		return el("div", { class: "hsb-msg " + cls, role: type === "error" ? "alert" : "status", text: text });
	}

	function render(root, doctorId) {
		root.innerHTML = "";
		root.appendChild(el("p", { text: "در حال بارگذاری برنامه…" }));

		api("schedule?doctor_id=" + doctorId).then(function (res) {
			root.innerHTML = "";
			if (!res.ok) {
				root.appendChild(box("error", res.message || "بارگذاری برنامه ممکن نشد."));
				return;
			}

			if (!res.can_edit) {
				root.appendChild(box("warn", "شما مجاز به ویرایش برنامهٔ این پزشک نیستید (فقط مشاهده). این محدودیت از تنظیمات افزونه تغییر می‌کند."));
			}

			var table = el("table", { class: "hsb-schedule-table" });
			var thead = el("thead", {}, [
				el("tr", {}, [
					el("th", { text: "روز" }),
					el("th", { text: "فعال" }),
					el("th", { text: "شروع" }),
					el("th", { text: "پایان" }),
					el("th", { text: "طول بازه (دقیقه)" }),
					el("th", { text: "ظرفیت هر بازه" }),
				]),
			]);
			table.appendChild(thead);
			var tbody = el("tbody");

			res.days.forEach(function (d) {
				var activeCb = el("input", { type: "checkbox", "data-field": "active" });
				activeCb.checked = !!d.active;
				var startIn = el("input", { type: "time", value: d.start, "data-field": "start" });
				var endIn = el("input", { type: "time", value: d.end, "data-field": "end" });
				var lenSel = el("select", { "data-field": "slot_length" });
				[10, 15, 20, 30, 45, 60].forEach(function (m) {
					var o = el("option", { value: String(m), text: String(m) });
					if (d.slot_length === m) o.selected = true;
					lenSel.appendChild(o);
				});
				var capIn = el("input", { type: "number", min: "1", max: "50", value: String(d.capacity), "data-field": "capacity", style: "width:70px" });

				[activeCb, startIn, endIn, lenSel, capIn].forEach(function (i) {
					if (!res.can_edit) i.setAttribute("disabled", "disabled");
				});

				tbody.appendChild(el("tr", { "data-weekday": String(d.weekday) }, [
					el("td", { text: d.name }),
					el("td", {}, [activeCb]),
					el("td", {}, [startIn]),
					el("td", {}, [endIn]),
					el("td", {}, [lenSel]),
					el("td", {}, [capIn]),
				]));
			});
			table.appendChild(tbody);
			root.appendChild(table);

			var msgArea = el("div");
			root.appendChild(msgArea);

			if (res.can_edit) {
				var saveBtn = el("button", { type: "button", class: "button button-primary hsb-save", text: "ذخیرهٔ برنامهٔ هفتگی" });
				saveBtn.addEventListener("click", function () {
					saveBtn.setAttribute("disabled", "disabled");
					msgArea.innerHTML = "";
					var days = [];
					tbody.querySelectorAll("tr").forEach(function (tr) {
						days.push({
							weekday: parseInt(tr.getAttribute("data-weekday"), 10),
							active: !!tr.querySelector('[data-field="active"]').checked,
							start: tr.querySelector('[data-field="start"]').value,
							end: tr.querySelector('[data-field="end"]').value,
							slot_length: parseInt(tr.querySelector('[data-field="slot_length"]').value, 10),
							capacity: parseInt(tr.querySelector('[data-field="capacity"]').value, 10),
						});
					});
					api("schedule", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({ doctor_id: doctorId, days: days }),
					}).then(function (r) {
						saveBtn.removeAttribute("disabled");
						if (!r.ok) {
							msgArea.appendChild(box("error", r.message || "ذخیرهٔ برنامه انجام نشد."));
							return;
						}
						msgArea.appendChild(box("ok", r.message));
						if (r.conflicts && r.conflicts.length) {
							msgArea.appendChild(box("warn", "توجه: برخی نوبت‌های ثبت‌شده با برنامهٔ جدید تعارض دارند. هیچ نوبتی حذف نشده است؛ با بیماران هماهنگ کنید:"));
							var ul = el("ul", { style: "margin-right:18px" });
							r.conflicts.forEach(function (c) {
								ul.appendChild(el("li", { text: c.date_fa + (c.time_fa ? " ساعت " + c.time_fa : "") + " — " + c.problem }));
							});
							msgArea.appendChild(ul);
						}
					}).catch(function () {
						saveBtn.removeAttribute("disabled");
						msgArea.appendChild(box("warn", "ارتباط قطع شد؛ نتیجهٔ ذخیره نامشخص است. پیش از تلاش دوباره، برنامهٔ فعلی را بررسی کنید."));
					});
				});
				root.appendChild(el("p", {}, [saveBtn]));
			}

			renderOverrides(root, res.overrides, res.can_edit, doctorId);
		});
	}

	function renderOverrides(root, overrides, canEdit, doctorId) {
		root.appendChild(el("h3", { text: "استثناهای تاریخ (تعطیلی / ساعت یا ظرفیت خاص)" }));
		var list = el("div", { class: "hsb-overrides" });
		if (!overrides.length) {
			list.appendChild(el("p", { text: "استثنایی برای روزهای آینده ثبت نشده است." }));
		}
		overrides.forEach(function (o) {
			var line = el("div", { class: "hsb-override-row" }, [
				el("span", { text: o.date_fa + (o.is_closed ? " — تعطیل" : " — ساعت خاص: " + (o.start || "…") + " تا " + (o.end || "…")) + (o.reason ? " (" + o.reason + ")" : "") }),
			]);
			if (canEdit) {
				var delBtn = el("button", { type: "button", class: "button-link-delete", text: "حذف" });
				delBtn.addEventListener("click", function () {
					api("overrides/" + o.id, { method: "DELETE" }).then(function (r) {
						render(root, doctorId); // تازه‌سازی کامل
					});
				});
				line.appendChild(delBtn);
			}
			list.appendChild(line);
		});
		root.appendChild(list);

		if (!canEdit) return;

		root.appendChild(el("h4", { text: "افزودن استثنا" }));
		var form = el("form", { class: "hsb-override-form" });
		var dateIn = el("input", { type: "date", required: "required" });
		var closedCb = el("input", { type: "checkbox" });
		var startIn = el("input", { type: "time" });
		var endIn = el("input", { type: "time" });
		var capIn = el("input", { type: "number", min: "1", max: "50", placeholder: "ظرفیت (اختیاری)" });
		var reasonIn = el("input", { type: "text", maxlength: "190", placeholder: "علت (اختیاری)" });

		form.appendChild(field("تاریخ (میلادی)", dateIn));
		form.appendChild(fieldWrap("تعطیل کامل", closedCb));
		form.appendChild(field("ساعت شروع خاص (اختیاری)", startIn));
		form.appendChild(field("ساعت پایان خاص (اختیاری)", endIn));
		form.appendChild(fieldWrap("ظرفیت خاص (اختیاری)", capIn));
		form.appendChild(fieldWrap("علت", reasonIn));

		var msgArea = el("div");
		form.appendChild(msgArea);
		var submit = el("button", { type: "submit", class: "button button-secondary", text: "ثبت استثنا" });
		form.appendChild(el("p", {}, [submit]));

		form.addEventListener("submit", function (ev) {
			ev.preventDefault();
			msgArea.innerHTML = "";
			var payload = {
				doctor_id: doctorId,
				date: dateIn.value,
				is_closed: closedCb.checked,
				start: startIn.value || "",
				end: endIn.value || "",
				reason: reasonIn.value || "",
			};
			if (capIn.value) payload.capacity = parseInt(capIn.value, 10);
			api("overrides", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload),
			}).then(function (r) {
				if (!r.ok) {
					msgArea.appendChild(box("error", r.message || "ثبت استثنا انجام نشد."));
					return;
				}
				render(root, doctorId);
				if (r.conflicts && r.conflicts.length) {
					alert(r.conflicts[0].problem);
				}
			});
		});
		root.appendChild(form);

		function field(label, input) {
			var w = el("div", { class: "hsb-ov-field" });
			w.appendChild(el("label", { text: label }));
			w.appendChild(input);
			return w;
		}
		function fieldWrap(label, input) {
			var w = el("div", { class: "hsb-ov-field" });
			var l = el("label", { text: " " + label });
			l.insertBefore(input, l.firstChild);
			w.appendChild(l);
			return w;
		}
	}

	function boot() {
		document.querySelectorAll("[data-hsb-schedule]").forEach(function (root) {
			var id = parseInt(root.getAttribute("data-hsb-schedule"), 10);
			if (id) render(root, id);
		});
	}
	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();
