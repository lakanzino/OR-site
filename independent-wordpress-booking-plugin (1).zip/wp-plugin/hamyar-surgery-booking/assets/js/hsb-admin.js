/**
 * HSB — اسکریپت پیشخوان: فهرست نوبت‌ها با فیلتر و تغییر وضعیت + ردیف‌های نگاشت کاربر↔پزشک.
 */
(function () {
	"use strict";

	var DATA = window.HSB_ADMIN || {};

	function api(path, options) {
		options = options || {};
		options.headers = Object.assign({ "X-WP-Nonce": DATA.nonce || "" }, options.headers || {});
		return fetch(DATA.restUrl + path, options).then(function (res) { return res.json(); });
	}

	/* فهرست نوبت‌ها */
	var listRoot = document.getElementById("hsb-admin-appointments");
	if (listRoot) {
		var load = function () {
			var doctor = document.getElementById("hsb-f-doctor").value;
			var date = document.getElementById("hsb-f-date").value;
			var status = document.getElementById("hsb-f-status").value;
			var q = "clinic/appointments?";
			if (doctor && doctor !== "0") q += "doctor_id=" + doctor + "&";
			if (date) q += "date=" + encodeURIComponent(date) + "&";
			if (status) q += "status=" + encodeURIComponent(status);

			listRoot.innerHTML = "<p>در حال بارگذاری…</p>";
			api(q).then(function (res) {
				if (!res.ok) {
					listRoot.innerHTML = "";
					var p = document.createElement("p");
					p.className = "notice notice-error";
					p.textContent = res.message || "بارگذاری نوبت‌ها ممکن نشد.";
					listRoot.appendChild(p);
					return;
				}
				renderTable(res.appointments || []);
			});
		};

		var renderTable = function (rows) {
			listRoot.innerHTML = "";
			if (!rows.length) {
				listRoot.innerHTML = "<p>نوبتی مطابق فیلترها یافت نشد.</p>";
				return;
			}
			var table = document.createElement("table");
			table.className = "widefat striped hsb-table";
			table.innerHTML = "<thead><tr>" +
				"<th>کد پیگیری</th><th>پزشک</th><th>بیمار</th><th>موبایل</th><th>کد ملی</th>" +
				"<th>خدمت</th><th>تاریخ</th><th>ساعت</th><th>وضعیت</th><th>اقدام</th></tr></thead>";
			var tbody = document.createElement("tbody");
			rows.forEach(function (a) {
				var tr = document.createElement("tr");
				var cells = [a.code, a.doctor_name, a.patient_name, a.patient_mobile, a.patient_national_id || "—", a.service_fa, a.date_fa, a.time_fa, a.status_fa];
				cells.forEach(function (c, i) {
					var td = document.createElement("td");
					td.textContent = c;
					if (i === 0 || i === 3) td.dir = "ltr";
					tr.appendChild(td);
				});
				var actions = document.createElement("td");
				var add = function (label, status) {
					var b = document.createElement("button");
					b.type = "button";
					b.className = "button button-small";
					b.textContent = label;
					b.style.marginLeft = "4px";
					b.addEventListener("click", function () {
						b.disabled = true;
						api("clinic/appointments/" + a.id + "/status", {
							method: "POST",
							headers: { "Content-Type": "application/json" },
							body: JSON.stringify({ status: status }),
						}).then(function (r) {
							window.alert(r.message || "");
							load();
						});
					});
					actions.appendChild(b);
				};
				if (a.status === "requested") {
					add("تأیید", "confirmed");
					add("لغو", "cancelled_clinic");
				} else if (a.status === "confirmed") {
					add("انجام شد", "completed");
					add("عدم مراجعه", "no_show");
					add("لغو", "cancelled_clinic");
				}
				tr.appendChild(actions);
				tbody.appendChild(tr);
			});
			table.appendChild(tbody);
			listRoot.appendChild(table);
		};

		document.getElementById("hsb-f-apply").addEventListener("click", load);
		load();
	}

	/* ردیف‌های نگاشت کاربر↔پزشک */
	var addBtn = document.getElementById("hsb-map-add");
	if (addBtn) {
		var counter = 1000;
		addBtn.addEventListener("click", function () {
			var tpl = document.getElementById("hsb-map-template");
			if (!tpl) return;
			var html = tpl.innerHTML.split("__i__").join(String(counter++));
			var tr = document.createElement("tbody");
			tr.innerHTML = html;
			document.getElementById("hsb-map-body").appendChild(tr.firstElementChild);
		});
		document.addEventListener("click", function (e) {
			if (e.target && e.target.classList.contains("hsb-map-remove")) {
				var row = e.target.closest("tr");
				if (row) row.remove();
			}
		});
	}
})();
