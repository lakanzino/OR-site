/**
 * HSB — فرانت‌اند فرایند رزرو و «نوبت‌های من» (بدون وابستگی خارجی).
 *
 * نکات امنیتی/درستی:
 *  - اطلاعات بیمار فقط با POST و هدر nonce ارسال می‌شود؛ هرگز در URL/کوکی/localStorage ذخیره نمی‌شود.
 *  - برای هر تلاشِ رزرو یک Idempotency-Key (UUID) ساخته می‌شود؛ اگر پاسخ نرسید، تلاش مجدد
 *    با همان کلید انجام می‌شود و نوبت تکراری ساخته نمی‌شود.
 *  - وضعیت «ثبت درخواست» با «در انتظار تأیید مطب» و «تأییدشده» در خروجی متمايز است.
 */
(function () {
	"use strict";

	var DATA = window.HSB_DATA || {};

	function el(tag, attrs, children) {
		var node = document.createElement(tag);
		attrs = attrs || {};
		Object.keys(attrs).forEach(function (k) {
			if (k === "text") node.textContent = attrs[k];
			else if (k === "html") node.innerHTML = attrs[k]; // فقط با محتوای ساخته‌شدهٔ خود افزونه
			else node.setAttribute(k, attrs[k]);
		});
		(children || []).forEach(function (c) {
			if (c) node.appendChild(c);
		});
		return node;
	}

	function api(path, options) {
		options = options || {};
		options.headers = Object.assign(
			{ "X-WP-Nonce": DATA.nonce || "" },
			options.headers || {}
		);
		return fetch(DATA.restUrl + path, options).then(function (res) {
			return res.json().catch(function () {
				return { ok: false, error: "bad_response", message: "پاسخ سرور نامعتبر بود." };
			});
		});
	}

	function loading(label) {
		return el("div", { class: "hsb-loading", role: "status" }, [
			el("span", { class: "hsb-spinner", "aria-hidden": "true" }),
			el("span", { text: label || "در حال بارگذاری…" }),
		]);
	}

	function messageBox(type, text) {
		return el("div", { class: "hsb-message hsb-message-" + type, role: type === "error" ? "alert" : "status", text: text });
	}

	/* ------------------------------------------------------------------ */
	/* فرایند رزرو                                                         */
	/* ------------------------------------------------------------------ */
	function initBooking(root) {
		var doctorId = parseInt(root.getAttribute("data-hsb-booking"), 10);
		if (!doctorId) return;

		var state = {
			days: null,
			day: null, // ردیف روز انتخابی
			slots: null,
			slot: null, // بازهٔ انتخابی
			idempotencyKey: null,
			lastPayload: null,
		};

		function rerender() {
			root.innerHTML = "";
			if (!DATA.isLoggedIn) {
				renderLoginCta();
				return;
			}
			renderSteps();
		}

		function renderLoginCta() {
			var box = el("div", { class: "hsb-login-cta" });
			box.appendChild(el("p", { text: "برای دریافت نوبت، ابتدا وارد حساب کاربری خود شوید. اگر حساب ندارید، از همان صفحهٔ ورود می‌توانید ثبت‌نام کنید (ورود با گوگل نیز در صورت فعال‌بودن روی همان صفحه در دسترس است)." }));
			box.appendChild(
				el("a", { class: "hsb-btn hsb-btn-primary", href: DATA.loginUrl || "#", text: "ورود / ثبت‌نام" })
			);
			root.appendChild(box);
			// روزها برای بازدیدکنندهٔ مهمان هم قابل مشاهده است (فقط ظرفیت).
			if (!state.days) loadDays(box);
		}

		function stepTitle(index, title) {
			return el("h2", { class: "hsb-step-title" }, [
				el("span", { class: "hsb-step-index", text: String(index) }),
				el("span", { text: title }),
			]);
		}

		function renderSteps() {
			root.appendChild(el("p", { text: "پزشک: " + (DATA.doctorName || "") }));
			root.appendChild(stepTitle(1, "انتخاب روز (۱۴ روز آینده)"));
			if (!state.days) {
				root.appendChild(loading());
				loadDays();
				return;
			}
			renderDayGrid();
			if (state.day) {
				root.appendChild(stepTitle(2, "انتخاب ساعت"));
				renderSlotGrid();
			}
			if (state.slot) {
				root.appendChild(stepTitle(3, "اطلاعات بیمار"));
				renderForm();
			}
		}

		function loadDays(attachTo) {
			api("doctors/" + doctorId + "/days").then(function (res) {
				if (!res.ok) {
					root.innerHTML = "";
					root.appendChild(messageBox("warning", res.message || "تقویم قابل نمایش نیست."));
					return;
				}
				state.days = res.days;
				if (attachTo) {
					// نمایش فقط‌خواندنی برای مهمان
					var grid = buildDayGrid(true);
					attachTo.parentNode.appendChild(el("h2", { class: "hsb-step-title", text: "وضعیت ظرفیت روزها" }));
					attachTo.parentNode.appendChild(grid);
				} else {
					rerender();
				}
			});
		}

		function buildDayGrid(readonly) {
			var grid = el("div", { class: "hsb-days" });
			state.days.forEach(function (d) {
				var btn = el("button", {
					type: "button",
					class: "hsb-day",
					"data-state": d.state,
					disabled: readonly || !d.bookable ? "disabled" : null,
					"aria-pressed": state.day && state.day.date === d.date ? "true" : "false",
					"aria-label": d.label + " — " + d.state_label,
				});
				if (readonly || !d.bookable) btn.setAttribute("disabled", "disabled");
				btn.appendChild(el("span", { class: "hsb-day-weekday", text: d.weekday }));
				btn.appendChild(el("span", { class: "hsb-day-date", text: d.label_short.replace(d.weekday + " ", "") }));
				btn.appendChild(el("span", { class: "hsb-day-state", text: d.state_label }));
				if (!readonly && d.bookable) {
					btn.addEventListener("click", function () {
						state.day = d;
						state.slot = null;
						state.slots = null;
						state.idempotencyKey = null;
						rerender();
					});
				}
				grid.appendChild(btn);
			});
			return grid;
		}

		function renderDayGrid() {
			root.appendChild(buildDayGrid(false));
		}

		function renderSlotGrid() {
			if (!state.slots) {
				root.appendChild(loading("در حال دریافت ساعت‌ها…"));
				api("doctors/" + doctorId + "/slots?date=" + encodeURIComponent(state.day.date)).then(function (res) {
					if (!res.ok) {
						rerender();
						root.appendChild(messageBox("warning", res.message || "ساعت‌های این روز قابل نمایش نیست."));
						return;
					}
					state.slots = res.slots;
					rerender();
				});
				return;
			}
			var grid = el("div", { class: "hsb-slots" });
			var anyBookable = false;
			state.slots.forEach(function (s) {
				if (s.bookable) anyBookable = true;
				var btn = el("button", {
					type: "button",
					class: "hsb-slot",
					"aria-pressed": state.slot && state.slot.time === s.time ? "true" : "false",
					"aria-label": "ساعت " + s.time_fa + (s.bookable ? "" : " — تکمیل یا گذشته"),
				}, [
					el("span", { text: s.time_fa }),
					el("small", { text: s.bookable ? "ظرفیت: " + s.remaining_fa : "تکمیل" }),
				]);
				if (!s.bookable) btn.setAttribute("disabled", "disabled");
				btn.addEventListener("click", function () {
					if (!s.bookable) return;
					state.slot = s;
					state.idempotencyKey = null; // انتخاب تازه = کلید تازه
					rerender();
				});
				grid.appendChild(btn);
			});
			if (!anyBookable) {
				root.appendChild(messageBox("warning", "برای این روز ساعت خالی وجود ندارد؛ لطفاً روز دیگری انتخاب کنید."));
				return;
			}
			root.appendChild(grid);
		}

		function renderForm() {
			var form = el("form", { novalidate: "novalidate" });
			form.setAttribute("novalidate", "novalidate");

			form.appendChild(field("نام و نام خانوادگی بیمار *", el("input", {
				type: "text", name: "patient_name", required: "required", maxlength: "100", autocomplete: "name",
			})));

			form.appendChild(field("شمارهٔ موبایل بیمار *", el("input", {
				type: "tel", name: "patient_mobile", required: "required", inputmode: "numeric", dir: "ltr",
				placeholder: "09xxxxxxxxx", maxlength: "11", autocomplete: "tel",
			}), "برای هماهنگی مطب استفاده می‌شود؛ بدون تأیید پیامکی."));

			form.appendChild(field("کد ملی (اختیاری)", el("input", {
				type: "text", name: "patient_national_id", inputmode: "numeric", dir: "ltr", maxlength: "10",
			}), "اگر وارد شود، صحت رقم کنترل آن بررسی می‌شود."));

			var service = el("select", { name: "service_type", required: "required" }, [
				el("option", { value: "consult", text: "مشاوره" }),
				el("option", { value: "visit", text: "ویزیت" }),
				el("option", { value: "surgery", text: "جراحی" }),
			]);
			form.appendChild(field("نوع خدمت *", service));

			var desc = el("textarea", { name: "description", maxlength: "500" });
			form.appendChild(field("توضیح کوتاه (اختیاری)", desc, null,
				"لطفاً اطلاعات پزشکی حساس (شرح بیماری، نتایج آزمایش، تصاویر) را اینجا وارد نکنید؛ این فیلد فقط برای هماهنگی کلی است."));

			var submit = el("button", { type: "submit", class: "hsb-btn hsb-btn-outline", text: "بازبینی و تأیید نهایی" });

			form.appendChild(el("div", { class: "hsb-actions" }, [submit]));

			form.addEventListener("submit", function (ev) {
				ev.preventDefault();
				var fd = new FormData(form);
				var payload = {
					doctor_id: doctorId,
					date: state.day.date,
					time: state.slot.time,
					patient_name: (fd.get("patient_name") || "").toString().trim(),
					patient_mobile: (fd.get("patient_mobile") || "").toString().trim(),
					patient_national_id: (fd.get("patient_national_id") || "").toString().trim(),
					service_type: (fd.get("service_type") || "").toString(),
					description: (fd.get("description") || "").toString().trim(),
				};
				var err = validateClient(payload);
				if (err) {
					form.querySelectorAll(".hsb-message").forEach(function (m) { m.remove(); });
					form.appendChild(messageBox("error", err));
					return;
				}
				state.lastPayload = payload;
				renderReview(form);
			});

			root.appendChild(form);

			function field(labelText, input, hint, warnText) {
				var wrap = el("div", { class: "hsb-field" });
				var label = el("label", { text: labelText });
				if (labelText.indexOf("*") > -1) {
					label.innerHTML = labelText.replace("*", '<span class="hsb-required">*</span>');
				}
				input.setAttribute("aria-label", labelText.replace(" *", ""));
				label.appendChild(input);
				wrap.appendChild(label);
				if (hint) wrap.appendChild(el("div", { class: "hsb-hint", text: hint }));
				if (warnText) wrap.appendChild(el("div", { class: "hsb-warn", text: warnText }));
				return wrap;
			}
		}

		function validateClient(p) {
			if (p.patient_name.length < 2) return "نام و نام خانوادگی بیمار را کامل وارد کنید.";
			var m = p.patient_mobile.replace(/[۰-۹]/g, function (d) { return "۰۱۲۳۴۵۶۷۸۹".indexOf(d); });
			if (!/^09\d{9}$/.test(m)) return "شمارهٔ موبایل معتبر نیست (مثال: 09123456789).";
			if (p.description.length > (DATA.maxDescLength || 500)) return "توضیحات بیش از حد طولانی است.";
			return null;
		}

		function renderReview(form) {
			// جایگزینی فرم با خلاصهٔ صریح: نام پزشک، تاریخ، ساعت + تأیید/انصراف.
			root.innerHTML = "";
			root.appendChild(stepTitle(4, "بازبینی و تأیید نهایی"));
			var p = state.lastPayload;
			var serviceFa = { consult: "مشاوره", visit: "ویزیت", surgery: "جراحی" }[p.service_type] || p.service_type;

			var dl = el("dl", { class: "hsb-summary" }, [
				el("div", {}, [el("dt", { text: "پزشک" }), el("dd", { text: DATA.doctorName || "" })]),
				el("div", {}, [el("dt", { text: "تاریخ" }), el("dd", { text: state.day.label })]),
				el("div", {}, [el("dt", { text: "ساعت" }), el("dd", { text: state.slot.time_fa })]),
				el("div", {}, [el("dt", { text: "نوع خدمت" }), el("dd", { text: serviceFa })]),
				el("div", {}, [el("dt", { text: "بیمار" }), el("dd", { text: p.patient_name })]),
			]);
			root.appendChild(dl);
			root.appendChild(messageBox("warning", "توجه: ثبت این فرم «درخواست» را ثبت می‌کند و نوبت پس از تأیید مطب نهایی می‌شود."));

			var confirmBtn = el("button", { type: "button", class: "hsb-btn hsb-btn-primary", text: "تأیید و ثبت نوبت" });
			var cancelBtn = el("button", { type: "button", class: "hsb-btn hsb-btn-outline", text: "انصراف و ویرایش" });

			confirmBtn.addEventListener("click", function () {
				confirmBtn.setAttribute("disabled", "disabled");
				confirmBtn.textContent = "در حال ثبت…";
				submitBooking(function () {
					confirmBtn.removeAttribute("disabled");
					confirmBtn.textContent = "تأیید و ثبت نوبت";
				});
			});
			cancelBtn.addEventListener("click", function () { rerender(); });

			root.appendChild(el("div", { class: "hsb-actions" }, [confirmBtn, cancelBtn]));
		}

		function submitBooking(done) {
			if (!state.idempotencyKey) {
				state.idempotencyKey = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : ("hsb-" + Date.now() + "-" + Math.random().toString(16).slice(2));
			}
			var headers = { "Content-Type": "application/json", "X-HSB-Idempotency-Key": state.idempotencyKey };
			api("appointments", {
				method: "POST",
				headers: headers,
				body: JSON.stringify(state.lastPayload),
			}).then(function (res) {
				done();
				root.innerHTML = "";
				if (res.ok) {
					var a = res.appointment;
					root.appendChild(messageBox("success", res.message || "درخواست شما ثبت شد."));
					var box = el("div", { class: "hsb-summary" });
					box.appendChild(el("div", {}, [el("dt", { text: "کد پیگیری" }), el("dd", {}, [el("span", { class: "hsb-code", text: a.code })])]));
					box.appendChild(el("div", {}, [el("dt", { text: "پزشک" }), el("dd", { text: a.doctor_name })]));
					box.appendChild(el("div", {}, [el("dt", { text: "تاریخ و ساعت" }), el("dd", { text: a.date_fa + " — ساعت " + a.time_fa })]));
					box.appendChild(el("div", {}, [el("dt", { text: "وضعیت" }), el("dd", { text: a.status_fa })]));
					root.appendChild(box);
					root.appendChild(messageBox("warning", "این وضعیت یعنی «در انتظار تأیید مطب»؛ تا وقتی وضعیت «تأییدشده» نشده، نوبت نهایی نیست. کد پیگیری را نگه دارید."));
					state.slot = null;
					state.day = null;
					state.days = null;
					state.idempotencyKey = null;
					return;
				}
				if (res.uncertain) {
					root.appendChild(messageBox("warning", res.message));
					var retryBtn = el("button", { type: "button", class: "hsb-btn hsb-btn-outline", text: "تلاش دوبارهٔ امن (بدون ساخت نوبت تکراری)" });
					retryBtn.addEventListener("click", function () {
						root.innerHTML = "";
						// همان کلید تکرارناپذیری حفظ می‌شود — درخواست یکی است.
						renderSteps();
						state.slot = null;
						rerender();
					});
					root.appendChild(el("div", { class: "hsb-actions" }, [retryBtn]));
					return;
				}
				root.appendChild(messageBox("error", res.message || "ثبت نوبت انجام نشد."));
				if (res.error === "slot_full" || res.error === "day_unavailable") {
					var reloadBtn = el("button", { type: "button", class: "hsb-btn hsb-btn-outline", text: "مشاهدهٔ ظرفیت تازه" });
					reloadBtn.addEventListener("click", function () {
						state.days = null;
						state.slots = null;
						rerender();
					});
					root.appendChild(el("div", { class: "hsb-actions" }, [reloadBtn]));
					return;
				}
				rerenderErrorOnly(res.message);
			}).catch(function () {
				done();
				root.innerHTML = "";
				root.appendChild(messageBox("warning", "ارتباط با سرور قطع شد و نتیجهٔ ثبت نامشخص است. اگر دوباره تلاش کنید نوبت تکراری ساخته نمی‌شود؛ یا چند لحظهٔ دیگر «نوبت‌های من» را بررسی کنید."));
			});
		}

		function rerenderErrorOnly(msg) {
			root.innerHTML = "";
			rerender();
			root.insertBefore(messageBox("error", msg || "خطایی رخ داد."), root.firstChild);
		}

		rerender();
	}

	/* ------------------------------------------------------------------ */
	/* نوبت‌های من                                                          */
	/* ------------------------------------------------------------------ */
	function initMyAppointments(root) {
		root.appendChild(loading());
		api("my-appointments").then(function (res) {
			root.innerHTML = "";
			if (!res.ok) {
				root.appendChild(messageBox("error", res.message || "بارگذاری نوبت‌ها ممکن نشد."));
				return;
			}
			if (!res.appointments.length) {
				root.appendChild(messageBox("warning", "تا کنون نوبتی ثبت نکرده‌اید."));
				return;
			}
			res.appointments.forEach(function (a) {
				var card = el("div", { class: "hsb-appt" });
				var head = el("div", { class: "hsb-appt-head" }, [
					el("span", { class: "hsb-appt-code", text: a.code }),
					el("span", { class: "hsb-badge hsb-badge-" + a.status, text: a.status_fa }),
				]);
				var body = el("div", { class: "hsb-appt-body" });
				body.appendChild(el("div", { text: "پزشک: " + a.doctor_name }));
				body.appendChild(el("div", { text: "زمان: " + a.date_fa + " — ساعت " + a.time_fa }));
				body.appendChild(el("div", { text: "خدمت: " + a.service_fa + " — بیمار: " + a.patient_name }));
				card.appendChild(head);
				card.appendChild(body);

				if (a.cancellable) {
					var btn = el("button", { type: "button", class: "hsb-btn hsb-btn-danger", text: "لغو این نوبت" });
					btn.addEventListener("click", function () {
						if (!window.confirm("از لغو این نوبت مطمئن هستید؟ این کار قابل بازگشت نیست.")) return;
						btn.setAttribute("disabled", "disabled");
						btn.textContent = "در حال لغو…";
						api("appointments/" + a.id + "/cancel", { method: "POST" }).then(function (r) {
							root.innerHTML = "";
							root.appendChild(messageBox(r.ok ? "success" : (r.uncertain ? "warning" : "error"), r.message || ""));
							initMyAppointments(root);
						});
					});
					card.appendChild(el("div", { class: "hsb-actions" }, [btn]));
				}
				root.appendChild(card);
			});
		});
	}

	/* ------------------------------------------------------------------ */
	function boot() {
		document.querySelectorAll("[data-hsb-booking]").forEach(initBooking);
		document.querySelectorAll("[data-hsb-my]").forEach(initMyAppointments);
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();
