<?php
/**
 * ارکستراتور اصلی افزونه — اتصال ماژول‌ها به چرخهٔ حیات وردپرس.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس مرکزی افزونهٔ نوبت‌دهی همیار جراحی.
 */
final class HSB_Plugin {

	/**
	 * اتصال هوک‌ها.
	 */
	public static function init(): void {
		// ارتقای اسکیما در صورت نیاز (نسخه‌بندی‌شده و غیرمخرب).
		add_action( 'admin_init', array( 'HSB_Activator', 'maybe_upgrade' ) );

		// REST API.
		add_action( 'rest_api_init', array( 'HSB_REST', 'register_routes' ) );

		// شورت‌کدها.
		add_action( 'init', array( 'HSB_Shortcodes', 'register' ) );

		// پیشخوان.
		if ( is_admin() ) {
			HSB_Admin::hooks();
		}

		// اعلان‌ها (فقط در صورت فعال‌بودن در تنظیمات).
		HSB_Notifications::hooks();

		// دارایی‌های فرانت‌اند (ثبت؛ enqueue فقط هنگام نمایش شورت‌کد).
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );

		// اخطار پیکربندی ناقص برای مدیران.
		add_action( 'admin_notices', array( __CLASS__, 'configuration_notices' ) );
	}

	/**
	 * ثبت اسکریپت‌ها و استایل‌ها (بدون enqueue سراسری تا با قالب تداخل نکند).
	 */
	public static function register_assets(): void {
		wp_register_style(
			'hsb-frontend',
			HSB_PLUGIN_URL . 'assets/css/hsb-frontend.css',
			array(),
			HSB_VERSION
		);
		wp_register_script(
			'hsb-frontend',
			HSB_PLUGIN_URL . 'assets/js/hsb-frontend.js',
			array(),
			HSB_VERSION,
			true
		);
		wp_register_script(
			'hsb-schedule',
			HSB_PLUGIN_URL . 'assets/js/hsb-schedule.js',
			array(),
			HSB_VERSION,
			true
		);
	}

	/**
	 * اطلاعات لازم برای اسکریپت‌های فرانت‌اند را تزریق می‌کند.
	 * دادهٔ شخصی بیمار هرگز اینجا قرار نمی‌گیرد.
	 *
	 * @param array $extra دادهٔ تکمیلی (مثلاً doctor_id).
	 */
	public static function localize_frontend( array $extra = array() ): void {
		$data = array_merge(
			array(
				'restUrl'       => esc_url_raw( rest_url( 'hsb/v1/' ) ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'isLoggedIn'    => is_user_logged_in(),
				'loginUrl'      => wp_login_url( get_permalink() ),
				'horizon'       => HSB_BOOKING_HORIZON_DAYS,
				'cancelCutoff'  => (int) HSB_Settings::get( 'cancel_cutoff_hours', 24 ),
				'maxDescLength' => 500,
			),
			$extra
		);
		wp_localize_script( 'hsb-frontend', 'HSB_DATA', $data );
	}

	/**
	 * اعلان‌های مدیریتی برای پیکربندی ناقص — روشن و غیرمزاحم.
	 */
	public static function configuration_notices(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'hsb' ) ) {
			return; // فقط در صفحات خود افزونه.
		}
		if ( ! HSB_Doctor::provider_is_configured() ) {
			echo '<div class="notice notice-warning"><p>';
			echo esc_html__(
				'نوبت‌دهی همیار: اتصال پزشکان هنوز پیکربندی نشده است. از بخش «تنظیمات نوبت‌دهی» نوع محتوای پزشک و رابطهٔ حساب کاربری با پروفایل را مشخص کنید؛ در غیر این صورت فرم رزرو نمایش داده نمی‌شود.',
				'hamyar-surgery-booking'
			);
			echo '</p></div>';
		}
	}
}
