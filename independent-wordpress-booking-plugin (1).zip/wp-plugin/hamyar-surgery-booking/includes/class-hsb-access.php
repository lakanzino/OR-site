<?php
/**
 * کنترل دسترسی و مالکیت — مرزهای روشن برای مدیر، پزشک، منشی و بیمار.
 *
 * هیچ نقش جدیدی ساخته نمی‌شود؛ دسترسی‌ها از capabilityهای موجود + لایهٔ اتصال پزشک مشتق می‌شوند.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * سیاست‌های دسترسی.
 */
final class HSB_Access {

	/**
	 * مدیر کامل سایت.
	 */
	public static function is_admin( int $user_id = 0 ): bool {
		if ( $user_id ) {
			return user_can( $user_id, 'manage_options' );
		}
		return current_user_can( 'manage_options' );
	}

	/**
	 * آیا کاربر می‌تواند نوبت‌های یک پزشک را ببیند/مدیریت کند؟ (پزشکِ مالک یا منشیِ نگاشت‌شده یا مدیر)
	 */
	public static function can_manage_doctor( int $user_id, int $doctor_id ): bool {
		if ( self::is_admin( $user_id ) ) {
			return true;
		}
		return null !== HSB_Doctor::relation_type( $user_id, $doctor_id );
	}

	/**
	 * آیا کاربر می‌تواند برنامهٔ هفتگی/استثناهای یک پزشک را ویرایش کند؟
	 * مرز منشی به‌صورت صریح از تنظیمات خوانده می‌شود.
	 */
	public static function can_edit_schedule( int $user_id, int $doctor_id ): bool {
		if ( self::is_admin( $user_id ) ) {
			return true;
		}
		$relation = HSB_Doctor::relation_type( $user_id, $doctor_id );
		if ( 'owner' === $relation ) {
			return (bool) HSB_Settings::get( 'doctors_can_edit_schedule', 1 );
		}
		if ( 'staff' === $relation ) {
			return (bool) HSB_Settings::get( 'staff_can_edit_schedule', 0 );
		}
		return false;
	}

	/**
	 * آیا کاربر می‌تواند یک نوبت خاص را ببیند؟
	 * فقط: خود بیمار، پزشک/منشیٔ مجاز همان پزشک، یا مدیر.
	 *
	 * @param object $appointment ردیف نوبت.
	 */
	public static function can_view_appointment( int $user_id, $appointment ): bool {
		if ( ! $user_id || ! $appointment ) {
			return false;
		}
		if ( self::is_admin( $user_id ) ) {
			return true;
		}
		if ( (int) $appointment->patient_user_id === $user_id ) {
			return true;
		}
		return self::can_manage_doctor( $user_id, (int) $appointment->doctor_id );
	}

	/**
	 * آیا کاربر می‌تواند وضعیت نوبت را از سمت مطب تغییر دهد؟ (پزشک/منشی/مدیر همان پزشک)
	 */
	public static function can_change_status( int $user_id, $appointment ): bool {
		if ( ! $appointment ) {
			return false;
		}
		return self::can_manage_doctor( $user_id, (int) $appointment->doctor_id );
	}

	/**
	 * فهرست پزشکانی که کاربر جاری می‌تواند مدیریت کند (برای پیشخوان).
	 *
	 * @return int[]
	 */
	public static function manageable_doctor_ids( int $user_id ): array {
		if ( self::is_admin( $user_id ) ) {
			$all = HSB_Doctor::list_doctors();
			return array_map(
				function ( $d ) {
					return (int) $d['id'];
				},
				$all
			);
		}
		$ids = array();
		foreach ( HSB_Doctor::list_doctors() as $d ) {
			if ( null !== HSB_Doctor::relation_type( $user_id, (int) $d['id'] ) ) {
				$ids[] = (int) $d['id'];
			}
		}
		return $ids;
	}
}
