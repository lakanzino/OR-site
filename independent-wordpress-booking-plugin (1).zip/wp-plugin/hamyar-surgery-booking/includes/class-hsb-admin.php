<?php
/**
 * پیشخوان وردپرس: فهرست نوبت‌ها، برنامهٔ پزشکان، تنظیمات اتصال و سیاست‌ها.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت پیشخوان.
 */
final class HSB_Admin {

	/**
	 * اتصال هوک‌های پیشخوان.
	 */
	public static function hooks(): void {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_hsb_save_settings', array( __CLASS__, 'handle_save_settings' ) );
		add_action( 'admin_post_hsb_save_map', array( __CLASS__, 'handle_save_map' ) );
		add_action( 'admin_post_hsb_save_flags', array( __CLASS__, 'handle_save_flags' ) );
		add_action( 'admin_post_hsb_test_email', array( __CLASS__, 'handle_test_email' ) );
	}

	/**
	 * منوها.
	 */
	public static function menu(): void {
		add_menu_page(
			'نوبت‌دهی همیار',
			'نوبت‌دهی همیار',
			'manage_options',
			'hsb-appointments',
			array( __CLASS__, 'page_appointments' ),
			'dashicons-calendar-alt',
			26
		);
		add_submenu_page( 'hsb-appointments', 'نوبت‌ها', 'نوبت‌ها', 'manage_options', 'hsb-appointments', array( __CLASS__, 'page_appointments' ) );
		add_submenu_page( 'hsb-appointments', 'برنامهٔ پزشکان', 'برنامهٔ پزشکان', 'manage_options', 'hsb-schedule', array( __CLASS__, 'page_schedule' ) );
		add_submenu_page( 'hsb-appointments', 'تنظیمات نوبت‌دهی', 'تنظیمات', 'manage_options', 'hsb-settings', array( __CLASS__, 'page_settings' ) );
	}

	/**
	 * بارگذاری دارایی‌ها فقط در صفحات خود افزونه.
	 */
	public static function assets( string $hook ): void {
		if ( false === strpos( $hook, 'hsb' ) ) {
			return;
		}
		wp_enqueue_style( 'hsb-admin', HSB_PLUGIN_URL . 'assets/css/hsb-admin.css', array(), HSB_VERSION );
		wp_enqueue_script( 'hsb-admin', HSB_PLUGIN_URL . 'assets/js/hsb-admin.js', array(), HSB_VERSION, true );
		wp_localize_script(
			'hsb-admin',
			'HSB_ADMIN',
			array(
				'restUrl' => esc_url_raw( rest_url( 'hsb/v1/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
			)
		);
		// اسکریپت ویرایشگر برنامه در صفحهٔ برنامه.
		if ( false !== strpos( $hook, 'hsb-schedule' ) ) {
			wp_enqueue_script( 'hsb-schedule', HSB_PLUGIN_URL . 'assets/js/hsb-schedule.js', array(), HSB_VERSION, true );
		}
	}

	/**
	 * صفحهٔ فهرست نوبت‌ها (رندر با جاوااسکریپت از روی REST؛ فیلتر پزشک/تاریخ/وضعیت).
	 */
	public static function page_appointments(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$doctors = HSB_Doctor::list_doctors();
		?>
		<div class="wrap hsb-admin" dir="rtl">
			<h1>نوبت‌ها</h1>
			<?php if ( ! HSB_Doctor::provider_is_configured() ) : ?>
				<div class="notice notice-warning"><p>اتصال پزشکان پیکربندی نشده است؛ ابتدا از «تنظیمات نوبت‌دهی» آن را کامل کنید.</p></div>
			<?php endif; ?>
			<div class="hsb-filters">
				<label>پزشک:
					<select id="hsb-f-doctor">
						<option value="0">همه</option>
						<?php foreach ( $doctors as $d ) : ?>
							<option value="<?php echo esc_attr( (string) $d['id'] ); ?>"><?php echo esc_html( $d['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label>تاریخ: <input type="date" id="hsb-f-date"></label>
				<label>وضعیت:
					<select id="hsb-f-status">
						<option value="">همه</option>
						<option value="requested">در انتظار تأیید مطب</option>
						<option value="confirmed">تأییدشده</option>
						<option value="completed">انجام‌شده</option>
						<option value="cancelled_patient">لغوشده توسط بیمار</option>
						<option value="cancelled_clinic">لغوشده توسط مطب</option>
						<option value="no_show">عدم مراجعه</option>
					</select>
				</label>
				<button type="button" class="button button-primary" id="hsb-f-apply">اعمال فیلتر</button>
			</div>
			<div id="hsb-admin-appointments" aria-live="polite"><p>در حال بارگذاری…</p></div>
		</div>
		<?php
	}

	/**
	 * صفحهٔ ویرایش برنامهٔ پزشکان.
	 */
	public static function page_schedule(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$doctors    = HSB_Doctor::list_doctors();
		$doctor_id  = isset( $_GET['doctor_id'] ) ? absint( $_GET['doctor_id'] ) : ( $doctors[0]['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap hsb-admin" dir="rtl">
			<h1>برنامهٔ پزشکان</h1>
			<?php if ( empty( $doctors ) ) : ?>
				<div class="notice notice-warning"><p>هیچ پزشکی از لایهٔ اتصال دریافت نشد. ابتدا اتصال پزشکان را در تنظیمات پیکربندی کنید.</p></div>
			</div>
			<?php else : ?>
				<form method="get" style="margin-bottom:16px">
					<input type="hidden" name="page" value="hsb-schedule">
					<label>انتخاب پزشک:
						<select name="doctor_id" onchange="this.form.submit()">
							<?php foreach ( $doctors as $d ) : ?>
								<option value="<?php echo esc_attr( (string) $d['id'] ); ?>" <?php selected( $doctor_id, $d['id'] ); ?>><?php echo esc_html( $d['name'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				</form>
				<div class="hsb-schedule-manager" data-hsb-schedule="<?php echo esc_attr( (string) $doctor_id ); ?>"></div>
				<script>
					window.HSB_SCHEDULE = {
						restUrl: <?php echo wp_json_encode( esc_url_raw( rest_url( 'hsb/v1/' ) ) ); ?>,
						nonce: <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>,
						doctorId: <?php echo (int) $doctor_id; ?>
					};
				</script>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * صفحهٔ تنظیمات.
	 */
	public static function page_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$s         = HSB_Settings::all();
		$doctors   = HSB_Doctor::list_doctors();
		$roles     = wp_roles()->roles;
		$users     = get_users( array( 'number' => 500, 'fields' => array( 'ID', 'display_name', 'user_login' ) ) );
		$map       = HSB_Settings::user_doctor_map();
		$flags     = HSB_Settings::doctor_booking_enabled();
		$saved     = isset( $_GET['hsb_saved'] ) && '1' === $_GET['hsb_saved']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$test_res  = get_transient( 'hsb_test_email_result' );
		if ( $test_res ) {
			delete_transient( 'hsb_test_email_result' );
		}
		?>
		<div class="wrap hsb-admin" dir="rtl">
			<h1>تنظیمات نوبت‌دهی همیار</h1>
			<?php if ( $saved ) : ?>
				<div class="notice notice-success"><p>تنظیمات ذخیره شد.</p></div>
			<?php endif; ?>
			<?php if ( is_array( $test_res ) ) : ?>
				<div class="notice <?php echo ! empty( $test_res['ok'] ) ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $test_res['message'] ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! empty( $s['email_last_error'] ) ) : ?>
				<div class="notice notice-warning"><p><?php echo esc_html( $s['email_last_error'] ); ?></p></div>
			<?php endif; ?>

			<h2 class="title">۱) اتصال پزشکان (لایهٔ Provider)</h2>
			<p class="description">
				رابطهٔ واقعی حساب کاربری و پروفایل پزشک را مشخص کنید؛ افزونه هیچ چیزی را حدس نمی‌زند و شناسهٔ کاربر را معادل شناسهٔ پروفایل فرض نمی‌کند.
				پرسش‌هایی که باید از توسعه‌دهندهٔ افزونهٔ پروفایل پزشکان بپرسید: «رابطهٔ حساب کاربری با پروفایل کجا نگهداری می‌شود؟ post_author یا یک کلید متا؟ نام دقیق کلید متا چیست؟»
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'hsb_save_settings' ); ?>
				<input type="hidden" name="action" value="hsb_save_settings">
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">روش اتصال</th>
						<td>
							<select name="doctor_provider">
								<option value="none" <?php selected( $s['doctor_provider'], 'none' ); ?>>غیرفعال (بدون اتصال)</option>
								<option value="cpt" <?php selected( $s['doctor_provider'], 'cpt' ); ?>>نوع محتوای پزشک (CPT)</option>
								<option value="users" <?php selected( $s['doctor_provider'], 'users' ); ?>>کاربران وردپرس با نقش انتخابی</option>
							</select>
						</td>
					</tr>
					<tr><th scope="row">نام نوع محتوا (post type)</th><td><input type="text" name="doctor_post_type" value="<?php echo esc_attr( $s['doctor_post_type'] ); ?>" class="regular-text" dir="ltr"> <span class="description">معمولاً «doctor» — مقدار واقعی را از افزونهٔ پروفایل بپرسید.</span></td></tr>
					<tr>
						<th scope="row">نوع رابطهٔ حساب ↔ پروفایل</th>
						<td>
							<label><input type="radio" name="doctor_relation" value="post_author" <?php checked( 'post_author', $s['doctor_relation'] ); ?>> نویسندهٔ پروفایل (post_author)</label><br>
							<label><input type="radio" name="doctor_relation" value="meta_key" <?php checked( 'meta_key', $s['doctor_relation'] ); ?>> کلید متا:
								<input type="text" name="doctor_relation_meta_key" value="<?php echo esc_attr( $s['doctor_relation_meta_key'] ); ?>" dir="ltr" style="width:220px"> <span class="description">کلید متایی که شناسهٔ کاربر مالک پروفایل را نگه می‌دارد.</span>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row">نقش‌های پزشک (حالت کاربران)</th>
						<td>
							<?php foreach ( $roles as $role_key => $role ) : ?>
								<label style="display:inline-block;margin-left:12px"><input type="checkbox" name="doctor_roles[]" value="<?php echo esc_attr( $role_key ); ?>" <?php checked( in_array( $role_key, (array) $s['doctor_roles'], true ) ); ?>> <?php echo esc_html( translate_user_role( $role['name'] ) ); ?></label>
							<?php endforeach; ?>
							<p class="description">فقط برای «حالت کاربران»؛ نقش تکراری ساخته نمی‌شود.</p>
						</td>
					</tr>
				</table>

				<h2 class="title">۲) مرزهای دسترسی</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">پزشک می‌تواند برنامهٔ خودش را ویرایش کند</th><td><input type="checkbox" name="doctors_can_edit_schedule" value="1" <?php checked( 1, (int) $s['doctors_can_edit_schedule'] ); ?>></td></tr>
					<tr><th scope="row">منشی/کارمند می‌تواند برنامه را ویرایش کند</th><td><input type="checkbox" name="staff_can_edit_schedule" value="1" <?php checked( 1, (int) $s['staff_can_edit_schedule'] ); ?>> <span class="description">پیش‌فرض خیر — مرز روشن است.</span></td></tr>
				</table>

				<h2 class="title">۳) سیاست لغو و بازه‌ها</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">مهلت لغو بیمار (ساعت قبل از نوبت)</th><td><input type="number" name="cancel_cutoff_hours" value="<?php echo esc_attr( (string) $s['cancel_cutoff_hours'] ); ?>" min="0" max="720" style="width:90px"></td></tr>
					<tr><th scope="row">بیمار بتواند نوبت «تأییدشده» را هم لغو کند</th><td><input type="checkbox" name="patient_can_cancel_confirmed" value="1" <?php checked( 1, (int) $s['patient_can_cancel_confirmed'] ); ?>></td></tr>
					<tr><th scope="row">طول بازهٔ پیش‌فرض (دقیقه)</th><td><input type="number" name="default_slot_length" value="<?php echo esc_attr( (string) $s['default_slot_length'] ); ?>" min="10" max="60" step="5" style="width:90px"> <span class="description">۱۰، ۱۵، ۲۰، ۳۰، ۴۵ یا ۶۰</span></td></tr>
					<tr><th scope="row">ظرفیت پیش‌فرض هر بازه</th><td><input type="number" name="default_capacity" value="<?php echo esc_attr( (string) $s['default_capacity'] ); ?>" min="1" max="50" style="width:90px"></td></tr>
					<tr><th scope="row">حداکثر ثبت نوبت در ساعت برای هر کاربر/IP</th><td><input type="number" name="rate_limit_booking_per_hour" value="<?php echo esc_attr( (string) $s['rate_limit_booking_per_hour'] ); ?>" min="1" max="100" style="width:90px"></td></tr>
				</table>

				<h2 class="title">۴) اعلان‌ها (پیش‌فرض خاموش)</h2>
				<p class="description">اعلان ایمیلی فقط پس از پیکربندی و «تست واقعی ارسال» روشن کنید. پیامک و OTP در این نسخه پیاده‌سازی نشده‌اند و ورود با Google به معنای تأیید مالکیت شمارهٔ موبایل نیست.</p>
				<table class="form-table" role="presentation">
					<tr><th scope="row">فعال‌سازی اعلان ایمیلی</th><td><input type="checkbox" name="email_notifications" value="1" <?php checked( 1, (int) $s['email_notifications'] ); ?>></td></tr>
					<tr><th scope="row">ایمیل مطب</th><td><input type="email" name="clinic_email" value="<?php echo esc_attr( $s['clinic_email'] ); ?>" class="regular-text" dir="ltr"></td></tr>
				</table>

				<h2 class="title">۵) حذف داده‌ها</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">حذف کامل داده‌ها هنگام «پاک‌کردن افزونه»</th><td><input type="checkbox" name="delete_data_on_uninstall" value="1" <?php checked( 1, (int) $s['delete_data_on_uninstall'] ); ?>> <span class="description">پیش‌فرض خیر؛ غیرفعال‌سازی افزونه هیچ‌وقت داده‌ای را پاک نمی‌کند.</span></td></tr>
				</table>

				<?php submit_button( 'ذخیرهٔ تنظیمات' ); ?>
			</form>

			<hr>
			<h2>تست واقعی ارسال ایمیل</h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;align-items:center">
				<?php wp_nonce_field( 'hsb_test_email' ); ?>
				<input type="hidden" name="action" value="hsb_test_email">
				<input type="email" name="test_email" placeholder="گیرندهٔ تست" dir="ltr" required>
				<?php submit_button( 'ارسال ایمیل آزمایشی', 'secondary', 'submit', false ); ?>
			</form>

			<hr>
			<h2>۶) نگاشت کاربر ↔ پروفایل پزشک</h2>
			<p class="description">برای اتصال حساب پزشک یا منشی به پروفایل(ها). نوع «پزشک» = مالک پروفایل؛ نوع «منشی» = کارمند با مرزهای تنظیم‌شده در بالا.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'hsb_save_map' ); ?>
				<input type="hidden" name="action" value="hsb_save_map">
				<table class="widefat striped" style="max-width:900px">
					<thead><tr><th>کاربر</th><th>پزشک (پروفایل)</th><th>نوع</th><th></th></tr></thead>
					<tbody id="hsb-map-body">
						<?php
						$row_index = 0;
						foreach ( $map as $mapped_user_id => $entries ) {
							foreach ( $entries as $entry ) {
								self::map_row( $row_index++, (int) $mapped_user_id, (int) $entry['doctor'], (string) $entry['type'], $users, $doctors );
							}
						}
						self::map_row( $row_index, 0, 0, 'doctor', $users, $doctors ); // یک ردیف خالی برای افزودن.
						?>
					</tbody>
				</table>
				<p><button type="button" class="button" id="hsb-map-add">افزودن ردیف</button></p>
				<?php submit_button( 'ذخیرهٔ نگاشت' ); ?>
			</form>
			<template id="hsb-map-template">
				<?php self::map_row( '__i__', 0, 0, 'doctor', $users, $doctors ); ?>
			</template>

			<?php if ( ! empty( $doctors ) ) : ?>
				<hr>
				<h2>۷) فعال‌سازی رزرو داخلی برای هر پزشک</h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'hsb_save_flags' ); ?>
					<input type="hidden" name="action" value="hsb_save_flags">
					<ul>
						<?php foreach ( $doctors as $d ) : ?>
							<li><label><input type="checkbox" name="flags[<?php echo esc_attr( (string) $d['id'] ); ?>]" value="1" <?php checked( ! isset( $flags[ $d['id'] ] ) || 1 === (int) $flags[ $d['id'] ] ); ?>> <?php echo esc_html( $d['name'] ); ?></label></li>
						<?php endforeach; ?>
					</ul>
					<?php submit_button( 'ذخیرهٔ وضعیت رزروها' ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * رندر یک ردیف نگاشت کاربر↔پزشک.
	 *
	 * @param int|string $i اندیس ردیف.
	 */
	private static function map_row( $i, int $user_id, int $doctor_id, string $type, array $users, array $doctors ): void {
		?>
		<tr>
			<td>
				<select name="map[<?php echo esc_attr( (string) $i ); ?>][user]">
					<option value="">— انتخاب کاربر —</option>
					<?php foreach ( $users as $u ) : ?>
						<option value="<?php echo esc_attr( (string) $u->ID ); ?>" <?php selected( $user_id, (int) $u->ID ); ?>><?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?></option>
					<?php endforeach; ?>
				</select>
			</td>
			<td>
				<select name="map[<?php echo esc_attr( (string) $i ); ?>][doctor]">
					<option value="">— انتخاب پزشک —</option>
					<?php foreach ( $doctors as $d ) : ?>
						<option value="<?php echo esc_attr( (string) $d['id'] ); ?>" <?php selected( $doctor_id, (int) $d['id'] ); ?>><?php echo esc_html( $d['name'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</td>
			<td>
				<select name="map[<?php echo esc_attr( (string) $i ); ?>][type]">
					<option value="doctor" <?php selected( 'doctor', $type ); ?>>پزشک (مالک)</option>
					<option value="staff" <?php selected( 'staff', $type ); ?>>منشی/کارمند</option>
				</select>
			</td>
			<td><button type="button" class="button-link-delete hsb-map-remove">حذف</button></td>
		</tr>
		<?php
	}

	/**
	 * هدایت بازگشتی به تنظیمات با پیام.
	 */
	private static function redirect_settings( bool $saved = true ): void {
		wp_safe_redirect( admin_url( 'admin.php?page=hsb-settings&hsb_saved=' . ( $saved ? '1' : '0' ) ) );
		exit;
	}

	/**
	 * ذخیرهٔ تنظیمات اصلی.
	 */
	public static function handle_save_settings(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hsb_save_settings' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$input = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		HSB_Settings::update( HSB_Settings::sanitize( is_array( $input ) ? $input : array() ) );
		self::redirect_settings();
	}

	/**
	 * ذخیرهٔ نگاشت کاربر↔پزشک.
	 */
	public static function handle_save_map(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hsb_save_map' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$rows = isset( $_POST['map'] ) ? (array) wp_unslash( $_POST['map'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$map  = array();
		foreach ( $rows as $row ) {
			$user_id   = absint( $row['user'] ?? 0 );
			$doctor_id = absint( $row['doctor'] ?? 0 );
			$type      = ( $row['type'] ?? '' ) === 'staff' ? 'staff' : 'doctor';
			if ( $user_id && $doctor_id ) {
				$map[ $user_id ][] = array(
					'doctor' => $doctor_id,
					'type'   => $type,
				);
			}
		}
		HSB_Settings::save_user_doctor_map( $map );
		self::redirect_settings();
	}

	/**
	 * ذخیرهٔ پرچم‌های فعال‌سازی رزرو هر پزشک.
	 */
	public static function handle_save_flags(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hsb_save_flags' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$flags = isset( $_POST['flags'] ) ? (array) wp_unslash( $_POST['flags'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$all   = array();
		foreach ( HSB_Doctor::list_doctors() as $d ) {
			$all[ (int) $d['id'] ] = isset( $flags[ (int) $d['id'] ] ) || isset( $flags[ (string) $d['id'] ] ) ? 1 : 0;
		}
		HSB_Settings::save_doctor_booking_flags( $all );
		self::redirect_settings();
	}

	/**
	 * ارسال ایمیل آزمایشی واقعی و نمایش نتیجهٔ صادقانه.
	 */
	public static function handle_test_email(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hsb_test_email' ) ) {
			wp_die( 'دسترسی غیرمجاز.' );
		}
		$to     = isset( $_POST['test_email'] ) ? sanitize_email( wp_unslash( $_POST['test_email'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$result = HSB_Notifications::send_test( (string) $to );
		set_transient( 'hsb_test_email_result', $result, 60 );
		// بدون پرچم «ذخیره شد» — نتیجهٔ تست فقط از transient نمایش داده می‌شود تا با ذخیرهٔ تنظیمات اشتباه نشود.
		wp_safe_redirect( admin_url( 'admin.php?page=hsb-settings' ) );
		exit;
	}
}
