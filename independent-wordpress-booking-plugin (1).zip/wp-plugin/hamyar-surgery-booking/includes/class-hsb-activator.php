<?php
/**
 * فعال‌سازی، غیرفعال‌سازی و ارتقای نسخه‌بندی‌شدهٔ اسکیما.
 *
 * اصول:
 * - ساخت/ارتقا با dbDelta (غیرمخرب و تکرارپذیر).
 * - نسخهٔ اسکیما در wp_options ذخیره و هنگام ارتقای افزونه بازبینی می‌شود.
 * - غیرفعال‌سازی هیچ داده‌ای را حذف نمی‌کند.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت چرخهٔ حیات و اسکیما.
 */
final class HSB_Activator {

	/**
	 * نام جدول‌ها با پیشوند واقعی وردپرس.
	 *
	 * @param string $table کلید جدول: schedules|overrides|appointments.
	 */
	public static function table( string $table ): string {
		global $wpdb;
		$map = array(
			'schedules'    => $wpdb->prefix . 'hsb_schedules',
			'overrides'    => $wpdb->prefix . 'hsb_overrides',
			'appointments' => $wpdb->prefix . 'hsb_appointments',
		);
		return $map[ $table ];
	}

	/**
	 * فعال‌سازی: ساخت جداول + تنظیمات پیش‌فرض. هیچ دادهٔ موجودی دست نمی‌خورد.
	 */
	public static function activate(): void {
		self::create_or_upgrade_schema();
		HSB_Settings::ensure_defaults();
		// بازتولید rewrite برای REST معمولاً لازم نیست، اما برای سلامت پیوندهای یکتا در صورت نیاز آینده.
		flush_rewrite_rules();
	}

	/**
	 * غیرفعال‌سازی: عمداً هیچ داده‌ای حذف نمی‌شود.
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
		// داده‌ها و برنامه‌ها حفظ می‌شوند (طبق نیازمندی).
	}

	/**
	 * اجرای ارتقا هنگام تغییر نسخهٔ اسکیما یا نسخهٔ افزونه.
	 */
	public static function maybe_upgrade(): void {
		$installed = get_option( 'hsb_schema_version', '' );
		if ( HSB_SCHEMA_VERSION !== $installed ) {
			self::create_or_upgrade_schema();
		}
	}

	/**
	 * اجرای dbDelta روی تعریف جداول و به‌روزرسانی نسخهٔ اسکیما.
	 */
	public static function create_or_upgrade_schema(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( self::schema_statements() as $sql ) {
			dbDelta( $sql );
		}
		update_option( 'hsb_schema_version', HSB_SCHEMA_VERSION, false );
	}

	/**
	 * تعریف جداول. قالب‌بندی مطابق قواعد سخت‌گیرانهٔ dbDelta:
	 * هر فیلد در یک خط، دو فاصله قبل از PRIMARY KEY، استفاده از KEY به‌جای INDEX.
	 *
	 * @return string[]
	 */
	public static function schema_statements(): array {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$schedules    = self::table( 'schedules' );
		$overrides    = self::table( 'overrides' );
		$appointments = self::table( 'appointments' );

		// weekday: ۰=شنبه … ۶=جمعه (قرارداد داخلی افزونه، مستقل از date('w')).
		$sql_schedules = "CREATE TABLE $schedules (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			doctor_id BIGINT(20) UNSIGNED NOT NULL,
			weekday TINYINT(3) UNSIGNED NOT NULL,
			start_time TIME NOT NULL,
			end_time TIME NOT NULL,
			slot_length SMALLINT(5) UNSIGNED NOT NULL DEFAULT 30,
			capacity SMALLINT(5) UNSIGNED NOT NULL DEFAULT 1,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY doctor_weekday (doctor_id, weekday),
			KEY doctor_id (doctor_id)
		) $charset_collate;";

		$sql_overrides = "CREATE TABLE $overrides (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			doctor_id BIGINT(20) UNSIGNED NOT NULL,
			override_date DATE NOT NULL,
			is_closed TINYINT(1) NOT NULL DEFAULT 0,
			start_time TIME DEFAULT NULL,
			end_time TIME DEFAULT NULL,
			capacity SMALLINT(5) UNSIGNED DEFAULT NULL,
			reason VARCHAR(190) DEFAULT '',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY doctor_date (doctor_id, override_date),
			KEY doctor_id (doctor_id)
		) $charset_collate;";

		// پیامک/پرداخت در نسخهٔ ۱ پیاده نشده؛ ستون‌های وضعیت برای توسعهٔ آینده طراحی شده‌اند.
		$sql_appointments = "CREATE TABLE $appointments (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(20) NOT NULL,
			doctor_id BIGINT(20) UNSIGNED NOT NULL,
			patient_user_id BIGINT(20) UNSIGNED NOT NULL,
			patient_name VARCHAR(190) NOT NULL,
			patient_mobile VARCHAR(20) NOT NULL,
			patient_national_id VARCHAR(10) DEFAULT '',
			service_type VARCHAR(20) NOT NULL,
			description TEXT,
			appointment_date DATE NOT NULL,
			start_time TIME NOT NULL,
			end_time TIME NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'requested',
			idempotency_key VARCHAR(64) DEFAULT NULL,
			created_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY doctor_date (doctor_id, appointment_date),
			KEY patient_user_id (patient_user_id),
			KEY status (status)
		) $charset_collate;";

		return array( $sql_schedules, $sql_overrides, $sql_appointments );
	}
}
