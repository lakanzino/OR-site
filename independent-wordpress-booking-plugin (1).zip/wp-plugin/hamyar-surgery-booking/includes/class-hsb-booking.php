<?php
/**
 * موتور رزرو — درستی و ایمنی در برابر هم‌زمانی.
 *
 * راهبرد قفل:
 *  - هر رزرو ابتدا ردیف برنامهٔ هفتگیِ همان پزشک و همان روز هفته را با FOR UPDATE قفل می‌کند.
 *    این ردیف «نقطهٔ سریال‌سازی مشترک» برای همهٔ رزروهای همان پزشک/روز است (بر خلاف قفل‌کردنِ
 *    فقط ردیف‌های نوبت موجود که هنگام خالی‌بودن بازه هیچ چیزی را قفل نمی‌کند).
 *  - ظرفیت پس از گرفتن قفل دوباره محاسبه می‌شود؛ سپس درج می‌شود.
 *  - هر خطای پایگاه‌داده در تراکنش ⇒ ROLLBACK؛ خطاهای قابل‌تلاش‌مجدد (deadlock/قطعی اتصال) تا ۳ بار تکرار.
 *  - اگر نتیجهٔ COMMIT نامعلوم باشد (قطعی در لحظهٔ کامیت)، پاسخ «uncertain» صادقانه برمی‌گردد و
 *    کلید تکرارناپذیری تضمین می‌کند که تلاش مجدد کلاینت نوبت تکراری نسازد.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'HSB_TESTING' ) ) {
	exit;
}

/**
 * موتور رزرو.
 */
final class HSB_Booking {

	/** وضعیت‌های فعال که ظرفیت را اشغال می‌کنند. */
	public const ACTIVE_STATUSES = array( 'requested', 'confirmed' );

	/** حداکثر تلاش برای تراکنش‌های قابل‌تلاش‌مجدد. */
	private const MAX_ATTEMPTS = 3;

	/**
	 * برچسب فارسی وضعیت‌ها — تمایز روشن بین «ثبت درخواست»، «در انتظار تأیید مطب» و «تأییدشده».
	 */
	public static function status_label( string $status ): string {
		$labels = array(
			'requested'         => 'در انتظار تأیید مطب',
			'confirmed'         => 'تأییدشده',
			'cancelled_patient' => 'لغوشده توسط بیمار',
			'cancelled_clinic'  => 'لغوشده توسط مطب',
			'completed'         => 'انجام‌شده',
			'no_show'           => 'عدم مراجعه',
		);
		return $labels[ $status ] ?? $status;
	}

	/**
	 * گذارهای وضعیت مجاز از سمت مطب.
	 *
	 * @param string $from وضعیت فعلی.
	 * @return string[] وضعیت‌های مقصد مجاز.
	 */
	public static function allowed_transitions( string $from ): array {
		$map = array(
			'requested' => array( 'confirmed', 'cancelled_clinic' ),
			'confirmed' => array( 'completed', 'no_show', 'cancelled_clinic' ),
		);
		return $map[ $from ] ?? array();
	}

	/**
	 * ساخت کد پیگیری غیرقابل‌حدس (CSPRNG) — قالب HSB-XXXXXXXX.
	 */
	public static function generate_code(): string {
		$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // بدون کاراکترهای مشابه.
		$bytes    = random_bytes( 8 );
		$code     = '';
		for ( $i = 0; $i < 8; $i++ ) {
			$code .= $alphabet[ ord( $bytes[ $i ] ) & 31 ];
		}
		return 'HSB-' . $code;
	}

	/**
	 * یافتن نوبت با کلید تکرارناپذیری.
	 *
	 * @return object|null
	 */
	public static function find_by_idempotency_key( string $key ) {
		if ( '' === $key ) {
			return null;
		}
		global $wpdb;
		$table = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE idempotency_key = %s", $key ) );
	}

	/**
	 * یافتن نوبت با شناسه.
	 *
	 * @return object|null
	 */
	public static function find( int $id ) {
		global $wpdb;
		$table = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
	}

	/**
	 * نوبت‌های یک بیمار (فقط دادهٔ خودش).
	 *
	 * @return object[]
	 */
	public static function for_patient( int $user_id ): array {
		global $wpdb;
		$table = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE patient_user_id = %d ORDER BY appointment_date DESC, start_time DESC LIMIT 200",
				$user_id
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * آیا خطای پایگاه‌داده قابل تلاش مجدد است؟ (deadlock، timeout قفل، قطعی اتصال)
	 */
	public static function is_retryable_error( string $last_error ): bool {
		if ( '' === $last_error ) {
			return false;
		}
		$needles = array(
			'Deadlock found',            // 1213.
			'Lock wait timeout',         // 1205.
			'server has gone away',      // 2006.
			'Lost connection',           // 2013.
		);
		foreach ( $needles as $needle ) {
			if ( false !== stripos( $last_error, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * اعتبارسنجی کامل ورودی رزرو (سمت سرور؛ جدا از بررسی مرورگر).
	 *
	 * @param array $input ورودی خام.
	 * @return array{ok:true, data:array}|array{ok:false, error:string, message:string}
	 */
	public static function validate_booking_input( array $input ): array {
		$doctor_id = isset( $input['doctor_id'] ) ? absint( $input['doctor_id'] ) : 0;

		if ( ! $doctor_id || null === HSB_Doctor::get_public( $doctor_id ) ) {
			return array(
				'ok'      => false,
				'error'   => 'doctor_unavailable',
				'message' => 'رزرو داخلی برای این پزشک فعال نیست.',
			);
		}

		$date = isset( $input['date'] ) ? (string) $input['date'] : '';
		if ( ! HSB_Validator::date_ymd( $date ) ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_date',
				'message' => 'تاریخ انتخاب‌شده معتبر نیست.',
			);
		}
		$today = HSB_Jalali::today_local();
		$max   = gmdate( 'Y-m-d', strtotime( $today . ' +' . ( HSB_BOOKING_HORIZON_DAYS - 1 ) . ' days' ) );
		if ( $date < $today || $date > $max ) {
			return array(
				'ok'      => false,
				'error'   => 'date_out_of_range',
				'message' => 'تاریخ انتخاب‌شده خارج از بازهٔ مجاز رزرو است.',
			);
		}

		$time = isset( $input['time'] ) ? (string) $input['time'] : '';
		if ( ! HSB_Validator::time_hi( $time ) ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_time',
				'message' => 'ساعت انتخاب‌شده معتبر نیست.',
			);
		}
		if ( $date === $today && $time <= HSB_Jalali::now_local_hm() ) {
			return array(
				'ok'      => false,
				'error'   => 'time_passed',
				'message' => 'این ساعت گذشته است؛ لطفاً بازهٔ دیگری انتخاب کنید.',
			);
		}

		$name = isset( $input['patient_name'] ) ? trim( (string) $input['patient_name'] ) : '';
		if ( ! HSB_Validator::person_name( $name ) ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_name',
				'message' => 'نام و نام خانوادگی بیمار الزامی است (۲ تا ۱۰۰ نویسه).',
			);
		}

		$mobile = HSB_Validator::mobile( (string) ( $input['patient_mobile'] ?? '' ) );
		if ( '' === $mobile ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_mobile',
				'message' => 'شمارهٔ موبایل معتبر نیست. قالب صحیح: ۰۹xxxxxxxx',
			);
		}

		$national_id = HSB_Validator::national_id( (string) ( $input['patient_national_id'] ?? '' ) );
		if ( null === $national_id ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_national_id',
				'message' => 'کد ملی واردشده معتبر نیست. در صورت تمایل می‌توانید آن را خالی بگذارید.',
			);
		}

		$service = (string) ( $input['service_type'] ?? '' );
		if ( ! HSB_Validator::service_type( $service ) ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_service',
				'message' => 'نوع خدمت باید یکی از مشاوره، ویزیت یا جراحی باشد.',
			);
		}

		$description = HSB_Validator::description( (string) ( $input['description'] ?? '' ) );
		if ( null === $description ) {
			return array(
				'ok'      => false,
				'error'   => 'description_too_long',
				'message' => 'توضیحات حداکثر می‌تواند ۵۰۰ نویسه باشد.',
			);
		}

		return array(
			'ok'   => true,
			'data' => array(
				'doctor_id'           => $doctor_id,
				'date'                => $date,
				'time'                => $time,
				'patient_name'        => $name,
				'patient_mobile'      => $mobile,
				'patient_national_id' => $national_id,
				'service_type'        => $service,
				'description'         => $description,
			),
		);
	}

	/**
	 * ثبت نوبت با تراکنش + قفل اشتراکی روی ردیف برنامهٔ پزشک.
	 *
	 * @param array  $input           ورودی خام رزرو.
	 * @param int    $patient_user_id شناسهٔ کاربر واردشده (الزامی).
	 * @param string $idempotency_key کلید تکرارناپذیری از کلاینت.
	 * @return array{ok:bool, ...}
	 */
	public static function book( array $input, int $patient_user_id, string $idempotency_key ): array {
		global $wpdb;

		if ( $patient_user_id <= 0 ) {
			return array(
				'ok'      => false,
				'error'   => 'auth_required',
				'message' => 'برای دریافت نوبت ابتدا وارد حساب کاربری خود شوید.',
			);
		}

		$idem = HSB_Validator::idempotency_key( $idempotency_key );

		// تکرار امن: اگر همین کلید قبلاً ثبت شده، همان نوبت را برگردان (بدون ساخت تکراری).
		if ( '' !== $idem ) {
			$existing = self::find_by_idempotency_key( $idem );
			if ( $existing ) {
				return array(
					'ok'          => true,
					'duplicate'   => true,
					'appointment' => self::present_for_patient( $existing ),
					'message'     => 'این درخواست قبلاً ثبت شده است؛ نوبت تکراری ساخته نشد.',
				);
			}
		}

		$validation = self::validate_booking_input( $input );
		if ( ! $validation['ok'] ) {
			return $validation;
		}
		$data = $validation['data'];

		$table_a = HSB_Activator::table( 'appointments' );
		$table_s = HSB_Activator::table( 'schedules' );
		$table_o = HSB_Activator::table( 'overrides' );
		$weekday = HSB_Availability::weekday_of( $data['date'] );

		$attempt = 0;
		while ( $attempt < self::MAX_ATTEMPTS ) {
			$attempt++;

			// شروع تراکنش.
			$wpdb->query( 'START TRANSACTION' );

			// ۱) قفل اشتراکی روی ردیف برنامهٔ همین پزشک/روز هفته — نقطهٔ سریال‌سازی.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$schedule = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $table_s WHERE doctor_id = %d AND weekday = %d FOR UPDATE",
					$data['doctor_id'],
					$weekday
				)
			);
			if ( '' !== $wpdb->last_error ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}

			// ۲) قفل ردیف استثنای همین تاریخ (در صورت وجود) — ترتیب قفل‌ها همیشه یکسان.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$override = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $table_o WHERE doctor_id = %d AND override_date = %s FOR UPDATE",
					$data['doctor_id'],
					$data['date']
				)
			);
			if ( '' !== $wpdb->last_error ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}

			// ۳) پنجرهٔ مؤثر روز از منبع حقیقت (جداول افزونه) — بازبینی داخل قفل.
			$window = HSB_Availability_Calc::resolve_day( $schedule, $override );
			if ( ! $window['active'] || $window['holiday'] ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'day_unavailable',
					'message' => 'این روز برای رزرو فعال نیست؛ لطفاً روز دیگری را انتخاب کنید.',
				);
			}

			// ۴) انطباق بازهٔ درخواستی با برنامه.
			$slots = HSB_Availability_Calc::build_slots( $window['start'], $window['end'], $window['slot_length'] );
			if ( ! in_array( $data['time'], $slots, true ) ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'slot_mismatch',
					'message' => 'بازهٔ انتخاب‌شده با برنامهٔ پزشک هم‌خوانی ندارد.',
				);
			}

			// ۵) شمارش اشغال فعلیِ همین بازه — زیر سایهٔ قفل برنامه (سریال‌سازی).
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$used = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM $table_a
					 WHERE doctor_id = %d AND appointment_date = %s AND start_time = %s
					   AND status IN ('requested','confirmed')",
					$data['doctor_id'],
					$data['date'],
					$data['time'] . ':00'
				)
			);
			if ( '' !== $wpdb->last_error ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}
			if ( $used >= $window['capacity'] ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'slot_full',
					'message' => 'ظرفیت این بازه همین حالا تکمیل شد. لطفاً بازهٔ دیگری انتخاب کنید.',
				);
			}

			// ۶) درج نوبت — کد پیگیری یکتا با چند بار تلاش در برابر برخورد احتمالی.
			$end_time = gmdate( 'H:i:s', strtotime( '1970-01-01 ' . $data['time'] . ':00' ) + $window['slot_length'] * 60 );
			$inserted = false;
			for ( $code_try = 0; $code_try < 5 && ! $inserted; $code_try++ ) {
				$now = current_time( 'mysql' );
				$ok  = $wpdb->insert(
					$table_a,
					array(
						'code'                => self::generate_code(),
						'doctor_id'           => $data['doctor_id'],
						'patient_user_id'     => $patient_user_id,
						'patient_name'        => $data['patient_name'],
						'patient_mobile'      => $data['patient_mobile'],
						'patient_national_id' => $data['patient_national_id'],
						'service_type'        => $data['service_type'],
						'description'         => $data['description'],
						'appointment_date'    => $data['date'],
						'start_time'          => $data['time'] . ':00',
						'end_time'            => $end_time,
						'status'              => 'requested',
						'idempotency_key'     => ( '' !== $idem ) ? $idem : null,
						'created_by'          => $patient_user_id,
						'created_at'          => $now,
						'updated_at'          => $now,
					),
					array( '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
				);
				if ( $ok ) {
					$inserted = true;
					break;
				}
				// برخورد روی کلید تکرارناپذیری یعنی رقابتِ همان درخواست: همان را برگردان.
				if ( '' !== $idem && false !== stripos( $wpdb->last_error, 'Duplicate' ) ) {
					$wpdb->query( 'ROLLBACK' );
					$existing = self::find_by_idempotency_key( $idem );
					if ( $existing ) {
						return array(
							'ok'          => true,
							'duplicate'   => true,
							'appointment' => self::present_for_patient( $existing ),
							'message'     => 'این درخواست قبلاً ثبت شده است؛ نوبت تکراری ساخته نشد.',
						);
					}
					// برخورد روی کد پیگیری: تلاش مجدد با کد تازه.
					continue;
				}
				// خطای دیگر: شکست این تلاش.
				break;
			}

			if ( ! $inserted ) {
				$last = $wpdb->last_error;
				$wpdb->query( 'ROLLBACK' );
				if ( self::is_retryable_error( $last ) && $attempt < self::MAX_ATTEMPTS ) {
					continue;
				}
				return array(
					'ok'      => false,
					'error'   => 'db_error',
					'message' => 'ثبت نوبت به‌علت خطای پایگاه‌داده انجام نشد. چیزی ذخیره نشده است؛ لطفاً دوباره تلاش کنید.',
				);
			}

			// ۷) کامیت.
			$commit = $wpdb->query( 'COMMIT' );
			if ( false === $commit || '' !== $wpdb->last_error ) {
				// نتیجهٔ واقعی نامعلوم است؛ به بیمار «موفق» اعلام نمی‌کنیم.
				return array(
					'ok'        => false,
					'uncertain' => true,
					'error'     => 'commit_unknown',
					'message'   => 'وضعیت ثبت نوبت نامشخص شد (قطعی ارتباط در لحظهٔ نهایی). اگر دوباره تلاش کنید نوبت تکراری ساخته نمی‌شود؛ می‌توانید نتیجه را در بخش «نوبت‌های من» بررسی کنید.',
				);
			}

			$appointment = self::find( (int) $wpdb->insert_id );
			if ( $appointment ) {
				if ( has_action( 'hsb_appointment_created' ) || function_exists( 'do_action' ) ) {
					do_action( 'hsb_appointment_created', (int) $appointment->id, $appointment );
				}
				return array(
					'ok'          => true,
					'duplicate'   => false,
					'appointment' => self::present_for_patient( $appointment ),
					'message'     => 'درخواست نوبت شما ثبت شد. وضعیت فعلی: در انتظار تأیید مطب.',
				);
			}

			return array(
				'ok'        => false,
				'uncertain' => true,
				'error'     => 'readback_failed',
				'message'   => 'نتیجهٔ ثبت نامشخص است؛ لطفاً چند لحظهٔ دیگر بخش «نوبت‌های من» را بررسی کنید.',
			);
		}

		return array(
			'ok'      => false,
			'error'   => 'contention',
			'message' => 'به دلیل تداخل درخواست‌های هم‌زمان، ثبت انجام نشد. چیزی ذخیره نشده است؛ لطفاً دوباره تلاش کنید.',
		);
	}

	/**
	 * ROLLBACK و تصمیم دربارهٔ تلاش مجدد بر اساس نوع خطا.
	 *
	 * @param int $attempt شمارهٔ تلاش فعلی.
	 */
	private static function rollback_and_maybe_retry( int $attempt ): bool {
		global $wpdb;
		$retryable = self::is_retryable_error( (string) $wpdb->last_error );
		$wpdb->query( 'ROLLBACK' );
		return $retryable && $attempt < self::MAX_ATTEMPTS;
	}

	/**
	 * پاسخ صادقانهٔ خطای پایگاه‌داده.
	 */
	private static function db_failure_response(): array {
		return array(
			'ok'      => false,
			'error'   => 'db_error',
			'message' => 'خطای پایگاه‌داده رخ داد؛ هیچ نوبتی ذخیره نشد. لطفاً دوباره تلاش کنید و اگر تکرار شد به پشتیبانی اطلاع دهید.',
		);
	}

	/**
	 * لغو نوبت — هم برای بیمار (با سیاست لغو) هم برای مطب.
	 *
	 * @param int    $appointment_id شناسهٔ نوبت.
	 * @param int    $user_id        کاربر درخواست‌کننده.
	 * @param string $actor          'patient' یا 'clinic'.
	 */
	public static function cancel( int $appointment_id, int $user_id, string $actor = 'patient' ): array {
		global $wpdb;
		$table_a = HSB_Activator::table( 'appointments' );

		$attempt = 0;
		while ( $attempt < self::MAX_ATTEMPTS ) {
			$attempt++;
			$wpdb->query( 'START TRANSACTION' );

			// قفل ردیف خود نوبت — تغییر وضعیت فقط یک‌بار موفق می‌شود.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$appointment = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM $table_a WHERE id = %d FOR UPDATE", $appointment_id )
			);
			if ( '' !== $wpdb->last_error ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}
			if ( ! $appointment ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'not_found',
					'message' => 'نوبت مورد نظر یافت نشد.',
				);
			}

			if ( 'patient' === $actor ) {
				// بررسی مالکیت: بیمار فقط نوبت خودش را لغو می‌کند.
				if ( (int) $appointment->patient_user_id !== $user_id ) {
					$wpdb->query( 'ROLLBACK' );
					return array(
						'ok'      => false,
						'error'   => 'forbidden',
						'message' => 'شما فقط می‌توانید نوبت‌های خودتان را لغو کنید.',
					);
				}
				// سیاست لغو: وضعیت مجاز.
				$cancellable = array( 'requested' );
				if ( HSB_Settings::get( 'patient_can_cancel_confirmed', 0 ) ) {
					$cancellable[] = 'confirmed';
				}
				if ( ! in_array( $appointment->status, $cancellable, true ) ) {
					$wpdb->query( 'ROLLBACK' );
					return array(
						'ok'      => false,
						'error'   => 'not_cancellable',
						'message' => 'این نوبت در وضعیت فعلی قابل لغو نیست. برای تغییر با مطب تماس بگیرید.',
					);
				}
				// سیاست لغو: مهلت زمانی.
				$cutoff   = (int) HSB_Settings::get( 'cancel_cutoff_hours', 24 );
				$start_ts = strtotime( $appointment->appointment_date . ' ' . $appointment->start_time );
				if ( ( $start_ts - HSB_Jalali::now_ts() ) < $cutoff * HOUR_IN_SECONDS_HSB ) {
					$wpdb->query( 'ROLLBACK' );
					return array(
						'ok'      => false,
						'error'   => 'cutoff_passed',
						'message' => sprintf( 'مهلت لغو این نوبت (تا %d ساعت قبل از نوبت) سپری شده است.', $cutoff ),
					);
				}
			} else {
				// لغو از سمت مطب: کاربر باید مجاز به همان پزشک باشد (فراخوانندهٔ REST بررسی می‌کند).
				if ( ! in_array( $appointment->status, self::ACTIVE_STATUSES, true ) && 'completed' !== $appointment->status ) {
					$wpdb->query( 'ROLLBACK' );
					return array(
						'ok'      => false,
						'error'   => 'not_cancellable',
						'message' => 'این نوبت قبلاً نهایی شده است.',
					);
				}
			}

			$previous   = $appointment->status;
			$new_status = 'patient' === $actor ? 'cancelled_patient' : 'cancelled_clinic';

			// به‌روزرسانی شرطی: فقط اگر وضعیت هنوز همان است — ضد تکرارِ بی‌صدا.
			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE $table_a SET status = %s, updated_at = %s WHERE id = %d AND status = %s",
					$new_status,
					current_time( 'mysql' ),
					$appointment_id,
					$previous
				)
			);
			if ( false === $updated ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}
			if ( 0 === $updated ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'already_changed',
					'message' => 'وضعیت این نوبت هم‌اکنون توسط درخواست دیگری تغییر کرد؛ صفحه را تازه‌سازی کنید.',
				);
			}

			$commit = $wpdb->query( 'COMMIT' );
			if ( false === $commit || '' !== $wpdb->last_error ) {
				return array(
					'ok'        => false,
					'uncertain' => true,
					'error'     => 'commit_unknown',
					'message'   => 'نتیجهٔ لغو نامشخص شد؛ لطفاً صفحه را تازه‌سازی کنید و وضعیت را بررسی نمایید.',
				);
			}

			if ( function_exists( 'do_action' ) ) {
				do_action( 'hsb_appointment_status_changed', $appointment_id, $new_status, $previous );
			}
			return array(
				'ok'      => true,
				'message' => 'نوبت با موفقیت لغو شد.',
				'status'  => $new_status,
			);
		}

		return array(
			'ok'      => false,
			'error'   => 'contention',
			'message' => 'به دلیل تداخل درخواست‌ها لغو انجام نشد؛ لطفاً دوباره تلاش کنید.',
		);
	}

	/**
	 * تغییر وضعیت از سمت مطب (تأیید، انجام‌شدن، عدم مراجعه) با تراکنش و به‌روزرسانی شرطی.
	 */
	public static function set_status( int $appointment_id, string $new_status, int $user_id ): array {
		global $wpdb;
		$table_a = HSB_Activator::table( 'appointments' );

		if ( ! in_array( $new_status, array( 'confirmed', 'completed', 'no_show' ), true ) ) {
			return array(
				'ok'      => false,
				'error'   => 'invalid_status',
				'message' => 'وضعیت مقصد نامعتبر است.',
			);
		}

		$attempt = 0;
		while ( $attempt < self::MAX_ATTEMPTS ) {
			$attempt++;
			$wpdb->query( 'START TRANSACTION' );

			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$appointment = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM $table_a WHERE id = %d FOR UPDATE", $appointment_id )
			);
			if ( '' !== $wpdb->last_error ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}
			if ( ! $appointment ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'not_found',
					'message' => 'نوبت مورد نظر یافت نشد.',
				);
			}
			if ( ! HSB_Access::can_change_status( $user_id, $appointment ) ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'forbidden',
					'message' => 'شما مجاز به تغییر وضعیت این نوبت نیستید.',
				);
			}
			if ( ! in_array( $new_status, self::allowed_transitions( $appointment->status ), true ) ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'invalid_transition',
					'message' => sprintf(
						'تغییر وضعیت از «%s» به «%s» مجاز نیست.',
						self::status_label( $appointment->status ),
						self::status_label( $new_status )
					),
				);
			}

			$previous = $appointment->status;
			$updated  = $wpdb->query(
				$wpdb->prepare(
					"UPDATE $table_a SET status = %s, updated_at = %s WHERE id = %d AND status = %s",
					$new_status,
					current_time( 'mysql' ),
					$appointment_id,
					$previous
				)
			);
			if ( false === $updated ) {
				if ( self::rollback_and_maybe_retry( $attempt ) ) {
					continue;
				}
				return self::db_failure_response();
			}
			if ( 0 === $updated ) {
				$wpdb->query( 'ROLLBACK' );
				return array(
					'ok'      => false,
					'error'   => 'already_changed',
					'message' => 'وضعیت این نوبت هم‌اکنون تغییر کرده است؛ صفحه را تازه‌سازی کنید.',
				);
			}

			$commit = $wpdb->query( 'COMMIT' );
			if ( false === $commit || '' !== $wpdb->last_error ) {
				return array(
					'ok'        => false,
					'uncertain' => true,
					'error'     => 'commit_unknown',
					'message'   => 'نتیجهٔ تغییر وضعیت نامشخص شد؛ لطفاً صفحهٔ نوبت‌ها را تازه‌سازی کنید.',
				);
			}

			if ( function_exists( 'do_action' ) ) {
				do_action( 'hsb_appointment_status_changed', $appointment_id, $new_status, $previous );
			}
			return array(
				'ok'      => true,
				'message' => sprintf( 'وضعیت نوبت به «%s» تغییر کرد.', self::status_label( $new_status ) ),
				'status'  => $new_status,
			);
		}

		return array(
			'ok'      => false,
			'error'   => 'contention',
			'message' => 'به دلیل تداخل درخواست‌ها تغییر انجام نشد؛ لطفاً دوباره تلاش کنید.',
		);
	}

	/**
	 * نمایش امن نوبت برای خود بیمار.
	 */
	public static function present_for_patient( object $appointment ): array {
		return array(
			'id'           => (int) $appointment->id,
			'code'         => (string) $appointment->code,
			'doctor_id'    => (int) $appointment->doctor_id,
			'doctor_name'  => self::doctor_name_for( (int) $appointment->doctor_id ),
			'patient_name' => (string) $appointment->patient_name,
			'service'      => (string) $appointment->service_type,
			'service_fa'   => HSB_Validator::service_label( (string) $appointment->service_type ),
			'date'         => (string) $appointment->appointment_date,
			'date_fa'      => HSB_Jalali::label( (string) $appointment->appointment_date, true ),
			'time_fa'      => HSB_Jalali::fa_digits( substr( (string) $appointment->start_time, 0, 5 ) ),
			'status'       => (string) $appointment->status,
			'status_fa'    => self::status_label( (string) $appointment->status ),
		);
	}

	/**
	 * نمایش نوبت برای مطب — شامل اطلاعات تماس بیمار (فقط برای مجازین بررسی می‌شود).
	 */
	public static function present_for_clinic( object $appointment ): array {
		$base                       = self::present_for_patient( $appointment );
		$base['patient_mobile']     = (string) $appointment->patient_mobile;
		$base['patient_national_id'] = (string) ( $appointment->patient_national_id ?? '' );
		$base['description']        = (string) ( $appointment->description ?? '' );
		return $base;
	}

	/**
	 * نام پزشک با دورریخت امن.
	 */
	private static function doctor_name_for( int $doctor_id ): string {
		$public = HSB_Doctor::get_public( $doctor_id );
		if ( $public ) {
			return $public['name'];
		}
		// نوبت قدیمی ممکن است به پزشکِ غیرفعال‌شده اشاره کند؛ نام را بدون وابستگی به فعال‌بودن رزرو بخوان.
		if ( function_exists( 'get_post' ) ) {
			$post = get_post( $doctor_id );
			if ( $post ) {
				return get_the_title( $post );
			}
			$user = get_userdata( $doctor_id );
			if ( $user ) {
				return $user->display_name;
			}
		}
		return sprintf( 'پزشک #%d', $doctor_id );
	}
}

if ( ! defined( 'HOUR_IN_SECONDS_HSB' ) ) {
	define( 'HOUR_IN_SECONDS_HSB', 3600 );
}
