<?php
/**
 * شورت‌کدهای فرانت‌اند.
 *
 *  [hsb_booking]            فرم رزرو — doctor_id="123" یا "auto" (تشخیص از صفحهٔ پزشک)
 *  [hsb_my_appointments]    نوبت‌های بیمار + لغو
 *  [hsb_schedule_manager]   ویرایش برنامهٔ هفتگی/استثناها برای پزشک/منشی مجاز  doctor_id="123"
 *
 * این شورت‌کدها هیچ‌کدام شورت‌کد یا قابلیت موجود سایت را تغییر نمی‌دهند؛ لینک تماس/واتساپ
 * موجود در صفحهٔ پزشک دست‌نخورده باقی می‌ماند. اگر رزرو داخلی پزشکی غیرفعال باشد، پیام روشن
 * نمایش داده می‌شود (و کاربر می‌تواند از همان لینک‌های تماس موجود استفاده کند).
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * شورت‌کدها.
 */
final class HSB_Shortcodes {

	/**
	 * ثبت شورت‌کدها.
	 */
	public static function register(): void {
		add_shortcode( 'hsb_booking', array( __CLASS__, 'booking_form' ) );
		add_shortcode( 'hsb_my_appointments', array( __CLASS__, 'my_appointments' ) );
		add_shortcode( 'hsb_schedule_manager', array( __CLASS__, 'schedule_manager' ) );
	}

	/**
	 * تشخیص doctor_id از ویژگی شورت‌کد یا زمینهٔ صفحه.
	 *
	 * @param array|string $atts ویژگی‌ها.
	 */
	private static function resolve_doctor_id( $atts ): int {
		$atts = shortcode_atts( array( 'doctor_id' => 'auto' ), is_array( $atts ) ? $atts : array() );
		$raw  = (string) $atts['doctor_id'];
		if ( 'auto' !== $raw ) {
			return absint( $raw );
		}
		// حالت auto: اگر در صفحهٔ تکیِ نوع محتوای پزشکِ پیکربندی‌شده هستیم، همان شناسه را بردار.
		$provider  = HSB_Settings::get( 'doctor_provider', 'none' );
		$post_type = (string) HSB_Settings::get( 'doctor_post_type', '' );
		if ( 'cpt' === $provider && '' !== $post_type && is_singular( $post_type ) ) {
			return (int) get_the_ID();
		}
		return 0;
	}

	/**
	 * شورت‌کد فرم رزرو.
	 *
	 * @param array|string $atts ویژگی‌ها.
	 */
	public static function booking_form( $atts ): string {
		$doctor_id = self::resolve_doctor_id( $atts );

		// Enqueue فقط در همینجا.
		wp_enqueue_style( 'hsb-frontend' );
		wp_enqueue_script( 'hsb-frontend' );

		if ( ! $doctor_id ) {
			return self::notice_box(
				'برای نمایش فرم نوبت‌دهی، شناسهٔ پزشک مشخص نشده یا این صفحه به پروفایل پزشک متصل نیست.',
				'warning'
			);
		}

		$doctor = HSB_Doctor::get_public( $doctor_id );
		if ( ! $doctor ) {
			// پیام روشن + حفظ مسیر جایگزین: شورت‌کد چیزی از صفحه حذف نمی‌کند؛
			// لینک‌های تماس/واتساپ موجود صفحه همان‌طور که هست باقی می‌ماند.
			return self::notice_box(
				'رزرو آنلاین برای این پزشک در حال حاضر فعال نیست. برای گرفتن نوبت از راه‌های تماس موجود در همین صفحه (تلفن یا واتساپ) استفاده کنید.',
				'info'
			);
		}

		HSB_Plugin::localize_frontend(
			array(
				'mode'      => 'booking',
				'doctorId'  => $doctor_id,
				'doctorName'=> $doctor['name'],
			)
		);

		return '<div class="hsb-app hsb-booking" data-hsb-booking="' . esc_attr( (string) $doctor_id ) . '" aria-live="polite">'
			. '<noscript>' . esc_html__( 'برای رزرو آنلاین به جاوااسکریپت نیاز است.', 'hamyar-surgery-booking' ) . '</noscript>'
			. '</div>';
	}

	/**
	 * شورت‌کد نوبت‌های من.
	 */
	public static function my_appointments(): string {
		wp_enqueue_style( 'hsb-frontend' );
		wp_enqueue_script( 'hsb-frontend' );

		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( get_permalink() );
			return self::notice_box(
				sprintf(
					'برای مشاهدهٔ نوبت‌های خود ابتدا <a href="%s">وارد حساب کاربری</a> شوید.',
					esc_url( $login_url )
				),
				'info',
				true
			);
		}

		HSB_Plugin::localize_frontend( array( 'mode' => 'my_appointments' ) );

		return '<div class="hsb-app hsb-my-appointments" data-hsb-my="1" aria-live="polite"></div>';
	}

	/**
	 * شورت‌کد مدیریت برنامهٔ پزشک (برای پزشک/منشی مجاز بدون ورود به پیشخوان وردپرس).
	 *
	 * @param array|string $atts ویژگی‌ها.
	 */
	public static function schedule_manager( $atts ): string {
		wp_enqueue_style( 'hsb-frontend' );
		wp_enqueue_script( 'hsb-schedule' );

		if ( ! is_user_logged_in() ) {
			return self::notice_box(
				sprintf(
					'برای مدیریت برنامه ابتدا <a href="%s">وارد حساب کاربری</a> شوید.',
					esc_url( wp_login_url( get_permalink() ) )
				),
				'info',
				true
			);
		}

		$atts      = shortcode_atts( array( 'doctor_id' => 0 ), is_array( $atts ) ? $atts : array() );
		$doctor_id = absint( $atts['doctor_id'] );
		$user_id   = get_current_user_id();

		// اگر doctor_id داده نشده، اولین پزشکِ متصل به کاربر را پیشنهاد بده.
		if ( ! $doctor_id ) {
			$ids = HSB_Access::manageable_doctor_ids( $user_id );
			if ( 1 === count( $ids ) ) {
				$doctor_id = $ids[0];
			}
		}

		if ( ! $doctor_id || ! HSB_Access::can_manage_doctor( $user_id, $doctor_id ) ) {
			return self::notice_box(
				'شما به برنامهٔ هیچ پزشکی متصل نیستید یا شناسهٔ پزشک نامعتبر است. اتصال حساب شما به پروفایل پزشک را با مدیر سایت هماهنگ کنید.',
				'warning'
			);
		}

		wp_localize_script(
			'hsb-schedule',
			'HSB_SCHEDULE',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'hsb/v1/' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'doctorId' => $doctor_id,
			)
		);

		return '<div class="hsb-app hsb-schedule-manager" data-hsb-schedule="' . esc_attr( (string) $doctor_id ) . '"></div>';
	}

	/**
	 * جعبهٔ پیام استاندارد.
	 *
	 * @param string $message پیام (ممکن است HTML امن شامل لینک باشد).
	 * @param string $type    info|warning.
	 * @param bool   $allow_html اجازهٔ HTML ساده (فقط لینک) در پیام.
	 */
	private static function notice_box( string $message, string $type = 'info', bool $allow_html = false ): string {
		// استایل inline مینیمال تا حتی بدون CSS افزونه هم خوانا بماند.
		$border = 'warning' === $type ? '#8a6d00' : '#1a4f8b';
		$bg     = 'warning' === $type ? '#fff8e1' : '#eef5ff';
		$text   = $allow_html ? wp_kses_post( $message ) : esc_html( $message );
		return sprintf(
			'<div class="hsb-notice hsb-notice-%1$s" role="status" style="direction:rtl;text-align:right;border:1px solid %2$s;background:%3$s;color:#222;padding:14px 18px;border-radius:12px">%4$s</div>',
			esc_attr( $type ),
			esc_attr( $border ),
			esc_attr( $bg ),
			$text
		);
	}
}
