<?php
/**
 * اعلان‌رسانی ایمیلی — پیش‌فرض خاموش و فقط با پیکربندی + تست واقعی مدیر فعال می‌شود.
 *
 * اصول:
 *  - پیامک/OTP در نسخهٔ ۱ پیاده‌سازی نشده (ارائه‌دهنده مشخص نیست)؛ این فایل فقط ایمیل است.
 *  - شکست ارسال ایمیل هرگز بی‌صدا موفق اعلام نمی‌شود و وضعیت واقعی نوبت را تغییر نمی‌دهد؛
 *    خطا در تنظیمات ثبت و به مدیر نمایش داده می‌شود (بدون ذخیرهٔ دادهٔ حساس بیمار در لاگ).
 *  - ورود با Google (Nextend) تأیید مالکیت موبایل نیست؛ به همین دلیل ارسال پیامک خودکار نداریم.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اعلان‌های ایمیلی.
 */
final class HSB_Notifications {

	/**
	 * اتصال رویدادها — فقط در صورت فعال‌بودن.
	 */
	public static function hooks(): void {
		add_action( 'hsb_appointment_created', array( __CLASS__, 'on_created' ), 10, 2 );
		add_action( 'hsb_appointment_status_changed', array( __CLASS__, 'on_status_changed' ), 10, 3 );
	}

	/**
	 * آیا اعلان فعال است؟
	 */
	public static function enabled(): bool {
		return (bool) HSB_Settings::get( 'email_notifications', 0 ) && '' !== (string) HSB_Settings::get( 'clinic_email', '' );
	}

	/**
	 * رویداد ثبت نوبت.
	 *
	 * @param object $appointment ردیف نوبت.
	 */
	public static function on_created( int $appointment_id, $appointment ): void {
		if ( ! self::enabled() || ! $appointment ) {
			return;
		}
		$patient_email = self::patient_email( (int) $appointment->patient_user_id );
		$summary       = self::summary_lines( $appointment );

		if ( $patient_email ) {
			self::send(
				$patient_email,
				'ثبت درخواست نوبت — در انتظار تأیید مطب',
				"سلام؛ درخواست نوبت شما ثبت شد و «در انتظار تأیید مطب» است.\n\n" . $summary . "\n\nکد پیگیری: {$appointment->code}\n\nتا زمان تأیید مطب، نوبت شما نهایی نیست."
			);
		}
		self::send(
			(string) HSB_Settings::get( 'clinic_email' ),
			'درخواست نوبت جدید',
			"یک درخواست نوبت جدید ثبت شد:\n\n" . $summary . "\n\nکد پیگیری: {$appointment->code}"
		);
	}

	/**
	 * رویداد تغییر وضعیت.
	 */
	public static function on_status_changed( int $appointment_id, string $new_status, string $previous ): void {
		if ( ! self::enabled() ) {
			return;
		}
		$appointment = HSB_Booking::find( $appointment_id );
		if ( ! $appointment ) {
			return;
		}
		$patient_email = self::patient_email( (int) $appointment->patient_user_id );
		if ( ! $patient_email ) {
			return;
		}
		$labels = array(
			'confirmed'         => 'نوبت شما تأیید شد',
			'cancelled_clinic'  => 'نوبت شما توسط مطب لغو شد',
			'completed'         => 'نوبت شما انجام شد',
			'no_show'           => 'ثبت عدم مراجعه برای نوبت شما',
			'cancelled_patient' => 'لغو نوبت شما ثبت شد',
		);
		$subject = $labels[ $new_status ] ?? 'تغییر وضعیت نوبت';
		self::send(
			$patient_email,
			$subject,
			$subject . ".\n\n" . self::summary_lines( $appointment ) . "\n\nکد پیگیری: {$appointment->code}"
		);
	}

	/**
	 * متن خلاصهٔ نوبت (بدون کد ملی/توضیحات حساس در ایمیل).
	 *
	 * @param object $appointment ردیف نوبت.
	 */
	private static function summary_lines( $appointment ): string {
		$doctor = HSB_Booking::present_for_patient( $appointment );
		return sprintf(
			"پزشک: %s\nتاریخ: %s\nساعت: %s\nنوع خدمت: %s\nوضعیت: %s",
			$doctor['doctor_name'],
			$doctor['date_fa'],
			$doctor['time_fa'],
			$doctor['service_fa'],
			$doctor['status_fa']
		);
	}

	/**
	 * ایمیل کاربر بیمار از حساب وردپرسی‌اش.
	 */
	private static function patient_email( int $user_id ): string {
		$user = get_userdata( $user_id );
		$email = $user ? (string) $user->user_email : '';
		return is_email( $email ) ? $email : '';
	}

	/**
	 * ارسال امن ایمیل با ثبت خطای واقعی در صورت شکست.
	 *
	 * @return bool نتیجهٔ ارسال.
	 */
	public static function send( string $to, string $subject, string $body ): bool {
		if ( '' === $to ) {
			return false;
		}
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

		$sent = wp_mail( $to, '[همیار جراحی] ' . $subject, $body, $headers );
		if ( ! $sent ) {
			// خطای واقعی ثبت و به مدیر نشان داده می‌شود؛ بدون دادهٔ حساس بیمار در متن خطا.
			$settings                    = HSB_Settings::all();
			$settings['email_last_error'] = sprintf(
				'آخرین شکست ارسال ایمیل: %s — گیرنده: %s',
				current_time( 'mysql' ),
				self::mask_email( $to )
			);
			HSB_Settings::update( $settings );
		}
		return (bool) $sent;
	}

	/**
	 * پنهان‌سازی بخشی از ایمیل برای ثبت خطا.
	 */
	private static function mask_email( string $email ): string {
		$parts = explode( '@', $email );
		if ( 2 !== count( $parts ) ) {
			return '***';
		}
		return substr( $parts[0], 0, 2 ) . '***@' . $parts[1];
	}

	/**
	 * تست واقعی ارسال ایمیل (از صفحهٔ تنظیمات) — نتیجهٔ صادقانه برمی‌گردد.
	 *
	 * @return array{ok:bool, message:string}
	 */
	public static function send_test( string $to ): array {
		if ( ! is_email( $to ) ) {
			return array(
				'ok'      => false,
				'message' => 'نشانی ایمیل گیرندهٔ تست معتبر نیست.',
			);
		}
		$sent = self::send( $to, 'ایمیل آزمایشی نوبت‌دهی', 'این یک ایمیل آزمایشی از افزونهٔ نوبت‌دهی همیار جراحی است. اگر آن را دریافت کردید، اعلان‌ها به‌درستی کار می‌کنند.' );
		if ( $sent ) {
			return array(
				'ok'      => true,
				'message' => 'ایمیل آزمایشی با موفقیت به صف ارسال سپرده شد. صندوق گیرنده را بررسی کنید؛ تضمین تحویل به عهدهٔ سرویس ایمیل سایت است.',
			);
		}
		return array(
			'ok'      => false,
			'message' => 'ارسال ایمیل آزمایشی شکست خورد. اعلان‌ها را غیرفعال بگذارید یا سرویس ایمیل سایت (SMTP) را بررسی کنید.',
		);
	}
}
