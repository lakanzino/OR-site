<?php
/**
 * لایهٔ اتصال به پزشکان موجود سایت (Doctor Provider).
 *
 * این لایه هیچ ساختار سامانهٔ موجود را حدس نمی‌زند؛ دو روش اتصال قابل تنظیم ارائه می‌دهد:
 *  1) cpt   : نوع محتوای پزشک (پیش‌فرض 'doctor') + رابطهٔ حساب کاربری (post_author یا کلید متا).
 *  2) users : کاربران وردپرس دارای نقش‌های انتخابی (شناسهٔ پزشک = شناسهٔ کاربر، به‌صورت انتخابی).
 *
 * تا وقتی مدیر رابطهٔ واقعی را در تنظیمات مشخص نکرده، رزرو برای هیچ پزشکی فعال نمی‌شود.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * لایهٔ اتصال پزشکان.
 */
final class HSB_Doctor {

	/**
	 * آیا اتصال پزشکان به‌صورت معتبر پیکربندی شده است؟
	 */
	public static function provider_is_configured(): bool {
		$provider = HSB_Settings::get( 'doctor_provider', 'none' );
		if ( 'cpt' === $provider ) {
			$post_type = (string) HSB_Settings::get( 'doctor_post_type', '' );
			if ( '' === $post_type || ! post_type_exists( $post_type ) ) {
				return false;
			}
			if ( 'meta_key' === HSB_Settings::get( 'doctor_relation' ) && '' === (string) HSB_Settings::get( 'doctor_relation_meta_key', '' ) ) {
				return false;
			}
			return true;
		}
		if ( 'users' === $provider ) {
			$roles = (array) HSB_Settings::get( 'doctor_roles', array() );
			return ! empty( $roles );
		}
		return false;
	}

	/**
	 * فهرست پزشکان قابل استفاده در تنظیمات/برنامه‌ریزی.
	 *
	 * @return array<int, array{id:int, name:string}>
	 */
	public static function list_doctors(): array {
		if ( ! self::provider_is_configured() ) {
			return array();
		}
		$provider = HSB_Settings::get( 'doctor_provider' );
		if ( 'cpt' === $provider ) {
			$posts = get_posts(
				array(
					'post_type'      => HSB_Settings::get( 'doctor_post_type' ),
					'post_status'    => array( 'publish', 'private' ),
					'posts_per_page' => 500,
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				)
			);
			$out = array();
			foreach ( $posts as $p ) {
				$out[] = array(
					'id'   => (int) $p->ID,
					'name' => get_the_title( $p ),
				);
			}
			return $out;
		}
		// provider = users.
		$users = get_users(
			array(
				'role__in' => (array) HSB_Settings::get( 'doctor_roles', array() ),
				'number'   => 500,
				'orderby'  => 'display_name',
				'order'    => 'ASC',
				'fields'   => array( 'ID', 'display_name' ),
			)
		);
		$out = array();
		foreach ( $users as $u ) {
			$out[] = array(
				'id'   => (int) $u->ID,
				'name' => $u->display_name,
			);
		}
		return $out;
	}

	/**
	 * اطلاعات پایهٔ یک پزشک برای نمایش عمومی (نام؛ بدون دادهٔ بیمار).
	 *
	 * @return array{id:int, name:string}|null
	 */
	public static function get_public( int $doctor_id ): ?array {
		if ( ! self::provider_is_configured() || ! self::booking_is_enabled_for( $doctor_id ) ) {
			return null;
		}
		$provider = HSB_Settings::get( 'doctor_provider' );
		if ( 'cpt' === $provider ) {
			$post = get_post( $doctor_id );
			if ( ! $post || $post->post_type !== HSB_Settings::get( 'doctor_post_type' ) || 'publish' !== $post->post_status ) {
				return null;
			}
			return array(
				'id'   => $doctor_id,
				'name' => get_the_title( $post ),
			);
		}
		$user = get_userdata( $doctor_id );
		if ( ! $user ) {
			return null;
		}
		$roles = (array) HSB_Settings::get( 'doctor_roles', array() );
		if ( empty( array_intersect( $roles, (array) $user->roles ) ) ) {
			return null;
		}
		return array(
			'id'   => $doctor_id,
			'name' => $user->display_name,
		);
	}

	/**
	 * آیا رزرو داخلی برای این پزشک فعال است؟
	 */
	public static function booking_is_enabled_for( int $doctor_id ): bool {
		if ( ! self::provider_is_configured() ) {
			return false;
		}
		$flags = HSB_Settings::doctor_booking_enabled();
		// پیش‌فرض: فعال، مگر اینکه مدیر صریحاً غیرفعال کرده باشد.
		return ! isset( $flags[ $doctor_id ] ) || 1 === (int) $flags[ $doctor_id ];
	}

	/**
	 * نوع رابطهٔ یک کاربر با یک پروفایل پزشک:
	 * 'owner' (مالک حساب/پروفایل = خود پزشک)، 'staff' (منشی/کارمند نگاشت‌شده) یا null.
	 *
	 * توجه: شناسهٔ کاربر هرگز «معادل» شناسهٔ پروفایل فرض نمی‌شود؛ رابطه از تنظیمات/نگاشت خوانده می‌شود.
	 */
	public static function relation_type( int $user_id, int $doctor_id ): ?string {
		if ( ! $user_id || ! $doctor_id ) {
			return null;
		}
		// ۱) نگاشت صریح افزونه (تنظیم‌شده توسط مدیر).
		$map = HSB_Settings::user_doctor_map();
		foreach ( $map[ $user_id ] ?? array() as $entry ) {
			if ( (int) ( $entry['doctor'] ?? 0 ) === $doctor_id ) {
				return ( 'staff' === ( $entry['type'] ?? '' ) ) ? 'staff' : 'owner';
			}
		}
		// ۲) رابطهٔ تعریف‌شدهٔ لایهٔ اتصال.
		if ( self::provider_is_configured() ) {
			$provider = HSB_Settings::get( 'doctor_provider' );
			if ( 'cpt' === $provider ) {
				$post = get_post( $doctor_id );
				if ( $post && $post->post_type === HSB_Settings::get( 'doctor_post_type' ) ) {
					if ( 'post_author' === HSB_Settings::get( 'doctor_relation' ) ) {
						if ( (int) $post->post_author === $user_id ) {
							return 'owner';
						}
					} else {
						$key = (string) HSB_Settings::get( 'doctor_relation_meta_key', '' );
						if ( '' !== $key && (int) get_post_meta( $doctor_id, $key, true ) === $user_id ) {
							return 'owner';
						}
					}
				}
			} elseif ( 'users' === $provider && $user_id === $doctor_id ) {
				$user = get_userdata( $user_id );
				if ( $user && array_intersect( (array) HSB_Settings::get( 'doctor_roles', array() ), (array) $user->roles ) ) {
					return 'owner'; // در حالت users شناسهٔ پزشک = کاربر، فقط برای نقش‌های انتخابی.
				}
			}
		}
		return null;
	}
}
