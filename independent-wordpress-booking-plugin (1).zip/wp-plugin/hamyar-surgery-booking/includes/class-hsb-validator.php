<?php
/**
 * اعتبارسنجی ورودی‌ها — سمت سرور، جدا از منطق نمایش.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'HSB_TESTING' ) ) {
	exit;
}

/**
 * کلاس اعتبارسنجی.
 */
final class HSB_Validator {

	/** حداکثر طول توضیح بیمار. */
	public const MAX_DESC_LENGTH = 500;

	/** انواع خدمت مجاز. */
	public const SERVICE_TYPES = array( 'consult', 'visit', 'surgery' );

	/**
	 * برچسب فارسی نوع خدمت.
	 */
	public static function service_label( string $type ): string {
		$labels = array(
			'consult' => 'مشاوره',
			'visit'   => 'ویزیت',
			'surgery' => 'جراحی',
		);
		return $labels[ $type ] ?? $type;
	}

	/**
	 * اعتبارسنجی موبایل ایران: ۰۹xxxxxxxx (ارقام فارسی/عربی هم پذیرفته و نرمال می‌شوند).
	 *
	 * @return string موبایل نرمال‌شده یا رشتهٔ خالی در صورت نامعتبربودن.
	 */
	public static function mobile( string $raw ): string {
		$normalized = HSB_Jalali::normalize_digits( trim( $raw ) );
		$normalized = preg_replace( '/[\s\-]+/', '', $normalized );
		// پشتیبانی از قالب +98 یا 0098.
		if ( 0 === strpos( $normalized, '+98' ) ) {
			$normalized = '0' . substr( $normalized, 3 );
		} elseif ( 0 === strpos( $normalized, '0098' ) ) {
			$normalized = '0' . substr( $normalized, 4 );
		} elseif ( 0 === strpos( $normalized, '98' ) && 12 === strlen( $normalized ) ) {
			$normalized = '0' . substr( $normalized, 2 );
		}
		return preg_match( '/^09\d{9}$/', $normalized ) ? $normalized : '';
	}

	/**
	 * اعتبارسنجی کد ملی ایران با رقم کنترل. ورودی خالی مجاز است (اختیاری).
	 *
	 * @return string کد ملی نرمال‌شده؛ '' اگر خالی؛ null اگر نامعتبر.
	 */
	public static function national_id( string $raw ): ?string {
		$code = HSB_Jalali::normalize_digits( trim( $raw ) );
		if ( '' === $code ) {
			return ''; // اختیاری.
		}
		if ( ! preg_match( '/^\d{10}$/', $code ) ) {
			return null;
		}
		// همهٔ ارقام یکسان نامعتبر است.
		if ( 1 === preg_match( '/^(\d)\1{9}$/', $code ) ) {
			return null;
		}
		$sum = 0;
		for ( $i = 0; $i < 9; $i++ ) {
			$sum += ( (int) $code[ $i ] ) * ( 10 - $i );
		}
		$r     = $sum % 11;
		$check = (int) $code[9];
		$valid = ( $r < 2 ) ? ( $check === $r ) : ( $check === ( 11 - $r ) );
		return $valid ? $code : null;
	}

	/**
	 * اعتبارسنجی نام و نام خانوادگی (الزامی، ۲ تا ۱۰۰ نویسه).
	 */
	public static function person_name( string $raw ): bool {
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( trim( $raw ), 'UTF-8' ) : strlen( trim( $raw ) );
		return $len >= 2 && $len <= 100;
	}

	/**
	 * اعتبارسنجی و پاک‌سازی توضیح اختیاری (حداکثر ۵۰۰ نویسه، بدون HTML).
	 *
	 * @return string متن پاک‌سازی‌شده یا null اگر بیش از حد طولانی.
	 */
	public static function description( string $raw ): ?string {
		$text = trim( $raw );
		if ( function_exists( 'wp_strip_all_tags' ) ) {
			$text = wp_strip_all_tags( $text );
		} else {
			$text = strip_tags( $text );
		}
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( $text, 'UTF-8' ) : strlen( $text );
		if ( $len > self::MAX_DESC_LENGTH ) {
			return null;
		}
		return $text;
	}

	/**
	 * اعتبارسنجی نوع خدمت.
	 */
	public static function service_type( string $raw ): bool {
		return in_array( $raw, self::SERVICE_TYPES, true );
	}

	/**
	 * اعتبارسنجی قالب تاریخ میلادی Y-m-d + واقعی‌بودن.
	 */
	public static function date_ymd( string $raw ): bool {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ) {
			return false;
		}
		$parts = explode( '-', $raw );
		return checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] );
	}

	/**
	 * اعتبارسنجی قالب ساعت H:i.
	 */
	public static function time_hi( string $raw ): bool {
		return (bool) preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $raw );
	}

	/**
	 * اعتبارسنجی کلید تکرارناپذیری (UUID v4 یا رشتهٔ ۱۶ تا ۶۴ نویسه‌ای امن).
	 */
	public static function idempotency_key( string $raw ): string {
		$key = strtolower( trim( $raw ) );
		if ( preg_match( '/^[a-f0-9\-]{16,64}$/', $key ) ) {
			return $key;
		}
		return '';
	}
}
