<?php
/**
 * تقویم جلالی (شمسی) — پیاده‌سازی داخلی با الگوریتم JDN، بدون هیچ وابستگی خارجی.
 *
 * همهٔ ذخیره‌سازی‌ها در پایگاه‌داده میلادی (DATE) است؛ تبدیل فقط برای نمایش انجام می‌شود.
 * قرارداد روز هفتهٔ افزونه: ۰=شنبه، ۱=یکشنبه، … ۶=جمعه.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'HSB_TESTING' ) ) {
	exit;
}

/**
 * ابزار تبدیل و قالب‌بندی تاریخ شمسی.
 */
final class HSB_Jalali {

	/** نام روزهای هفته به ترتیب قرارداد داخلی (۰=شنبه). */
	private const WEEKDAYS = array( 'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه' );

	/** نام ماه‌های شمسی. */
	private const MONTHS = array(
		1  => 'فروردین',
		2  => 'اردیبهشت',
		3  => 'خرداد',
		4  => 'تیر',
		5  => 'مرداد',
		6  => 'شهریور',
		7  => 'مهر',
		8  => 'آبان',
		9  => 'آذر',
		10 => 'دی',
		11 => 'بهمن',
		12 => 'اسفند',
	);

	/**
	 * تبدیل میلادی به جلالی (الگوریتم استاندارد jdf).
	 *
	 * @return array{0:int,1:int,2:int} [سال, ماه, روز]
	 */
	public static function gregorian_to_jalali( int $gy, int $gm, int $gd ): array {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days  = 355666 + ( 365 * $gy ) + intdiv( $gy2 + 3, 4 ) - intdiv( $gy2 + 99, 100 ) + intdiv( $gy2 + 399, 400 ) + $gd + $g_d_m[ $gm - 1 ];
		$jy    = -1595 + ( 33 * intdiv( $days, 12053 ) );
		$days %= 12053;
		$jy   += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$jy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		$jm = ( $days < 186 ) ? 1 + intdiv( $days, 31 ) : 7 + intdiv( $days - 186, 30 );
		$jd = 1 + ( ( $days < 186 ) ? ( $days % 31 ) : ( ( $days - 186 ) % 30 ) );
		return array( $jy, $jm, $jd );
	}

	/**
	 * تبدیل جلالی به میلادی.
	 *
	 * @return array{0:int,1:int,2:int} [سال, ماه, روز]
	 */
	public static function jalali_to_gregorian( int $jy, int $jm, int $jd ): array {
		$jy   += 1595;
		$days  = -355668 + ( 365 * $jy ) + ( intdiv( $jy, 33 ) * 8 ) + intdiv( ( ( $jy % 33 ) + 3 ), 4 ) + $jd + ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );
		$gy    = 400 * intdiv( $days, 146097 );
		$days %= 146097;
		if ( $days > 36524 ) {
			$gy   += 100 * intdiv( --$days, 36524 );
			$days %= 36524;
			if ( $days >= 365 ) {
				$days++;
			}
		}
		$gy   += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$gy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		$gd = $days + 1;
		$leap = ( 0 === $gy % 4 && 0 !== $gy % 100 ) || ( 0 === $gy % 400 );
		$months = array( 0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
		$gm = 0;
		while ( $gm < 13 && $gd > $months[ $gm ] ) {
			$gd -= $months[ $gm ];
			$gm++;
		}
		return array( $gy, $gm, $gd );
	}

	/**
	 * ایندکس روز هفتهٔ افزونه (۰=شنبه … ۶=جمعه) برای یک تاریخ میلادی Y-m-d.
	 */
	public static function weekday_index( string $ymd ): int {
		$ts  = strtotime( $ymd . ' 12:00:00' );
		$php = (int) gmdate( 'w', $ts ); // ۰=یکشنبه … ۶=شنبه.
		$map = array( 6 => 0, 0 => 1, 1 => 2, 2 => 3, 3 => 4, 4 => 5, 5 => 6 );
		return $map[ $php ];
	}

	/**
	 * نام فارسی روز هفته بر اساس ایندکس داخلی.
	 */
	public static function weekday_name( int $index ): string {
		return self::WEEKDAYS[ $index ] ?? '';
	}

	/**
	 * نام ماه شمسی.
	 */
	public static function month_name( int $month ): string {
		return self::MONTHS[ $month ] ?? '';
	}

	/**
	 * تبدیل ارقام لاتین به فارسی.
	 *
	 * @param string|int $input ورودی.
	 */
	public static function fa_digits( $input ): string {
		$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		return str_replace( $en, $fa, (string) $input );
	}

	/**
	 * نرمال‌سازی ارقام فارسی/عربی به لاتین — برای ورودی‌های کاربر.
	 */
	public static function normalize_digits( string $input ): string {
		$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$ar = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		return str_replace( $ar, $en, str_replace( $fa, $en, $input ) );
	}

	/**
	 * برچسب کامل فارسی یک تاریخ میلادی: «شنبه ۱۴۰۳/۰۱/۰۱» یا قالب دلخواه.
	 *
	 * @param string $ymd    تاریخ میلادی Y-m-d.
	 * @param bool   $long   اگر true باشد قالب «شنبه ۱ فروردین ۱۴۰۳» برمی‌گردد.
	 */
	public static function label( string $ymd, bool $long = true ): string {
		$parts = explode( '-', $ymd );
		if ( 3 !== count( $parts ) ) {
			return $ymd;
		}
		list( $jy, $jm, $jd ) = self::gregorian_to_jalali( (int) $parts[0], (int) $parts[1], (int) $parts[2] );
		$weekday = self::weekday_name( self::weekday_index( $ymd ) );
		if ( $long ) {
			return sprintf(
				'%s %s %s %s',
				$weekday,
				self::fa_digits( $jd ),
				self::month_name( $jm ),
				self::fa_digits( $jy )
			);
		}
		return sprintf(
			'%s %s/%s/%s',
			$weekday,
			self::fa_digits( str_pad( (string) $jy, 4, '0', STR_PAD_LEFT ) ),
			self::fa_digits( str_pad( (string) $jm, 2, '0', STR_PAD_LEFT ) ),
			self::fa_digits( str_pad( (string) $jd, 2, '0', STR_PAD_LEFT ) )
		);
	}

	/**
	 * تاریخ امروز به میلادی بر اساس منطقهٔ زمانی تنظیم‌شده در وردپرس.
	 * در محیط تست بدون وردپرس، از ساعت سرور استفاده می‌شود.
	 */
	public static function today_local(): string {
		if ( function_exists( 'current_datetime' ) ) {
			$dt = current_datetime(); // WP_DateTime با منطقهٔ زمانی وردپرس.
			return $dt->format( 'Y-m-d' );
		}
		return gmdate( 'Y-m-d' );
	}

	/**
	 * زمان فعلی به‌صورت H:i در منطقهٔ زمانی وردپرس — برای غیرفعال‌کردن ساعت‌های گذشتهٔ امروز.
	 */
	public static function now_local_hm(): string {
		if ( function_exists( 'current_datetime' ) ) {
			return current_datetime()->format( 'H:i' );
		}
		return gmdate( 'H:i' );
	}

	/**
	 * tmestamp فعلی بر اساس ساعت وردپرس (برای محاسبهٔ مهلت لغو).
	 */
	public static function now_ts(): int {
		if ( function_exists( 'current_datetime' ) ) {
			return current_datetime()->getTimestamp();
		}
		return time();
	}
}
