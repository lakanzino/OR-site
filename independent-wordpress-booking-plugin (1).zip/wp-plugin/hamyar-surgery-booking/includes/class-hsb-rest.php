<?php
/**
 * REST API افزونه — تمام عملیات حساس با nonce وردپرس (X-WP-Nonce) و کنترل دسترسی سمت سرور.
 *
 * مسیرهای عمومی (روزها/بازه‌ها) فقط ظرفیت و زمان را برمی‌گردانند؛ هیچ هویت بیمری افشا نمی‌شود.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ثبت و مدیریت مسیرهای REST.
 */
final class HSB_REST {

	public const NS = 'hsb/v1';

	/**
	 * ثبت مسیرها.
	 */
	public static function register_routes(): void {
		// عمومی: تقویم ۱۴ روزهٔ یک پزشک.
		register_rest_route(
			self::NS,
			'/doctors/(?P<id>\d+)/days',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_days' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array( 'sanitize_callback' => 'absint' ),
				),
			)
		);

		// عمومی: بازه‌های یک روز.
		register_rest_route(
			self::NS,
			'/doctors/(?P<id>\d+)/slots',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_slots' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id'   => array( 'sanitize_callback' => 'absint' ),
					'date' => array( 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);

		// بیمار: ثبت نوبت.
		register_rest_route(
			self::NS,
			'/appointments',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_appointment' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
			)
		);

		// بیمار: نوبت‌های خودش.
		register_rest_route(
			self::NS,
			'/my-appointments',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'my_appointments' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
			)
		);

		// بیمار: لغو نوبت خودش.
		register_rest_route(
			self::NS,
			'/appointments/(?P<id>\d+)/cancel',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cancel_my_appointment' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
				'args'                => array(
					'id' => array( 'sanitize_callback' => 'absint' ),
				),
			)
		);

		// مطب: فهرست نوبت‌ها با فیلتر.
		register_rest_route(
			self::NS,
			'/clinic/appointments',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'clinic_appointments' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
			)
		);

		// مطب: تغییر وضعیت یا لغو.
		register_rest_route(
			self::NS,
			'/clinic/appointments/(?P<id>\d+)/status',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'clinic_set_status' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
				'args'                => array(
					'id' => array( 'sanitize_callback' => 'absint' ),
				),
			)
		);

		// برنامهٔ هفتگی: خواندن و ذخیره.
		register_rest_route(
			self::NS,
			'/schedule',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_schedule' ),
					'permission_callback' => array( __CLASS__, 'require_login' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'save_schedule' ),
					'permission_callback' => array( __CLASS__, 'require_login' ),
				),
			)
		);

		// استثناهای تاریخ (تعطیلی/ساعت خاص).
		register_rest_route(
			self::NS,
			'/overrides',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'save_override' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
			)
		);
		register_rest_route(
			self::NS,
			'/overrides/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( __CLASS__, 'delete_override' ),
				'permission_callback' => array( __CLASS__, 'require_login' ),
				'args'                => array(
					'id' => array( 'sanitize_callback' => 'absint' ),
				),
			)
		);
	}

	/**
	 * نیازمندی ورود — پیام روشن بدون افشای اطلاعات.
	 *
	 * @return bool|WP_Error
	 */
	public static function require_login() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'hsb_auth_required',
				'برای انجام این عملیات ابتدا وارد حساب کاربری خود شوید.',
				array( 'status' => 401 )
			);
		}
		return true;
	}

	/**
	 * محدودیت نرخ ساده بر پایهٔ transient — بر اساس کاربر یا IP.
	 */
	private static function rate_limited( string $action, int $max, int $window_seconds ): bool {
		$user_id = get_current_user_id();
		$ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$key     = 'hsb_rl_' . $action . '_' . md5( $user_id . '|' . $ip );
		$count   = (int) get_transient( $key );
		if ( $count >= $max ) {
			return true;
		}
		set_transient( $key, $count + 1, $window_seconds );
		return false;
	}

	/**
	 * ساخت پاسخ خطای یکدست.
	 */
	private static function fail( string $code, string $message, int $status = 400 ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'ok'      => false,
				'error'   => $code,
				'message' => $message,
			),
			$status
		);
	}

	/**
	 * GET /doctors/{id}/days — فقط ظرفیت و وضعیت روزها.
	 */
	public static function get_days( WP_REST_Request $request ): WP_REST_Response {
		$doctor_id = (int) $request->get_param( 'id' );
		$doctor    = HSB_Doctor::get_public( $doctor_id );
		if ( ! $doctor ) {
			return self::fail( 'doctor_unavailable', 'رزرو داخلی برای این پزشک فعال نیست.', 404 );
		}
		$response = new WP_REST_Response(
			array(
				'ok'     => true,
				'doctor' => $doctor,
				'days'   => HSB_Availability::days_payload( $doctor_id ),
			)
		);
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
		return $response;
	}

	/**
	 * GET /doctors/{id}/slots?date= — فقط زمان و ظرفیت.
	 */
	public static function get_slots( WP_REST_Request $request ): WP_REST_Response {
		$doctor_id = (int) $request->get_param( 'id' );
		$date      = (string) $request->get_param( 'date' );
		$doctor    = HSB_Doctor::get_public( $doctor_id );
		if ( ! $doctor ) {
			return self::fail( 'doctor_unavailable', 'رزرو داخلی برای این پزشک فعال نیست.', 404 );
		}
		$slots = HSB_Availability::slots_payload( $doctor_id, $date );
		if ( null === $slots ) {
			return self::fail( 'day_unavailable', 'این روز برای رزرو فعال نیست.', 400 );
		}
		$response = new WP_REST_Response(
			array(
				'ok'       => true,
				'date'     => $date,
				'date_fa'  => HSB_Jalali::label( $date, true ),
				'slots'    => $slots,
			)
		);
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
		return $response;
	}

	/**
	 * POST /appointments — ثبت نوبت با محدودیت نرخ و کلید تکرارناپذیری.
	 */
	public static function create_appointment( WP_REST_Request $request ) {
		// محدودیت نرخ: پیش‌فرض ۱۰ ثبت در ساعت برای هر کاربر/IP.
		$max = (int) HSB_Settings::get( 'rate_limit_booking_per_hour', 10 );
		if ( self::rate_limited( 'book', max( 1, $max ), HOUR_IN_SECONDS_HSB ) ) {
			return self::fail( 'rate_limited', 'تعداد درخواست‌ها بیش از حد مجاز است؛ لطفاً کمی بعد دوباره تلاش کنید.', 429 );
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$idempotency_key = (string) $request->get_header( 'x-hsb-idempotency-key' );
		if ( '' === $idempotency_key && isset( $params['idempotency_key'] ) ) {
			$idempotency_key = (string) $params['idempotency_key'];
		}

		$result = HSB_Booking::book( $params, get_current_user_id(), $idempotency_key );
		$status = 200;
		if ( ! $result['ok'] ) {
			$status = ! empty( $result['uncertain'] ) ? 200 : 400;
			if ( 'auth_required' === ( $result['error'] ?? '' ) ) {
				$status = 401;
			}
		}
		return new WP_REST_Response( $result, $status );
	}

	/**
	 * GET /my-appointments — فقط نوبت‌های خود کاربر.
	 */
	public static function my_appointments(): WP_REST_Response {
		$rows = HSB_Booking::for_patient( get_current_user_id() );
		$out  = array_map( array( 'HSB_Booking', 'present_for_patient' ), $rows );
		// آیا هر نوبت هنوز در مهلت لغو است؟ (برای نمایش دکمه).
		$cutoff = (int) HSB_Settings::get( 'cancel_cutoff_hours', 24 );
		$allow_confirmed_cancel = (bool) HSB_Settings::get( 'patient_can_cancel_confirmed', 0 );
		foreach ( $out as $i => $a ) {
			$row = $rows[ $i ];
			$start_ts = strtotime( $row->appointment_date . ' ' . $row->start_time );
			$in_time  = ( $start_ts - HSB_Jalali::now_ts() ) >= $cutoff * HOUR_IN_SECONDS_HSB;
			$status_ok = in_array( $a['status'], array( 'requested' ), true )
				|| ( $allow_confirmed_cancel && 'confirmed' === $a['status'] );
			$out[ $i ]['cancellable'] = $in_time && $status_ok;
			$out[ $i ]['cutoff_hours_fa'] = HSB_Jalali::fa_digits( $cutoff );
		}
		return new WP_REST_Response(
			array(
				'ok'           => true,
				'appointments' => $out,
			)
		);
	}

	/**
	 * POST /appointments/{id}/cancel — لغو توسط بیمار (مالکیت در موتور رزرو بررسی می‌شود).
	 */
	public static function cancel_my_appointment( WP_REST_Request $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = HSB_Booking::cancel( $id, get_current_user_id(), 'patient' );
		return new WP_REST_Response( $result, $result['ok'] ? 200 : 400 );
	}

	/**
	 * GET /clinic/appointments — فقط پزشکان مجازِ کاربر؛ فیلتر پزشک/تاریخ/وضعیت.
	 */
	public static function clinic_appointments( WP_REST_Request $request ) {
		global $wpdb;
		$user_id = get_current_user_id();

		$manageable = HSB_Access::manageable_doctor_ids( $user_id );
		if ( empty( $manageable ) ) {
			return self::fail( 'forbidden', 'شما به هیچ پزشکی متصل نیستید. با مدیر سایت تماس بگیرید.', 403 );
		}

		$doctor_id = absint( $request->get_param( 'doctor_id' ) );
		if ( $doctor_id && ! in_array( $doctor_id, $manageable, true ) ) {
			return self::fail( 'forbidden', 'دسترسی به نوبت‌های این پزشک را ندارید.', 403 );
		}

		$date   = (string) $request->get_param( 'date' );
		$status = (string) $request->get_param( 'status' );

		$table = HSB_Activator::table( 'appointments' );
		$where = array();
		$args  = array();

		$ids_placeholders = implode( ',', array_fill( 0, count( $manageable ), '%d' ) );
		$where[]          = "doctor_id IN ($ids_placeholders)"; // مرز داده: فقط پزشکان مجاز.
		$args             = array_merge( $args, $manageable );

		if ( $doctor_id ) {
			$where[] = 'doctor_id = %d';
			$args[]  = $doctor_id;
		}
		if ( $date && HSB_Validator::date_ymd( $date ) ) {
			$where[] = 'appointment_date = %s';
			$args[]  = $date;
		}
		$valid_statuses = array( 'requested', 'confirmed', 'cancelled_patient', 'cancelled_clinic', 'completed', 'no_show' );
		if ( $status && in_array( $status, $valid_statuses, true ) ) {
			$where[] = 'status = %s';
			$args[]  = $status;
		}

		$sql = "SELECT * FROM $table WHERE " . implode( ' AND ', $where ) . ' ORDER BY appointment_date DESC, start_time ASC LIMIT 300';
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = HSB_Booking::present_for_clinic( $row );
		}
		return new WP_REST_Response(
			array(
				'ok'           => true,
				'manageable'   => $manageable,
				'appointments' => $out,
			)
		);
	}

	/**
	 * POST /clinic/appointments/{id}/status — confirmed|completed|no_show|cancelled_clinic.
	 */
	public static function clinic_set_status( WP_REST_Request $request ) {
		$id      = (int) $request->get_param( 'id' );
		$params  = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = array();
		}
		$status  = (string) ( $params['status'] ?? '' );

		if ( 'cancelled_clinic' === $status ) {
			$result = HSB_Booking::cancel( $id, get_current_user_id(), 'clinic' );
		} else {
			$result = HSB_Booking::set_status( $id, $status, get_current_user_id() );
		}
		return new WP_REST_Response( $result, $result['ok'] ? 200 : 400 );
	}

	/**
	 * GET /schedule?doctor_id= — خواندن برنامه و استثناها برای ویرایش.
	 */
	public static function get_schedule( WP_REST_Request $request ) {
		$doctor_id = absint( $request->get_param( 'doctor_id' ) );
		$user_id   = get_current_user_id();
		if ( ! $doctor_id || ! HSB_Access::can_manage_doctor( $user_id, $doctor_id ) ) {
			return self::fail( 'forbidden', 'به برنامهٔ این پزشک دسترسی ندارید.', 403 );
		}

		$week = HSB_Availability::get_week_schedule( $doctor_id );
		$days = array();
		for ( $i = 0; $i < 7; $i++ ) {
			$row    = $week[ $i ] ?? null;
			$days[] = array(
				'weekday'     => $i,
				'name'        => HSB_Jalali::weekday_name( $i ),
				'active'      => $row ? (bool) $row->is_active : false,
				'start'       => $row ? substr( (string) $row->start_time, 0, 5 ) : '09:00',
				'end'         => $row ? substr( (string) $row->end_time, 0, 5 ) : '13:00',
				'slot_length' => $row ? (int) $row->slot_length : (int) HSB_Settings::get( 'default_slot_length', 30 ),
				'capacity'    => $row ? (int) $row->capacity : (int) HSB_Settings::get( 'default_capacity', 1 ),
			);
		}

		global $wpdb;
		$table_o = HSB_Activator::table( 'overrides' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$override_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_o WHERE doctor_id = %d AND override_date >= %s ORDER BY override_date ASC LIMIT 100",
				$doctor_id,
				HSB_Jalali::today_local()
			)
		);
		$overrides = array();
		foreach ( (array) $override_rows as $row ) {
			$overrides[] = array(
				'id'        => (int) $row->id,
				'date'      => (string) $row->override_date,
				'date_fa'   => HSB_Jalali::label( (string) $row->override_date, true ),
				'is_closed' => (bool) $row->is_closed,
				'start'     => $row->start_time ? substr( (string) $row->start_time, 0, 5 ) : '',
				'end'       => $row->end_time ? substr( (string) $row->end_time, 0, 5 ) : '',
				'capacity'  => null === $row->capacity ? null : (int) $row->capacity,
				'reason'    => (string) $row->reason,
			);
		}

		return new WP_REST_Response(
			array(
				'ok'              => true,
				'doctor_id'       => $doctor_id,
				'can_edit'        => HSB_Access::can_edit_schedule( $user_id, $doctor_id ),
				'days'            => $days,
				'overrides'       => $overrides,
				'booking_enabled' => HSB_Doctor::booking_is_enabled_for( $doctor_id ),
			)
		);
	}

	/**
	 * اعتبارسنجی یک روز از برنامهٔ هفتگی.
	 *
	 * @param array $day ورودی.
	 * @return array|WP_Error
	 */
	private static function sanitize_schedule_day( array $day ) {
		$weekday     = isset( $day['weekday'] ) ? (int) $day['weekday'] : -1;
		$active      = ! empty( $day['active'] );
		$start       = (string) ( $day['start'] ?? '' );
		$end         = (string) ( $day['end'] ?? '' );
		$slot_length = (int) ( $day['slot_length'] ?? 0 );
		$capacity    = (int) ( $day['capacity'] ?? 0 );

		if ( $weekday < 0 || $weekday > 6 ) {
			return new WP_Error( 'hsb_bad_day', 'روز هفته نامعتبر است.' );
		}
		if ( ! $active ) {
			return array(
				'weekday'     => $weekday,
				'active'      => false,
				'start'       => HSB_Validator::time_hi( $start ) ? $start : '09:00',
				'end'         => HSB_Validator::time_hi( $end ) ? $end : '13:00',
				'slot_length' => in_array( $slot_length, array( 10, 15, 20, 30, 45, 60 ), true ) ? $slot_length : 30,
				'capacity'    => max( 1, min( 50, $capacity ?: 1 ) ),
			);
		}
		if ( ! HSB_Validator::time_hi( $start ) || ! HSB_Validator::time_hi( $end ) || $start >= $end ) {
			return new WP_Error( 'hsb_bad_time', sprintf( 'ساعت شروع/پایان روز «%s» معتبر نیست.', HSB_Jalali::weekday_name( $weekday ) ) );
		}
		if ( ! in_array( $slot_length, array( 10, 15, 20, 30, 45, 60 ), true ) ) {
			return new WP_Error( 'hsb_bad_slot', 'طول بازه باید یکی از ۱۰، ۱۵، ۲۰، ۳۰، ۴۵ یا ۶۰ دقیقه باشد.' );
		}
		if ( $capacity < 1 || $capacity > 50 ) {
			return new WP_Error( 'hsb_bad_capacity', 'ظرفیت هر بازه باید بین ۱ تا ۵۰ باشد.' );
		}
		if ( strtotime( "1970-01-01 $start:00" ) + $slot_length * 60 > strtotime( "1970-01-01 $end:00" ) ) {
			return new WP_Error( 'hsb_no_slot', sprintf( 'بازهٔ روز «%s» کوتاه‌تر از طول بازه است.', HSB_Jalali::weekday_name( $weekday ) ) );
		}
		return array(
			'weekday'     => $weekday,
			'active'      => true,
			'start'       => $start,
			'end'         => $end,
			'slot_length' => $slot_length,
			'capacity'    => $capacity,
		);
	}

	/**
	 * POST /schedule — ذخیرهٔ اتمی برنامهٔ هفتگی + گزارش صریح تعارض با نوبت‌های موجود.
	 * تعارض‌ها هشدار داده می‌شوند و هیچ نوبتی بی‌صدا حذف نمی‌شود.
	 */
	public static function save_schedule( WP_REST_Request $request ) {
		global $wpdb;
		$params    = $request->get_json_params();
		$doctor_id = absint( $params['doctor_id'] ?? 0 );
		$user_id   = get_current_user_id();

		if ( ! $doctor_id || ! HSB_Access::can_edit_schedule( $user_id, $doctor_id ) ) {
			return self::fail( 'forbidden', 'شما مجاز به ویرایش برنامهٔ این پزشک نیستید. این محدودیت از بخش تنظیمات قابل تغییر است.', 403 );
		}

		$days_in = $params['days'] ?? null;
		if ( ! is_array( $days_in ) || 7 !== count( $days_in ) ) {
			return self::fail( 'bad_request', 'دادهٔ برنامهٔ هفتگی ناقص است (هفت روز لازم است).' );
		}

		$days = array();
		foreach ( $days_in as $day ) {
			$clean = self::sanitize_schedule_day( (array) $day );
			if ( is_wp_error( $clean ) ) {
				return self::fail( $clean->get_error_code(), $clean->get_error_message() );
			}
			$days[ $clean['weekday'] ] = $clean;
		}
		if ( 7 !== count( $days ) ) {
			return self::fail( 'bad_request', 'روزهای هفته تکراری یا ناقص ارسال شده است.' );
		}

		$table_s = HSB_Activator::table( 'schedules' );
		$now     = current_time( 'mysql' );

		// ذخیرهٔ اتمی: همه یا هیچ.
		$wpdb->query( 'START TRANSACTION' );
		foreach ( $days as $day ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$sql = $wpdb->prepare(
				"INSERT INTO $table_s (doctor_id, weekday, start_time, end_time, slot_length, capacity, is_active, created_at, updated_at)
				 VALUES (%d, %d, %s, %s, %d, %d, %d, %s, %s)
				 ON DUPLICATE KEY UPDATE
					start_time = VALUES(start_time), end_time = VALUES(end_time),
					slot_length = VALUES(slot_length), capacity = VALUES(capacity),
					is_active = VALUES(is_active), updated_at = VALUES(updated_at)",
				$doctor_id,
				$day['weekday'],
				$day['start'] . ':00',
				$day['end'] . ':00',
				$day['slot_length'],
				$day['capacity'],
				$day['active'] ? 1 : 0,
				$now,
				$now
			);
			$result = $wpdb->query( $sql );
			if ( false === $result ) {
				$wpdb->query( 'ROLLBACK' );
				return self::fail( 'db_error', 'ذخیرهٔ برنامه با خطای پایگاه‌داده شکست خورد؛ هیچ روزی ذخیره نشد. لطفاً دوباره تلاش کنید.', 500 );
			}
		}
		if ( false === $wpdb->query( 'COMMIT' ) ) {
			return self::fail( 'commit_unknown', 'نتیجهٔ ذخیرهٔ برنامه نامشخص شد. پیش از تلاش دوباره، برنامهٔ فعلی را بررسی کنید.', 500 );
		}

		// تشخیص تعارض: نوبت‌های موجودِ آینده که با برنامهٔ جدید جا نمی‌شوند.
		$conflicts = self::find_schedule_conflicts( $doctor_id, $days );

		return new WP_REST_Response(
			array(
				'ok'        => true,
				'message'   => 'برنامهٔ هفتگی ذخیره شد.',
				'conflicts' => $conflicts, // هشدار روشن؛ واکنش بعدی با پزشک/مدیر است.
			)
		);
	}

	/**
	 * یافتن نوبت‌های آینده که با برنامهٔ جدید تعارض دارند (بدون حذف).
	 *
	 * @param array $days برنامهٔ تازهٔ پاک‌سازی‌شده.
	 */
	private static function find_schedule_conflicts( int $doctor_id, array $days ): array {
		global $wpdb;
		$table_a = HSB_Activator::table( 'appointments' );
		$today   = HSB_Jalali::today_local();
		$to      = gmdate( 'Y-m-d', strtotime( $today . ' +' . ( HSB_BOOKING_HORIZON_DAYS - 1 ) . ' days' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT appointment_date, DATE_FORMAT(start_time, '%%H:%%i') AS hm, COUNT(*) AS c
				 FROM $table_a
				 WHERE doctor_id = %d AND appointment_date BETWEEN %s AND %s AND status IN ('requested','confirmed')
				 GROUP BY appointment_date, start_time",
				$doctor_id,
				$today,
				$to
			)
		);

		$overrides = HSB_Availability::get_overrides( $doctor_id, $today, $to );
		$conflicts = array();
		foreach ( (array) $rows as $row ) {
			$ymd    = (string) $row->appointment_date;
			$widx   = HSB_Availability::weekday_of( $ymd );
			$day    = $days[ $widx ] ?? null;
			if ( ! $day ) {
				continue;
			}
			$sched  = (object) array(
				'is_active'   => $day['active'] ? 1 : 0,
				'start_time'  => $day['start'] . ':00',
				'end_time'    => $day['end'] . ':00',
				'slot_length' => $day['slot_length'],
				'capacity'    => $day['capacity'],
			);
			$window = HSB_Availability_Calc::resolve_day( $sched, $overrides[ $ymd ] ?? null );
			if ( ! $window['active'] || $window['holiday'] ) {
				$conflicts[] = array(
					'date'    => $ymd,
					'date_fa' => HSB_Jalali::label( $ymd, true ),
					'time_fa' => HSB_Jalali::fa_digits( $row->hm ),
					'count_fa' => HSB_Jalali::fa_digits( (int) $row->c ),
					'problem' => 'روز در برنامهٔ جدید غیرفعال/تعطیل است اما نوبت فعال دارد.',
				);
				continue;
			}
			$slots = HSB_Availability_Calc::build_slots( $window['start'], $window['end'], $window['slot_length'] );
			if ( ! in_array( (string) $row->hm, $slots, true ) ) {
				$conflicts[] = array(
					'date'    => $ymd,
					'date_fa' => HSB_Jalali::label( $ymd, true ),
					'time_fa' => HSB_Jalali::fa_digits( $row->hm ),
					'count_fa' => HSB_Jalali::fa_digits( (int) $row->c ),
					'problem' => 'ساعت این نوبت در برنامهٔ جدید وجود ندارد.',
				);
			} elseif ( (int) $row->c > $window['capacity'] ) {
				$conflicts[] = array(
					'date'    => $ymd,
					'date_fa' => HSB_Jalali::label( $ymd, true ),
					'time_fa' => HSB_Jalali::fa_digits( $row->hm ),
					'count_fa' => HSB_Jalali::fa_digits( (int) $row->c ),
					'problem' => sprintf( 'تعداد نوبت‌های این بازه (%d) از ظرفیت جدید (%d) بیشتر است.', (int) $row->c, $window['capacity'] ),
				);
			}
		}
		return $conflicts;
	}

	/**
	 * POST /overrides — افزودن/به‌روزرسانی استثنای یک تاریخ (تعطیلی یا ساعت/ظرفیت خاص).
	 * اگر روز نوبت فعال داشته باشد، تعارض گزارش و هیچ نوبتی حذف نمی‌شود.
	 */
	public static function save_override( WP_REST_Request $request ) {
		global $wpdb;
		$params    = $request->get_json_params();
		$doctor_id = absint( $params['doctor_id'] ?? 0 );
		$user_id   = get_current_user_id();

		if ( ! $doctor_id || ! HSB_Access::can_edit_schedule( $user_id, $doctor_id ) ) {
			return self::fail( 'forbidden', 'شما مجاز به ویرایش برنامهٔ این پزشک نیستید.', 403 );
		}

		$date = (string) ( $params['date'] ?? '' );
		if ( ! HSB_Validator::date_ymd( $date ) || $date < HSB_Jalali::today_local() ) {
			return self::fail( 'bad_date', 'تاریخ استثنا باید معتبر و از امروز به بعد باشد.' );
		}
		$is_closed = ! empty( $params['is_closed'] );
		$start     = (string) ( $params['start'] ?? '' );
		$end       = (string) ( $params['end'] ?? '' );
		$reason    = mb_substr( sanitize_text_field( (string) ( $params['reason'] ?? '' ) ), 0, 190 );

		$capacity = null;
		if ( isset( $params['capacity'] ) && '' !== $params['capacity'] && null !== $params['capacity'] ) {
			$capacity = max( 1, min( 50, (int) $params['capacity'] ) );
		}
		if ( ! $is_closed && ( '' !== $start || '' !== $end ) ) {
			if ( ! HSB_Validator::time_hi( $start ) || ! HSB_Validator::time_hi( $end ) || $start >= $end ) {
				return self::fail( 'bad_time', 'ساعت شروع/پایان استثنا معتبر نیست.' );
			}
		}

		$table_o = HSB_Activator::table( 'overrides' );
		$now     = current_time( 'mysql' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = $wpdb->prepare(
			"INSERT INTO $table_o (doctor_id, override_date, is_closed, start_time, end_time, capacity, reason, created_at, updated_at)
			 VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s)
			 ON DUPLICATE KEY UPDATE
				is_closed = VALUES(is_closed), start_time = VALUES(start_time), end_time = VALUES(end_time),
				capacity = VALUES(capacity), reason = VALUES(reason), updated_at = VALUES(updated_at)",
			$doctor_id,
			$date,
			$is_closed ? 1 : 0,
			( '' !== $start && ! $is_closed ) ? $start . ':00' : null,
			( '' !== $end && ! $is_closed ) ? $end . ':00' : null,
			$capacity,
			$reason,
			$now,
			$now
		);
		$result = $wpdb->query( $sql );
		if ( false === $result ) {
			return self::fail( 'db_error', 'ذخیرهٔ استثنا با خطا مواجه شد؛ چیزی ذخیره نشد.', 500 );
		}

		// گزارش تعارض با نوبت‌های موجود همان روز — بدون حذف خودکار.
		$conflicts = array();
		$table_a   = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_a WHERE doctor_id = %d AND appointment_date = %s AND status IN ('requested','confirmed')",
				$doctor_id,
				$date
			)
		);
		if ( $is_closed && $count > 0 ) {
			$conflicts[] = array(
				'date'    => $date,
				'date_fa' => HSB_Jalali::label( $date, true ),
				'problem' => sprintf(
					'این روز تعطیل شد، اما %d نوبت فعال در آن وجود دارد. این نوبت‌ها حذف نشدند؛ لغو یا جابه‌جایی آن‌ها با همراهی بیمار انجام شود.',
					$count
				),
				'count_fa' => HSB_Jalali::fa_digits( $count ),
			);
		}

		return new WP_REST_Response(
			array(
				'ok'        => true,
				'message'   => 'استثنای تاریخ ذخیره شد.',
				'conflicts' => $conflicts,
			)
		);
	}

	/**
	 * DELETE /overrides/{id} — حذف یک استثنا (با بررسی مجوز روی پزشک مالک ردیف).
	 */
	public static function delete_override( WP_REST_Request $request ) {
		global $wpdb;
		$id = (int) $request->get_param( 'id' );

		$table_o = HSB_Activator::table( 'overrides' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_o WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::fail( 'not_found', 'استثنای مورد نظر یافت نشد.', 404 );
		}
		if ( ! HSB_Access::can_edit_schedule( get_current_user_id(), (int) $row->doctor_id ) ) {
			return self::fail( 'forbidden', 'مجاز به حذف این استثنا نیستید.', 403 );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM $table_o WHERE id = %d", $id ) );
		if ( false === $deleted ) {
			return self::fail( 'db_error', 'حذف استثنا با خطا مواجه شد؛ چیزی تغییر نکرد.', 500 );
		}
		return new WP_REST_Response(
			array(
				'ok'      => true,
				'message' => 'استثنا حذف شد.',
			)
		);
	}
}
