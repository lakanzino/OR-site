<?php
/**
 * تنظیمات افزونه — یک آپشن واحد با مقادیر پیش‌فرض امن و پاک‌سازی ورودی.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'HSB_TESTING' ) ) {
	exit;
}

/**
 * مدیریت تنظیمات.
 */
final class HSB_Settings {

	public const OPTION_KEY = 'hsb_settings';

	/**
	 * مقادیر پیش‌فرض.
	 */
	public static function defaults(): array {
		return array(
			// لایهٔ اتصال پزشکان.
			'doctor_provider'           => 'none',   // none|cpt|users — تا پیکربندی صریح، غیرفعال.
			'doctor_post_type'          => 'doctor', // فقط برای provider=cpt.
			'doctor_relation'           => 'post_author', // post_author|meta_key.
			'doctor_relation_meta_key'  => '',       // مثلاً 'user_id' — مقدار را مدیر باید بداند؛ حدس نمی‌زنیم.
			'doctor_roles'              => array(),  // فقط برای provider=users: نقش‌های موجود که پزشک هستند.

			// دسترسی منشی/کارکنان.
			'staff_can_edit_schedule'   => 0,        // مرز روشن: پیش‌فرض خیر.
			'doctors_can_edit_schedule' => 1,        // پزشک روی برنامهٔ خودش.

			// سیاست لغو بیمار.
			'cancel_cutoff_hours'       => 24,       // تا ۲۴ ساعت قبل از نوبت.
			'patient_can_cancel_confirmed' => 0,     // پیش‌فرض فقط نوبت‌های «در انتظار تأیید» قابل لغو است.

			// مقادیر پیش‌فرض بازه.
			'default_slot_length'       => 30,
			'default_capacity'          => 1,

			// ظرفیت‌سنجی نرخ.
			'rate_limit_booking_per_hour' => 10,

			// اعلان‌ها: پیش‌فرض خاموش؛ فقط پس از پیکربندی و تست واقعی روشن شود.
			'email_notifications'       => 0,
			'clinic_email'              => '',
			'email_last_error'          => '',

			// حذف داده‌ها هنگام حذف افزونه: پیش‌فرض خیر (طبق نیازمندی).
			'delete_data_on_uninstall'  => 0,
		);
	}

	/**
	 * درج مقادیر پیش‌فرض بدون بازنویسی تنظیمات موجود.
	 */
	public static function ensure_defaults(): void {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults(), '', false );
		}
	}

	/**
	 * خواندن همهٔ تنظیمات (ادغام با پیش‌فرض).
	 */
	public static function all(): array {
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * خواندن یک کلید.
	 *
	 * @param mixed $fallback جایگزین در صورت نبود کلید.
	 * @return mixed
	 */
	public static function get( string $key, $fallback = null ) {
		$all = self::all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return $fallback;
	}

	/**
	 * پاک‌سازی و ذخیرهٔ تنظیمات از ورودی فرم.
	 *
	 * @param array $input ورودی خام.
	 */
	public static function sanitize( array $input ): array {
		$out = self::defaults();

		$out['doctor_provider'] = in_array( $input['doctor_provider'] ?? 'none', array( 'none', 'cpt', 'users' ), true )
			? $input['doctor_provider']
			: 'none';
		$out['doctor_post_type'] = sanitize_key( $input['doctor_post_type'] ?? 'doctor' );
		$out['doctor_relation']  = in_array( $input['doctor_relation'] ?? 'post_author', array( 'post_author', 'meta_key' ), true )
			? $input['doctor_relation']
			: 'post_author';
		$out['doctor_relation_meta_key'] = sanitize_key( $input['doctor_relation_meta_key'] ?? '' );

		$roles = $input['doctor_roles'] ?? array();
		$out['doctor_roles'] = array_values( array_filter( array_map( 'sanitize_key', (array) $roles ) ) );

		$out['staff_can_edit_schedule']      = empty( $input['staff_can_edit_schedule'] ) ? 0 : 1;
		$out['doctors_can_edit_schedule']    = empty( $input['doctors_can_edit_schedule'] ) ? 0 : 1;
		$out['patient_can_cancel_confirmed'] = empty( $input['patient_can_cancel_confirmed'] ) ? 0 : 1;

		$out['cancel_cutoff_hours'] = max( 0, min( 720, absint( $input['cancel_cutoff_hours'] ?? 24 ) ) );

		$slot = absint( $input['default_slot_length'] ?? 30 );
		$out['default_slot_length'] = in_array( $slot, array( 10, 15, 20, 30, 45, 60 ), true ) ? $slot : 30;
		$out['default_capacity']    = max( 1, min( 50, absint( $input['default_capacity'] ?? 1 ) ) );

		$out['rate_limit_booking_per_hour'] = max( 1, min( 100, absint( $input['rate_limit_booking_per_hour'] ?? 10 ) ) );

		$out['email_notifications'] = empty( $input['email_notifications'] ) ? 0 : 1;
		$email = sanitize_email( $input['clinic_email'] ?? '' );
		$out['clinic_email'] = is_email( $email ) ? $email : '';
		// اگر ایمیل مطب نامعتبر باشد، اعلان برای جلوگیری از سوءتفاهم خاموش می‌شود.
		if ( 1 === $out['email_notifications'] && '' === $out['clinic_email'] ) {
			$out['email_notifications'] = 0;
		}

		$out['delete_data_on_uninstall'] = empty( $input['delete_data_on_uninstall'] ) ? 0 : 1;

		// خطای آخرین ایمیل هنگام ذخیرهٔ تنظیمات پاک نمی‌شود.
		$out['email_last_error'] = (string) self::get( 'email_last_error', '' );

		return $out;
	}

	/**
	 * به‌روزرسانی تنظیمات.
	 */
	public static function update( array $settings ): void {
		update_option( self::OPTION_KEY, $settings, false );
	}

	/**
	 * نگاشت کاربر↔پروفایل پزشک (ساختار: [ user_id => [ ['doctor'=>id,'type'=>'doctor|staff'], ... ] ]).
	 */
	public static function user_doctor_map(): array {
		$map = get_option( 'hsb_user_doctor_map', array() );
		return is_array( $map ) ? $map : array();
	}

	/**
	 * ذخیرهٔ نگاشت کاربر↔پزشک.
	 */
	public static function save_user_doctor_map( array $map ): void {
		$clean = array();
		foreach ( $map as $user_id => $entries ) {
			$uid = absint( $user_id );
			if ( ! $uid ) {
				continue;
			}
			foreach ( (array) $entries as $entry ) {
				$did  = absint( $entry['doctor'] ?? 0 );
				$type = ( $entry['type'] ?? '' ) === 'staff' ? 'staff' : 'doctor';
				if ( $did ) {
					$clean[ $uid ][] = array(
						'doctor' => $did,
						'type'   => $type,
					);
				}
			}
		}
		update_option( 'hsb_user_doctor_map', $clean, false );
	}

	/**
	 * فعال/غیرفعال‌بودن رزرو داخلی برای یک پزشک مشخص.
	 * پیش‌فرض «فعال» است اما فقط زمانی معنا پیدا می‌کند که provider پیکربندی شده باشد.
	 */
	public static function doctor_booking_enabled(): array {
		$flags = get_option( 'hsb_doctor_booking_flags', array() );
		return is_array( $flags ) ? $flags : array();
	}

	/**
	 * ذخیرهٔ پرچم‌های فعال‌سازی رزرو هر پزشک.
	 */
	public static function save_doctor_booking_flags( array $flags ): void {
		$clean = array();
		foreach ( $flags as $doctor_id => $enabled ) {
			$clean[ absint( $doctor_id ) ] = $enabled ? 1 : 0;
		}
		update_option( 'hsb_doctor_booking_flags', $clean, false );
	}
}
