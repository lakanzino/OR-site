<?php
/**
 * موتور ظرفیت و برنامهٔ پزشک.
 *
 * دو لایه:
 *  - HSB_Availability_Calc: محاسبات خالص و قابل‌آزمون (بدون دیتابیس).
 *  - HSB_Availability: چسباندن به wpdb و ساخت پاسخ برای REST.
 *
 * منبع حقیقت همیشه جداول خود افزونه است؛ هیچ دادهٔ نمایشی/ACF جایگزین نمی‌شود.
 *
 * @package HSB
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'HSB_TESTING' ) ) {
	exit;
}

/**
 * محاسبات خالص ظرفیت.
 */
final class HSB_Availability_Calc {

	/** وضعیت‌های ممکن یک روز برای تقویم عمومی. */
	public const STATE_PAST     = 'past';      // گذشته — غیرقابل انتخاب.
	public const STATE_INACTIVE = 'inactive';  // روز بدون برنامهٔ فعال — غیرقابل انتخاب.
	public const STATE_HOLIDAY  = 'holiday';   // تعطیل صریح (override) — آبی با برچسب «تعطیل».
	public const STATE_FULL     = 'full';      // تکمیل ظرفیت — آبی با برچسب «تکمیل ظرفیت».
	public const STATE_LOW      = 'low';       // ۱ تا ۳ جای خالی — زرد.
	public const STATE_OK       = 'ok';        // بیش از ۳ جای خالی — سبز.

	/**
	 * ساخت فهرست بازه‌های زمانی از بازهٔ شروع/پایان و طول بازه (دقیقه).
	 *
	 * @return string[] ساعت‌های شروع H:i
	 */
	public static function build_slots( string $start, string $end, int $slot_length ): array {
		$slots = array();
		if ( $slot_length < 1 ) {
			return $slots;
		}
		$start_ts = strtotime( '1970-01-01 ' . $start . ':00' );
		$end_ts   = strtotime( '1970-01-01 ' . $end . ':00' );
		if ( false === $start_ts || false === $end_ts || $end_ts <= $start_ts ) {
			return $slots;
		}
		for ( $t = $start_ts; $t + ( $slot_length * 60 ) <= $end_ts; $t += $slot_length * 60 ) {
			$slots[] = gmdate( 'H:i', $t );
		}
		return $slots;
	}

	/**
	 * ترکیب برنامهٔ هفتگی با استثنای تاریخ خاص و استخراج پنجرهٔ مؤثر یک روز.
	 *
	 * @param object|null $schedule ردیف برنامهٔ هفتگی (is_active, start_time, end_time, slot_length, capacity).
	 * @param object|null $override ردیف استثنا (is_closed, start_time, end_time, capacity).
	 * @return array{active:bool, closed:bool, holiday:bool, start:string, end:string, slot_length:int, capacity:int, reason:string}
	 */
	public static function resolve_day( $schedule, $override ): array {
		$day = array(
			'active'      => false,
			'closed'      => false,
			'holiday'     => false,
			'start'       => '',
			'end'         => '',
			'slot_length' => 0,
			'capacity'    => 0,
			'reason'      => '',
		);
		if ( $override && (int) $override->is_closed ) {
			$day['closed']  = true;
			$day['holiday'] = true;
			$day['reason']  = (string) ( $override->reason ?? '' );
			return $day;
		}
		if ( ! $schedule || ! (int) $schedule->is_active ) {
			return $day; // روز بدون برنامهٔ فعال.
		}
		$day['active']      = true;
		$day['start']       = substr( (string) $schedule->start_time, 0, 5 );
		$day['end']         = substr( (string) $schedule->end_time, 0, 5 );
		$day['slot_length'] = max( 1, (int) $schedule->slot_length );
		$day['capacity']    = max( 1, (int) $schedule->capacity );
		if ( $override ) {
			// ساعت/ظرفیت خاص برای این تاریخ (بدون تعطیلی).
			if ( ! empty( $override->start_time ) && ! empty( $override->end_time ) ) {
				$day['start'] = substr( (string) $override->start_time, 0, 5 );
				$day['end']   = substr( (string) $override->end_time, 0, 5 );
			}
			if ( null !== $override->capacity && '' !== $override->capacity ) {
				$day['capacity'] = max( 1, (int) $override->capacity );
			}
			$day['reason'] = (string) ( $override->reason ?? '' );
		}
		return $day;
	}

	/**
	 * تعیین وضعیت قابل‌فهم یک روز (برچسب متنی + رنگ).
	 *
	 * @return array{state:string, label:string, remaining:int, bookable:bool}
	 */
	public static function day_status( array $day_window, int $remaining, bool $is_past ): array {
		if ( $is_past ) {
			return array(
				'state'     => self::STATE_PAST,
				'label'     => 'گذشته',
				'remaining' => 0,
				'bookable'  => false,
			);
		}
		if ( $day_window['holiday'] ) {
			return array(
				'state'     => self::STATE_HOLIDAY,
				'label'     => 'تعطیل',
				'remaining' => 0,
				'bookable'  => false,
			);
		}
		if ( ! $day_window['active'] ) {
			return array(
				'state'     => self::STATE_INACTIVE,
				'label'     => 'غیرفعال',
				'remaining' => 0,
				'bookable'  => false,
			);
		}
		if ( $remaining <= 0 ) {
			return array(
				'state'     => self::STATE_FULL,
				'label'     => 'تکمیل ظرفیت',
				'remaining' => 0,
				'bookable'  => false,
			);
		}
		if ( $remaining <= 3 ) {
			return array(
				'state'     => self::STATE_LOW,
				'label'     => sprintf( 'فقط %d جای خالی', $remaining ),
				'remaining' => $remaining,
				'bookable'  => true,
			);
		}
		return array(
			'state'     => self::STATE_OK,
			'label'     => 'ظرفیت موجود',
			'remaining' => $remaining,
			'bookable'  => true,
		);
	}
}

/**
 * لایهٔ اتصال به پایگاه‌داده برای ظرفیت.
 */
final class HSB_Availability {

	/**
	 * ایندکس روز هفتهٔ افزونه (۰=شنبه … ۶=جمعه).
	 */
	public static function weekday_of( string $ymd ): int {
		return HSB_Jalali::weekday_index( $ymd );
	}

	/**
	 * خواندن برنامهٔ هفتگی یک پزشک (همهٔ ۷ روز).
	 *
	 * @return array<int, object> نگاشت weekday => ردیف.
	 */
	public static function get_week_schedule( int $doctor_id ): array {
		global $wpdb;
		$table = HSB_Activator::table( 'schedules' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- نام جدول داخلی است.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM $table WHERE doctor_id = %d", $doctor_id )
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row->weekday ] = $row;
		}
		return $out;
	}

	/**
	 * خواندن استثناهای یک بازهٔ تاریخی.
	 *
	 * @return array<string, object> نگاشت date => ردیف.
	 */
	public static function get_overrides( int $doctor_id, string $from, string $to ): array {
		global $wpdb;
		$table = HSB_Activator::table( 'overrides' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE doctor_id = %d AND override_date BETWEEN %s AND %s",
				$doctor_id,
				$from,
				$to
			)
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ $row->override_date ] = $row;
		}
		return $out;
	}

	/**
	 * شمارش نوبت‌های فعال (requested/confirmed) به تفکیک تاریخ برای یک بازه.
	 *
	 * @return array<string, int> نگاشت date => تعداد.
	 */
	public static function booked_counts_by_date( int $doctor_id, string $from, string $to ): array {
		global $wpdb;
		$table = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT appointment_date, COUNT(*) AS c FROM $table
				 WHERE doctor_id = %d AND appointment_date BETWEEN %s AND %s
				   AND status IN ('requested','confirmed')
				 GROUP BY appointment_date",
				$doctor_id,
				$from,
				$to
			)
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ $row->appointment_date ] = (int) $row->c;
		}
		return $out;
	}

	/**
	 * شمارش نوبت‌های فعال به تفکیک ساعت شروع برای یک روز.
	 *
	 * @return array<string, int> نگاشت H:i => تعداد.
	 */
	public static function booked_counts_by_time( int $doctor_id, string $date ): array {
		global $wpdb;
		$table = HSB_Activator::table( 'appointments' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE_FORMAT(start_time, '%%H:%%i') AS hm, COUNT(*) AS c FROM $table
				 WHERE doctor_id = %d AND appointment_date = %s
				   AND status IN ('requested','confirmed')
				 GROUP BY start_time",
				$doctor_id,
				$date
			)
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ $row->hm ] = (int) $row->c;
		}
		return $out;
	}

	/**
	 * ساخت پاسخ تقویم ۱۴ روز آینده برای یک پزشک — فقط ظرفیت و زمان، بدون هیچ هویت بیماری.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function days_payload( int $doctor_id, int $count = HSB_BOOKING_HORIZON_DAYS ): array {
		$today = HSB_Jalali::today_local();
		$from  = $today;
		$to    = gmdate( 'Y-m-d', strtotime( $today . ' +' . ( $count - 1 ) . ' days' ) );

		$schedule  = self::get_week_schedule( $doctor_id );
		$overrides = self::get_overrides( $doctor_id, $from, $to );
		$booked    = self::booked_counts_by_date( $doctor_id, $from, $to );

		$days  = array();
		$now_hm = HSB_Jalali::now_local_hm();

		for ( $i = 0; $i < $count; $i++ ) {
			$ymd   = gmdate( 'Y-m-d', strtotime( $today . ' +' . $i . ' days' ) );
			$widx  = self::weekday_of( $ymd );
			$sched = $schedule[ $widx ] ?? null;
			$ov    = $overrides[ $ymd ] ?? null;

			$window = HSB_Availability_Calc::resolve_day( $sched, $ov );

			$remaining = 0;
			if ( $window['active'] ) {
				$slots = HSB_Availability_Calc::build_slots( $window['start'], $window['end'], $window['slot_length'] );
				$slot_count_total = count( $slots ) * $window['capacity'];
				$used             = $booked[ $ymd ] ?? 0;
				$remaining        = max( 0, $slot_count_total - $used );
				// برای امروز، فقط بازه‌های آینده قابل رزرو است: یک ظرفیت فزاینده به کار نمی‌رود، ولی
				// اگر همهٔ بازه‌های امروز گذشته باشند روز باید غیرقابل انتخاب شود.
				if ( $ymd === $today ) {
					$future_slots = array_filter(
						$slots,
						function ( $hm ) use ( $now_hm ) {
							return $hm > $now_hm;
						}
					);
					if ( empty( $future_slots ) ) {
						$remaining = 0;
						if ( $window['active'] ) {
							$status = array(
								'state'     => HSB_Availability_Calc::STATE_PAST,
								'label'     => 'ساعت کاری امروز گذشته است',
								'remaining' => 0,
								'bookable'  => false,
							);
							$days[] = self::day_row( $ymd, $status );
							continue;
						}
					}
				}
			}

			$status = HSB_Availability_Calc::day_status( $window, $remaining, false );
			$days[] = self::day_row( $ymd, $status );
		}
		return $days;
	}

	/**
	 * قالب دهی یک ردیف روز برای پاسخ REST.
	 *
	 * @param array $status خروجی day_status.
	 */
	private static function day_row( string $ymd, array $status ): array {
		return array(
			'date'          => $ymd,
			'label'         => HSB_Jalali::label( $ymd, true ),
			'label_short'   => HSB_Jalali::label( $ymd, false ),
			'weekday'       => HSB_Jalali::weekday_name( HSB_Jalali::weekday_index( $ymd ) ),
			'state'         => $status['state'],
			'state_label'   => HSB_Jalali::fa_digits( $status['label'] ),
			'remaining_fa'  => HSB_Jalali::fa_digits( $status['remaining'] ),
			'bookable'      => $status['bookable'],
		);
	}

	/**
	 * ساخت فهرست بازه‌های یک روز برای یک پزشک — فقط زمان و ظرفیت.
	 *
	 * @return array<int, array<string, mixed>>|null null اگر روز قابل رزرو نیست.
	 */
	public static function slots_payload( int $doctor_id, string $ymd ): ?array {
		if ( ! HSB_Validator::date_ymd( $ymd ) ) {
			return null;
		}
		$today = HSB_Jalali::today_local();
		if ( $ymd < $today ) {
			return null; // روز گذشته.
		}
		$max = gmdate( 'Y-m-d', strtotime( $today . ' +' . ( HSB_BOOKING_HORIZON_DAYS - 1 ) . ' days' ) );
		if ( $ymd > $max ) {
			return null; // بیرون از افق رزرو.
		}
		$schedule  = self::get_week_schedule( $doctor_id );
		$overrides = self::get_overrides( $doctor_id, $ymd, $ymd );
		$window    = HSB_Availability_Calc::resolve_day(
			$schedule[ self::weekday_of( $ymd ) ] ?? null,
			$overrides[ $ymd ] ?? null
		);
		if ( ! $window['active'] || $window['holiday'] ) {
			return null;
		}
		$counts = self::booked_counts_by_time( $doctor_id, $ymd );
		$now_hm = HSB_Jalali::now_local_hm();
		$out    = array();
		foreach ( HSB_Availability_Calc::build_slots( $window['start'], $window['end'], $window['slot_length'] ) as $hm ) {
			$used      = $counts[ $hm ] ?? 0;
			$remaining = max( 0, $window['capacity'] - $used );
			$is_past   = ( $ymd === $today && $hm <= $now_hm );
			$end_hm    = gmdate( 'H:i', strtotime( '1970-01-01 ' . $hm . ':00' ) + $window['slot_length'] * 60 );
			$out[]     = array(
				'time'         => $hm,
				'time_fa'      => HSB_Jalali::fa_digits( $hm ),
				'end'          => $end_hm,
				'end_fa'       => HSB_Jalali::fa_digits( $end_hm ),
				'remaining_fa' => HSB_Jalali::fa_digits( $remaining ),
				'bookable'     => ( $remaining > 0 && ! $is_past ),
			);
		}
		return $out;
	}
}
