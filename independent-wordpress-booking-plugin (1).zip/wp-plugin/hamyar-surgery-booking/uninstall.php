<?php
/**
 * حذف افزونه (uninstall).
 *
 * توجه مهم: غیرفعال‌سازی افزونه هرگز داده‌ای را حذف نمی‌کند.
 * حذف کامل داده‌ها (جداول و تنظیمات) فقط وقتی انجام می‌شود که مدیر صریحاً در صفحهٔ
 * «تنظیمات نوبت‌دهی» گزینهٔ «حذف کامل داده‌ها هنگام پاک‌کردن افزونه» را فعال کرده باشد.
 *
 * @package HSB
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'hsb_settings', array() );

if ( ! is_array( $settings ) || empty( $settings['delete_data_on_uninstall'] ) ) {
	// تصمیم صریح مدیر برای حذف داده‌ها وجود ندارد؛ همه‌چیز حفظ می‌شود.
	return;
}

global $wpdb;

// حذف جداول اختصاصی فقط با تصمیم صریح مدیر.
$tables = array(
	$wpdb->prefix . 'hsb_appointments',
	$wpdb->prefix . 'hsb_overrides',
	$wpdb->prefix . 'hsb_schedules',
);
foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange
	$wpdb->query( "DROP TABLE IF EXISTS `$table`" );
}

delete_option( 'hsb_settings' );
delete_option( 'hsb_schema_version' );
delete_option( 'hsb_user_doctor_map' );
delete_option( 'hsb_doctor_booking_flags' );
