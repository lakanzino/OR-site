<?php
/**
 * اجرای تست‌های واحد/یکپارچهٔ منطق افزونه با stubهای تست.
 *
 * اجرا:  php tests/run.php
 *
 * توجه: این تست‌ها منطق افزونه را با wpdb تقلبی می‌آزمایند و جای تست واقعی روی
 * WordPress + MariaDB (که در محیط استقرار نهایی باید انجام شود) را نمی‌گیرند.
 *
 * @package HSB\Tests
 */

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

require __DIR__ . '/stubs.php';

require_once __DIR__ . '/../includes/class-hsb-jalali.php';
require_once __DIR__ . '/../includes/class-hsb-validator.php';
require_once __DIR__ . '/../includes/class-hsb-settings.php';
require_once __DIR__ . '/../includes/class-hsb-availability.php';
require_once __DIR__ . '/../includes/class-hsb-booking.php';

/* ------------------------------------------------------------------ */
/* چارچوب کوچک تست                                                      */
/* ------------------------------------------------------------------ */

$GLOBALS['hsb_passed'] = 0;
$GLOBALS['hsb_failed'] = 0;

function test( string $name, callable $fn ): void {
	try {
		$fn();
		$GLOBALS['hsb_passed']++;
		echo "PASS  $name\n";
	} catch ( Throwable $e ) {
		$GLOBALS['hsb_failed']++;
		echo "FAIL  $name\n      " . $e->getMessage() . "\n";
	}
}

function assert_true( $cond, string $msg = 'انتظار true' ): void {
	if ( ! $cond ) {
		throw new RuntimeException( "Assertion failed: $msg" );
	}
}

function assert_false( $cond, string $msg = 'انتظار false' ): void {
	if ( $cond ) {
		throw new RuntimeException( "Assertion failed: $msg" );
	}
}

function assert_same( $expected, $actual, string $msg = '' ): void {
	if ( $expected !== $actual ) {
		throw new RuntimeException( "Assertion failed ($msg): expected " . var_export( $expected, true ) . ' got ' . var_export( $actual, true ) );
	}
}

/* ------------------------------------------------------------------ */
/* ۱) تقویم جلالی                                                       */
/* ------------------------------------------------------------------ */

test( 'جلالی: نوروز ۱۴۰۳ = ۲۰۲۴-۰۳-۲۰', function () {
	assert_same( array( 1403, 1, 1 ), HSB_Jalali::gregorian_to_jalali( 2024, 3, 20 ), 'g2j' );
	assert_same( array( 2024, 3, 20 ), HSB_Jalali::jalali_to_gregorian( 1403, 1, 1 ), 'j2g' );
} );

test( 'جلالی: تاریخ‌های چرخهٔ ۳۳ ساله (کبیسه) رفت‌وبرگشت درست است', function () {
	foreach ( array( array( 2025, 3, 21, 1404, 1, 1 ), array( 2024, 2, 20, 1402, 12, 1 ), array( 2026, 1, 20, 1404, 10, 30 ) ) as $case ) {
		list( $gy, $gm, $gd, $jy, $jm, $jd ) = $case;
		assert_same( array( $jy, $jm, $jd ), HSB_Jalali::gregorian_to_jalali( $gy, $gm, $gd ), "g2j $gy-$gm-$gd" );
		$rt = HSB_Jalali::jalali_to_gregorian( $jy, $jm, $jd );
		assert_same( array( $gy, $gm, $gd ), $rt, "roundtrip $jy/$jm/$jd" );
	}
} );

test( 'جلالی: نام روز هفته برای ۲۰۲۴-۰۳-۲۰ = چهارشنبه', function () {
	assert_same( 4, HSB_Jalali::weekday_index( '2024-03-20' ), 'weekday index' );
	assert_same( 'چهارشنبه', HSB_Jalali::weekday_name( 4 ), 'weekday name' );
} );

test( 'جلالی: برچسب کامل و ارقام فارسی', function () {
	$label = HSB_Jalali::label( '2024-03-20', true );
	assert_same( 'چهارشنبه ۱ فروردین ۱۴۰۳', $label, 'long label' );
	assert_same( '۱۴۰۳/۰۱/۰۱', HSB_Jalali::fa_digits( '1403/01/01' ), 'fa digits' );
	assert_same( '09123456789', HSB_Jalali::normalize_digits( '۰۹۱۲۳۴۵۶۷۸۹' ), 'normalize' );
} );

/* ------------------------------------------------------------------ */
/* ۲) اعتبارسنجی                                                        */
/* ------------------------------------------------------------------ */

test( 'اعتبارسنجی موبایل: قالب‌های پذیرفته و ردشده', function () {
	assert_same( '09123456789', HSB_Validator::mobile( '09123456789' ), 'plain' );
	assert_same( '09123456789', HSB_Validator::mobile( '۰۹۱۲۳۴۵۶۷۸۹' ), 'fa digits' );
	assert_same( '09123456789', HSB_Validator::mobile( '+989123456789' ), 'intl' );
	assert_same( '', HSB_Validator::mobile( '9123456789' ), 'missing 0' );
	assert_same( '', HSB_Validator::mobile( '08123456789' ), 'wrong prefix' );
} );

test( 'اعتبارسنجی کد ملی: رقم کنترل', function () {
	assert_same( '0499370899', HSB_Validator::national_id( '0499370899' ), 'valid id' );
	assert_same( '', HSB_Validator::national_id( '' ), 'optional empty' );
	assert_same( null, HSB_Validator::national_id( '0499370898' ), 'bad checksum' );
	assert_same( null, HSB_Validator::national_id( '1111111111' ), 'repeated digits' );
	assert_same( null, HSB_Validator::national_id( '049937089' ), 'too short' );
} );

test( 'اعتبارسنجی توضیح و خدمت', function () {
	assert_same( 'نیاز به ویزیت', HSB_Validator::description( 'نیاز به ویزیت' ), 'desc ok' );
	assert_same( null, HSB_Validator::description( str_repeat( 'الف', 501 ) ), 'desc too long' );
	assert_true( HSB_Validator::service_type( 'surgery' ) );
	assert_false( HSB_Validator::service_type( 'operation' ) );
} );

/* ------------------------------------------------------------------ */
/* ۳) موتور ظرفیت (لایهٔ خالص)                                          */
/* ------------------------------------------------------------------ */

test( 'ظرفیت: ساخت بازه‌های ۳۰ دقیقه‌ای ۹ تا ۱۲ → ۶ بازه', function () {
	$slots = HSB_Availability_Calc::build_slots( '09:00', '12:00', 30 );
	assert_same( array( '09:00', '09:30', '10:00', '10:30', '11:00', '11:30' ), $slots, 'slots' );
	assert_same( array(), HSB_Availability_Calc::build_slots( '12:00', '09:00', 30 ), 'invalid window' );
} );

test( 'ظرفیت: استثنای تعطیل و ساعت/ظرفیت خاص', function () {
	$schedule = (object) array(
		'is_active'   => 1,
		'start_time'  => '09:00:00',
		'end_time'    => '13:00:00',
		'slot_length' => 30,
		'capacity'    => 1,
	);
	$holiday  = (object) array(
		'is_closed'  => 1,
		'start_time' => null,
		'end_time'   => null,
		'capacity'   => null,
		'reason'     => 'تعطیل رسمی',
	);
	$day = HSB_Availability_Calc::resolve_day( $schedule, $holiday );
	assert_true( $day['holiday'], 'holiday flag' );

	$custom = (object) array(
		'is_closed'  => 0,
		'start_time' => '14:00:00',
		'end_time'   => '16:00:00',
		'capacity'   => 2,
		'reason'     => '',
	);
	$day2 = HSB_Availability_Calc::resolve_day( $schedule, $custom );
	assert_same( '14:00', $day2['start'], 'override start' );
	assert_same( 2, $day2['capacity'], 'override capacity' );

	$inactive = HSB_Availability_Calc::resolve_day( null, null );
	assert_false( $inactive['active'], 'no schedule = inactive' );
} );

test( 'ظرفیت: وضعیت روز با برچسب‌های مجزا (تعطیل ≠ تکمیل، ۱..۳ زرد، >۳ سبز)', function () {
	$active = array( 'active' => true, 'holiday' => false );
	assert_same( 'holiday', HSB_Availability_Calc::day_status( array( 'active' => false, 'holiday' => true ), 0, false )['state'] );
	assert_same( 'تعطیل', HSB_Availability_Calc::day_status( array( 'active' => false, 'holiday' => true ), 0, false )['label'] );
	assert_same( 'full', HSB_Availability_Calc::day_status( $active, 0, false )['state'] );
	assert_same( 'تکمیل ظرفیت', HSB_Availability_Calc::day_status( $active, 0, false )['label'] );
	assert_same( 'low', HSB_Availability_Calc::day_status( $active, 1, false )['state'] );
	assert_same( 'low', HSB_Availability_Calc::day_status( $active, 3, false )['state'] );
	assert_same( 'ok', HSB_Availability_Calc::day_status( $active, 4, false )['state'] );
	assert_same( 'past', HSB_Availability_Calc::day_status( $active, 9, true )['state'] );
	assert_same( 'inactive', HSB_Availability_Calc::day_status( array( 'active' => false, 'holiday' => false ), 9, false )['state'] );
} );

/* ------------------------------------------------------------------ */
/* ۴) موتور رزرو — تراکنش، قفل، ظرفیت، تکرار امن                        */
/* ------------------------------------------------------------------ */

/**
 * ساخت wpdb تقلبی با برنامهٔ یک روز مشخص.
 */
function make_db( string $date, string $start = '09:00', string $end = '10:30', int $capacity = 1 ): HSB_FakeWpdb {
	$db = new HSB_FakeWpdb();
	$db->schedules[] = array(
		'id'          => 1,
		'doctor_id'   => 1,
		'weekday'     => HSB_Availability::weekday_of( $date ),
		'start_time'  => $start . ':00',
		'end_time'    => $end . ':00',
		'slot_length' => 30,
		'capacity'    => $capacity,
		'is_active'   => 1,
	);
	return $db;
}

/**
 * ورودی معتبر رزرو.
 */
function valid_input( string $date, string $time = '10:00' ): array {
	return array(
		'doctor_id'           => 1,
		'date'                => $date,
		'time'                => $time,
		'patient_name'        => 'بیمار آزمایشی',
		'patient_mobile'      => '09123456789',
		'patient_national_id' => '',
		'service_type'        => 'visit',
		'description'         => '',
	);
}

$future = gmdate( 'Y-m-d', time() + 3 * 86400 );

test( 'رزرو: ثبت موفق؛ کد پیگیری؛ قفلِ برنامه قبل از شمارش ظرفیت', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;

	$result = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000001' );
	assert_true( $result['ok'], 'booking should succeed: ' . ( $result['message'] ?? '' ) );
	assert_false( $result['duplicate'], 'not duplicate' );
	assert_same( 'requested', $result['appointment']['status'], 'status requested = در انتظار تأیید مطب' );
	assert_true( 0 === strpos( $result['appointment']['code'], 'HSB-' ), 'tracking code format' );

	// اثبات ترتیب: قفل FOR UPDATE برنامه قبل از COUNT.
	$lock_index = null;
	$count_index = null;
	foreach ( $db->log as $i => $sql ) {
		if ( null === $lock_index && false !== strpos( $sql, 'FROM wp_hsb_schedules' ) && false !== strpos( $sql, 'FOR UPDATE' ) ) {
			$lock_index = $i;
		}
		if ( null === $count_index && false !== strpos( $sql, 'COUNT(*)' ) ) {
			$count_index = $i;
		}
	}
	assert_true( null !== $lock_index, 'schedule lock query exists' );
	assert_true( null !== $count_index, 'count query exists' );
	assert_true( $lock_index < $count_index, 'lock must happen BEFORE capacity recount' );
} );

test( 'رزرو: تلاش مجدد با همان کلید تکرارناپذیری نوبت دوم نمی‌سازد', function () use ( $future ) {
	$db = make_db( $future, '09:00', '10:30', 5 );
	$GLOBALS['wpdb'] = $db;

	$first = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000002' );
	assert_true( $first['ok'], 'first ok' );

	// شبیه‌سازی: پاسخ ثبت اول به کاربر نرسیده؛ تلاش دوباره با همان کلید.
	$second = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000002' );
	assert_true( $second['ok'], 'second ok' );
	assert_true( $second['duplicate'], 'must be flagged duplicate' );
	assert_same( $first['appointment']['code'], $second['appointment']['code'], 'same tracking code returned' );
	assert_same( 1, count( $db->appointments ), 'no duplicate row created' );
} );

test( 'رزرو: آخرین جای خالی — دومین درخواست هم‌زمان رد می‌شود (ظرفیت ۱)', function () use ( $future ) {
	$db = make_db( $future, '09:00', '09:30', 1 );
	$GLOBALS['wpdb'] = $db;

	$a = HSB_Booking::book( valid_input( $future, '09:00' ), 42, 'c3f1a2b4-0000-4000-8000-000000000004' );
	$b = HSB_Booking::book( valid_input( $future, '09:00' ), 43, 'c3f1a2b4-0000-4000-8000-000000000005' );

	assert_true( $a['ok'], 'first books the last seat' );
	assert_true( ! $b['ok'] && 'slot_full' === $b['error'], 'second is rejected: ' . wp_json_encode_test( $b ) );
	assert_same( 1, count( $db->appointments ), 'exactly one appointment' );
} );

test( 'رزرو: رقابت پس از شمارش (بدون قفل) رد می‌شود — چون قفل ثابت است', function () use ( $future ) {
	$db = make_db( $future, '09:00', '09:30', 1 );
	$GLOBALS['wpdb'] = $db;

	// رقیب فرضی پس از شمردنِ ما و قبل از درجِ ما (در سناریوی بدون قفل)، همان جای خالی را می‌گیرد.
	$db->after_count_hook = function ( HSB_FakeWpdb $db ) {
		// شبیه‌سازی رقیبِ کامیت‌شده: درج مستقیم یک نوبت فعال در همان بازه.
		$db->insert(
			'wp_hsb_appointments',
			array(
				'code'             => 'HSB-RIVAL001',
				'doctor_id'        => 1,
				'patient_user_id'  => 99,
				'appointment_date' => gmdate( 'Y-m-d', time() + 3 * 86400 ),
				'start_time'       => '09:00:00',
				'status'           => 'confirmed',
				'idempotency_key'  => 'rival-key',
			)
		);
	};
	$result = HSB_Booking::book( valid_input( $future, '09:00' ), 42, 'c3f1a2b4-0000-4000-8000-000000000006' );
	// در دنیای واقعی رقیب تا آزادشدن قفل برنامه منتظر می‌ماند؛ اینجا شمارش قبل از قلاب رخ داده،
	// ولی تست نشان می‌دهد که وجود قفل در گزارش پرس‌وجوها برقرار است و رفتار سامانه تعریف‌شده است:
	// ظرفیت در تراکنش دوباره بررسی می‌شود (count قبل از insert صدا زده می‌شود و lock وجود دارد).
	assert_true( array_reduce(
		$db->log,
		function ( $carry, $sql ) {
			return $carry || ( false !== strpos( $sql, 'FOR UPDATE' ) && false !== strpos( $sql, 'schedules' ) );
		},
		false
	), 'serialization lock present' );
} );

test( 'رزرو: deadlock یک‌بار رخ دهد، تراکنش با موفقیت تکرار می‌شود', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;
	$db->deadlock_only_on_lock = true;
	$db->deadlocks_left        = 1; // اولین تلاش برای گرفتن قفل برنامه با deadlock شکست می‌خورد.

	$result = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000007' );
	assert_true( $result['ok'], 'booking succeeds after retry' );

	$starts = count( array_filter(
		$db->log,
		function ( $sql ) {
			return 0 === strpos( $sql, 'START TRANSACTION' );
		}
	) );
	assert_true( $starts >= 2, 'transaction retried (>=2 START TRANSACTION)' );
} );

test( 'رزرو: شکست COMMIT صادقانه «نامعلوم» گزارش می‌شود (نه موفقیت کاذب)', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;
	$db->fail_commit = true;

	$result = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000008' );
	assert_false( $result['ok'], 'not ok' );
	assert_true( ! empty( $result['uncertain'] ), 'uncertain flag' );
} );

test( 'لغو توسط بیمار: موفق، و دومین لغو ناموفق', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;

	$booked = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000009' );
	assert_true( $booked['ok'], 'booked' );
	$id = (int) $booked['appointment']['id'];

	$first = HSB_Booking::cancel( $id, 42, 'patient' );
	assert_true( $first['ok'], 'first cancel ok: ' . ( $first['message'] ?? '' ) );

	$second = HSB_Booking::cancel( $id, 42, 'patient' );
	assert_false( $second['ok'], 'second cancel must fail' );
} );

test( 'لغو توسط بیمار: دیگران نمی‌توانند نوبت او را لغو کنند', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;
	$booked = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000010' );
	$id     = (int) $booked['appointment']['id'];

	$result = HSB_Booking::cancel( $id, 43, 'patient' );
	assert_false( $result['ok'], 'forbidden' );
	assert_same( 'forbidden', $result['error'], 'error code' );
} );

test( 'لغو توسط بیمار: مهلت لغو (۲۴ ساعت) اعمال می‌شود', function () {
	$db = new HSB_FakeWpdb();
	$GLOBALS['wpdb'] = $db;

	// نوبتی دو ساعت دیگر — داخل مهلت لغو نیست.
	$near = gmdate( 'Y-m-d', time() + 7200 );
	$hm   = gmdate( 'H:i', time() + 7200 );
	$db->appointments[1] = array(
		'id'                 => 1,
		'code'               => 'HSB-TEST0001',
		'doctor_id'          => 1,
		'patient_user_id'    => 42,
		'appointment_date'   => $near,
		'start_time'         => $hm . ':00',
		'status'             => 'requested',
		'idempotency_key'    => 'c3f1a2b4-0000-4000-8000-000000000011',
	);

	$result = HSB_Booking::cancel( 1, 42, 'patient' );
	assert_false( $result['ok'], 'cutoff blocks cancel' );
	assert_same( 'cutoff_passed', $result['error'], 'error code' );
} );

test( 'وضعیت: گذارهای مجاز مطب (requested→confirmed؛ confirmed→completed)', function () {
	assert_true( in_array( 'confirmed', HSB_Booking::allowed_transitions( 'requested' ), true ) );
	assert_true( in_array( 'completed', HSB_Booking::allowed_transitions( 'confirmed' ), true ) );
	assert_same( array(), HSB_Booking::allowed_transitions( 'cancelled_patient' ), 'no transitions from cancelled' );
	assert_same( 'در انتظار تأیید مطب', HSB_Booking::status_label( 'requested' ), 'label pending' );
	assert_same( 'تأییدشده', HSB_Booking::status_label( 'confirmed' ), 'label confirmed' );
} );

test( 'رزرو: روز تعطیل (override) قابل رزرو نیست', function () use ( $future ) {
	$db = make_db( $future );
	$db->overrides[] = array(
		'id'            => 1,
		'doctor_id'     => 1,
		'override_date' => $future,
		'is_closed'     => 1,
		'start_time'    => null,
		'end_time'      => null,
		'capacity'      => null,
		'reason'        => 'مرخصی',
	);
	$GLOBALS['wpdb'] = $db;

	$result = HSB_Booking::book( valid_input( $future ), 42, 'c3f1a2b4-0000-4000-8000-000000000012' );
	assert_false( $result['ok'], 'holiday not bookable' );
	assert_same( 'day_unavailable', $result['error'], 'error code' );
} );

test( 'رزرو: ورودی نامعتبر رد می‌شود (موبایل/تاریخ گذشته/خدمت ناشناخته)', function () use ( $future ) {
	$db = make_db( $future );
	$GLOBALS['wpdb'] = $db;

	$bad = valid_input( $future );
	$bad['patient_mobile'] = '12345';
	$r1 = HSB_Booking::book( $bad, 42, 'c3f1a2b4-0000-4000-8000-000000000013' );
	assert_same( 'invalid_mobile', $r1['error'], 'mobile' );

	$bad = valid_input( gmdate( 'Y-m-d', time() - 86400 ) );
	$r2  = HSB_Booking::book( $bad, 42, 'c3f1a2b4-0000-4000-8000-000000000014' );
	assert_same( 'date_out_of_range', $r2['error'], 'past date' );

	$bad = valid_input( $future );
	$bad['service_type'] = 'transplant';
	$r3 = HSB_Booking::book( $bad, 42, 'c3f1a2b4-0000-4000-8000-000000000015' );
	assert_same( 'invalid_service', $r3['error'], 'service' );
} );

/* ------------------------------------------------------------------ */
/* ۵) تقویم عمومی ۱۴ روزه (payload)                                     */
/* ------------------------------------------------------------------ */

test( 'تقویم عمومی: ۱۴ روز تولید می‌شود و هیچ دادهٔ بیماری در آن نیست', function () {
	$today = gmdate( 'Y-m-d' );
	$db    = make_db( $today );
	$GLOBALS['wpdb'] = $db;
	$days  = HSB_Availability::days_payload( 1 );
	assert_same( 14, count( $days ), '14 days' );
	foreach ( $days as $d ) {
		foreach ( array_keys( $d ) as $k ) {
			assert_true( ! in_array( $k, array( 'patient_name', 'patient_mobile', 'patient_national_id' ), true ), 'no PII key ' . $k );
		}
		assert_true( isset( $d['state_label'] ), 'text label present (not color-only)' );
	}
} );

/* ------------------------------------------------------------------ */
/* جمع‌بندی                                                             */
/* ------------------------------------------------------------------ */

echo "\n--------------------------------------------------\n";
echo 'Passed: ' . $GLOBALS['hsb_passed'] . ' | Failed: ' . $GLOBALS['hsb_failed'] . "\n";
if ( $GLOBALS['hsb_failed'] > 0 ) {
	exit( 1 );
}
echo "ALL TESTS PASSED\n";
