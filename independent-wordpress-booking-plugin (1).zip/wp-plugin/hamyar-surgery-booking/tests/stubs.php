<?php
/**
 * هارنس تست مستقل — stubهای حداقلی وردپرس + wpdb تقلبی با پشتیبانی تراکنش و خطای برنامه‌ریزی‌شده.
 *
 * این stubها فقط برای اجرای منطق خالص افزونه (جلالی، اعتبارسنجی، ظرفیت، موتور رزرو) نوشته شده‌اند
 * و جایگزین تست روی وردپرسِ واقعی + MariaDB نیستند (این محدودیت صریحاً اعلام می‌شود).
 *
 * @package HSB\Tests
 */

define( 'HSB_TESTING', true );
if ( ! defined( 'HSB_BOOKING_HORIZON_DAYS' ) ) {
	define( 'HSB_BOOKING_HORIZON_DAYS', 14 );
}

/* ------------------------------------------------------------------ */
/* توابع حداقلی وردپرس                                                 */
/* ------------------------------------------------------------------ */

$GLOBALS['hsb_test_options'] = array();

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['hsb_test_options'] ) ? $GLOBALS['hsb_test_options'][ $key ] : $default;
}
function update_option( $key, $value, $autoload = null ) {
	$GLOBALS['hsb_test_options'][ $key ] = $value;
	return true;
}
function add_option( $key, $value, $deprecated = '', $autoload = null ) {
	if ( ! array_key_exists( $key, $GLOBALS['hsb_test_options'] ) ) {
		$GLOBALS['hsb_test_options'][ $key ] = $value;
	}
	return true;
}
function delete_option( $key ) {
	unset( $GLOBALS['hsb_test_options'][ $key ] );
	return true;
}
function current_time( $type = 'mysql', $gmt = 0 ) {
	return 'mysql' === $type ? gmdate( 'Y-m-d H:i:s' ) : time();
}
function sanitize_key( $key ) {
	return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $key ) );
}
function absint( $maybe ) {
	return abs( (int) $maybe );
}
function sanitize_text_field( $str ) {
	return trim( strip_tags( (string) $str ) );
}
function sanitize_email( $email ) {
	return trim( (string) $email );
}
function is_email( $email ) {
	return (bool) filter_var( $email, FILTER_VALIDATE_EMAIL );
}
function wp_strip_all_tags( $text ) {
	return strip_tags( (string) $text );
}
function wp_unslash( $v ) {
	return $v;
}
function do_action( $hook, ...$args ) {
	$GLOBALS['hsb_test_actions'][] = array( $hook, $args );
	return null;
}
function has_action( $hook ) {
	return false;
}
function __( $text, $domain = null ) {
	return $text;
}
function esc_html__( $text, $domain = null ) {
	return $text;
}
function is_user_logged_in() {
	return true;
}
function get_current_user_id() {
	return $GLOBALS['hsb_test_user_id'] ?? 1;
}

/* ------------------------------------------------------------------ */
/* Stub از کلاس‌هایی که به وردپرس کامل گره خورده‌اند                    */
/* ------------------------------------------------------------------ */

/**
 * Stub جداول.
 */
class HSB_Activator {
	public static function table( string $table ): string {
		return 'wp_hsb_' . $table;
	}
}

/**
 * Stub لایهٔ اتصال پزشک: در تست‌ها پزشک ۱ فعال فرض می‌شود.
 */
class HSB_Doctor {
	public static $enabled = true;
	public static function provider_is_configured(): bool {
		return self::$enabled;
	}
	public static function get_public( int $doctor_id ): ?array {
		if ( ! self::$enabled || 1 !== $doctor_id ) {
			return null;
		}
		return array(
			'id'   => 1,
			'name' => 'دکتر نمونه',
		);
	}
}

/* ------------------------------------------------------------------ */
/* wpdb تقلبی                                                          */
/* ------------------------------------------------------------------ */

/**
 * شبیه‌ساز wpdb با:
 *  - ثبت گزارش پرس‌وجوها (برای اثبات ترتیب «قفل قبل از شمارش»).
 *  - پشتیبانی حداقلی از الگوهای SQL که افزونه تولید می‌کند.
 *  - تزریق خطای برنامه‌ریزی‌شده (deadlock، duplicate key، شکست commit).
 *  - شمارش درخواست‌های «هم‌زمان» برای آزمون قفل (هر ورود به book قبل از قفل شمرده می‌شود).
 */
class HSB_FakeWpdb {
	public string $prefix = 'wp_';
	public string $last_error = '';
	public int $insert_id = 0;
	public int $rows_affected = 0;

	/** @var array<int, array<string, mixed>> */
	public array $schedules = array();
	/** @var array<int, array<string, mixed>> */
	public array $overrides = array();
	/** @var array<int, array<string, mixed>> */
	public array $appointments = array();
	public int $next_appt_id = 1;

	/** @var string[] گزارش پرس‌وجوها */
	public array $log = array();

	/** @var string[] خطاهای برنامه‌ریزی‌شده: deadlock_count/duplicate_next_idem/commit_fail */
	public string $scripted_error = '';
	public bool $fail_commit = false;
	public int $deadlocks_left = 0;
	public bool $deadlock_only_on_lock = false;

	/** شمارندهٔ هم‌زمانی: نشان می‌دهد آیا دو تراکنش هم‌زمان روی همان قفل رخ داده است. */
	public bool $schedule_lock_held = false;
	public int $concurrent_conflict_attempts = 0;

	/** @var callable|null قلاب شبیه‌سازی رقابت: بعد از «شمردن» ظرفیت و قبل از insert صدا زده می‌شود. */
	public $after_count_hook = null;

	private int $auto_code_seq = 0;

	public function prepare( string $sql, ...$args ): string {
		if ( 1 === count( $args ) && is_array( $args[0] ) ) {
			$args = $args[0];
		}
		$out = $sql;
		foreach ( $args as $arg ) {
			if ( is_int( $arg ) || is_float( $arg ) || null === $arg ) {
				$replacement = null === $arg ? 'NULL' : (string) $arg;
				$out         = preg_replace( '/%d/', $replacement, $out, 1 );
			} else {
				$escaped = addslashes( (string) $arg );
				$out     = preg_replace( '/%s/', "'" . $escaped . "'", $out, 1 );
			}
		}
		return $out;
	}

	public function get_charset_collate(): string {
		return 'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';
	}

	/**
	 * اجرای پرس‌وجوی عمومی (تراکنش، UPDATE، COUNT، DELETE …).
	 *
	 * @return int|bool
	 */
	public function query( string $sql ) {
		$this->log[]      = $sql;
		$this->last_error = '';

		if ( preg_match( '/^(START TRANSACTION|ROLLBACK|COMMIT)/', $sql, $m ) ) {
			if ( 'COMMIT' === $m[1] && ( $this->fail_commit || $this->consume_deadlock() ) ) {
				$this->last_error = 'Lost connection to MySQL server during query';
				return false;
			}
			if ( 'START TRANSACTION' === $m[1] ) {
				$this->schedule_lock_held = false;
			}
			return 1;
		}

		if ( $this->consume_deadlock( $sql ) ) {
			return false;
		}

		// UPDATE appointments شرطی روی وضعیت.
		if ( preg_match( '/^UPDATE wp_hsb_appointments SET status = \'([^\']+)\'.*WHERE id = (\d+) AND status = \'([^\']+)\'/', $sql, $m ) ) {
			foreach ( $this->appointments as $id => $row ) {
				if ( (int) $id === (int) $m[2] && $row['status'] === $m[3] ) {
					$this->appointments[ $id ]['status'] = $m[1];
					$this->rows_affected                 = 1;
					return 1;
				}
			}
			$this->rows_affected = 0;
			return 0;
		}

		if ( preg_match( '/SELECT COUNT\(\*\) FROM wp_hsb_appointments\s+WHERE doctor_id = (\d+) AND appointment_date = \'([^\']+)\' AND start_time = \'([^\']+)\'/', $sql, $m ) ) {
			// شمارش در موتور رزرو — با قلاب شبیه‌سازی رقابت.
			$count = $this->count_active_slot( (int) $m[1], $m[2], $m[3] );
			if ( $this->after_count_hook ) {
				( $this->after_count_hook )( $this );
			}
			$this->last_count_result = $count;
			$this->rows_affected     = 1;
			return 1;
		}

		return 1;
	}

	public $last_count_result = 0;

	/**
	 * get_row با تشخیص الگو.
	 *
	 * @return object|null
	 */
	public function get_row( string $sql ) {
		$this->log[] = $sql;

		if ( $this->consume_deadlock( $sql ) ) {
			return null;
		}
		$this->last_error = '';

		if ( preg_match( '/FROM wp_hsb_schedules WHERE doctor_id = (\d+) AND weekday = (\d+) FOR UPDATE/', $sql, $m ) ) {
			// شبیه‌سازی قفل: اگر تراکنش دیگری قفل را دارد اینجا «منتظر/رقبا» تشخیص داده می‌شود.
			if ( $this->schedule_lock_held ) {
				$this->concurrent_conflict_attempts++;
			}
			$this->schedule_lock_held = true;
			foreach ( $this->schedules as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1] && (int) $row['weekday'] === (int) $m[2] ) {
					return (object) $row;
				}
			}
			return null;
		}

		if ( preg_match( '/FROM wp_hsb_overrides WHERE doctor_id = (\d+) AND override_date = \'([^\']+)\' FOR UPDATE/', $sql, $m ) ) {
			foreach ( $this->overrides as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1] && $row['override_date'] === $m[2] ) {
					return (object) $row;
				}
			}
			return null;
		}

		if ( preg_match( '/FROM wp_hsb_appointments WHERE idempotency_key = \'([^\']+)\'/', $sql, $m ) ) {
			foreach ( $this->appointments as $row ) {
				if ( $row['idempotency_key'] === $m[1] ) {
					return (object) $row;
				}
			}
			return null;
		}

		if ( preg_match( '/FROM wp_hsb_appointments WHERE id = (\d+)( FOR UPDATE)?/', $sql, $m ) ) {
			$id = (int) $m[1];
			return isset( $this->appointments[ $id ] ) ? (object) $this->appointments[ $id ] : null;
		}

		return null;
	}

	/**
	 * get_var: فقط SELECT COUNT(*) از موتور رزرو.
	 *
	 * @return string|int|null
	 */
	public function get_var( string $sql ) {
		$this->log[] = $sql;

		if ( $this->consume_deadlock( $sql ) ) {
			$this->last_error = 'Deadlock found when trying to get lock';
			return null;
		}
		$this->last_error = '';

		if ( preg_match( '/COUNT\(\*\) FROM wp_hsb_appointments\s+WHERE doctor_id = (\d+) AND appointment_date = \'([^\']+)\' AND start_time = \'([^\']+)\'/', $sql, $m ) ) {
			if ( $this->after_count_hook ) {
				( $this->after_count_hook )( $this );
			}
			return $this->count_active_slot( (int) $m[1], $m[2], $m[3] );
		}

		return 0;
	}

	/**
	 * get_results حداقلی — برای خواندن برنامه/نوبت‌ها در تست‌های ظرفیت.
	 */
	public function get_results( string $sql ): array {
		$this->log[]      = $sql;
		$this->last_error = '';

		if ( preg_match( '/FROM wp_hsb_schedules WHERE doctor_id = (\d+)/', $sql, $m ) ) {
			$out = array();
			foreach ( $this->schedules as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1] ) {
					$out[] = (object) $row;
				}
			}
			return $out;
		}

		if ( preg_match( '/FROM wp_hsb_overrides WHERE doctor_id = (\d+) AND override_date BETWEEN \'([^\']+)\' AND \'([^\']+)\'/', $sql, $m ) ) {
			$out = array();
			foreach ( $this->overrides as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1] && $row['override_date'] >= $m[2] && $row['override_date'] <= $m[3] ) {
					$out[] = (object) $row;
				}
			}
			return $out;
		}

		if ( preg_match( '/GROUP BY appointment_date$/', $sql ) && preg_match( '/doctor_id = (\d+) AND appointment_date BETWEEN \'([^\']+)\' AND \'([^\']+)\'/', $sql, $m ) ) {
			$out = array();
			foreach ( $this->appointments as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1]
					&& $row['appointment_date'] >= $m[2] && $row['appointment_date'] <= $m[3]
					&& in_array( $row['status'], array( 'requested', 'confirmed' ), true )
				) {
					$key = $row['appointment_date'];
					if ( ! isset( $out[ $key ] ) ) {
						$out[ $key ] = (object) array(
							'appointment_date' => $key,
							'c'                => 0,
						);
					}
					$out[ $key ]->c++;
				}
			}
			return array_values( $out );
		}

		if ( preg_match( '/GROUP BY start_time/', $sql ) && preg_match( '/doctor_id = (\d+) AND appointment_date = \'([^\']+)\'/', $sql, $m ) ) {
			$out = array();
			foreach ( $this->appointments as $row ) {
				if ( (int) $row['doctor_id'] === (int) $m[1] && $row['appointment_date'] === $m[2]
					&& in_array( $row['status'], array( 'requested', 'confirmed' ), true )
				) {
					$hm = substr( $row['start_time'], 0, 5 );
					if ( ! isset( $out[ $hm ] ) ) {
						$out[ $hm ] = (object) array(
							'hm' => $hm,
							'c'  => 0,
						);
					}
					$out[ $hm ]->c++;
				}
			}
			return array_values( $out );
		}

		if ( preg_match( '/FROM wp_hsb_appointments WHERE patient_user_id = (\d+)/', $sql, $m ) ) {
			$out = array();
			foreach ( $this->appointments as $row ) {
				if ( (int) $row['patient_user_id'] === (int) $m[1] ) {
					$out[] = (object) $row;
				}
			}
			return $out;
		}

		return array();
	}

	/**
	 * درج ردیف — با اعتبارسنجی یکتایی code و idempotency_key.
	 *
	 * @return bool
	 */
	public function insert( string $table, array $data, array $format = array() ) {
		$this->log[]      = 'INSERT INTO ' . $table . ' ' . wp_json_encode_test( $data );
		$this->last_error = '';

		if ( $this->consume_deadlock( 'INSERT INTO ' . $table ) ) {
			return false;
		}

		foreach ( $this->appointments as $row ) {
			if ( isset( $data['code'] ) && $row['code'] === $data['code'] ) {
				$this->last_error = "Duplicate entry '{$data['code']}' for key 'code'";
				return false;
			}
			if ( ! empty( $data['idempotency_key'] ) && $row['idempotency_key'] === $data['idempotency_key'] ) {
				$this->last_error = "Duplicate entry '{$data['idempotency_key']}' for key 'idempotency_key'";
				return false;
			}
		}

		$id                  = $this->next_appt_id++;
		$data['id']          = $id;
		$this->appointments[ $id ] = $data;
		$this->insert_id     = $id;
		$this->rows_affected = 1;
		return true;
	}

	/**
	 * شمارش نوبت‌های فعال یک بازه.
	 */
	private function count_active_slot( int $doctor_id, string $date, string $time ): int {
		$c = 0;
		foreach ( $this->appointments as $row ) {
			if ( (int) $row['doctor_id'] === $doctor_id
				&& $row['appointment_date'] === $date
				&& substr( (string) $row['start_time'], 0, 8 ) === substr( $time, 0, 8 )
				&& in_array( $row['status'], array( 'requested', 'confirmed' ), true )
			) {
				$c++;
			}
		}
		return $c;
	}

	/**
	 * مصرف خطای deadlock برنامه‌ریزی‌شده (برای یک پرس‌وجو).
	 */
	private function consume_deadlock( string $sql = "" ): bool {
		if ( $this->deadlock_only_on_lock && false === strpos( $sql, "FOR UPDATE" ) ) {
			return false;
		}
		if ( $this->deadlocks_left > 0 ) {
			$this->deadlocks_left--;
			$this->last_error = 'Deadlock found when trying to get lock; try restarting transaction';
			return true;
		}
		return false;
	}
}

/**
 * json ساده برای لاگ (جلوگیری از وابستگی به ext/json در لاگ — json در هستهٔ PHP 8 است).
 */
function wp_json_encode_test( $data ): string {
	return json_encode( $data, JSON_UNESCAPED_UNICODE );
}
