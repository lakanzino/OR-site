<?php
/**
 * Plugin Name:       HSB — نوبت‌دهی همیار جراحی
 * Plugin URI:        https://hamiarjarrahi.example/hsb
 * Description:       افزونهٔ مستقل نوبت‌دهی برای سایت فارسی «همیار جراحی»: برنامهٔ هفتگی پزشکان، ظرفیت هر بازه، رزرو امن با تراکنش و قفل ردیف، کد پیگیری غیرقابل‌حدس، تاریخ شمسی، راست‌به‌چپ و واکنش‌گرا. بدون وابستگی به ACF، درگاه پرداخت یا پیامک.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Tested up to:      6.8
 * Requires PHP:      8.1
 * Author:            تیم فنی همیار جراحی
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       hamyar-surgery-booking
 *
 * این افزونه کاملاً مستقل است؛ هیچ افزونهٔ موجود دیگری را بازنویسی یا جایگزین نمی‌کند.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // دسترسی مستقیم ممنوع.
}

define( 'HSB_VERSION', '1.0.0' );
define( 'HSB_SCHEMA_VERSION', '1.0.0' );
define( 'HSB_PLUGIN_FILE', __FILE__ );
define( 'HSB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'HSB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'HSB_BOOKING_HORIZON_DAYS', 14 ); // افق نمایش روزها در نسخهٔ ۱ (طبق نیازمندی).

require_once HSB_PLUGIN_DIR . 'includes/class-hsb-jalali.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-validator.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-settings.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-doctor.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-access.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-availability.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-booking.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-notifications.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-rest.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-shortcodes.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-admin.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-activator.php';
require_once HSB_PLUGIN_DIR . 'includes/class-hsb-plugin.php';

register_activation_hook( __FILE__, array( 'HSB_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'HSB_Activator', 'deactivate' ) );

HSB_Plugin::init();
