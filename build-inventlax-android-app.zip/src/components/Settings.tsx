import { useRef, useState } from "react";
import { INVENTIONS } from "../data";
import { fa } from "../data/meta";
import { hashPin, useApp } from "../lib/store";
import { APP_NAME, AUTHOR_EN, AUTHOR_FA, DISCLAIMER, MIT, PURPOSE, SOURCES, VERSION } from "../lib/texts";
import { Logo, Sheet } from "./ui";

function Row({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <div className="font-black">{title}</div>
        {sub && <div className="text-xs text-[var(--muted)] font-semibold">{sub}</div>}
      </div>
      {children}
    </div>
  );
}

export function Settings({ onLock }: { onLock: () => void }) {
  const { data, setSettings, exportJson, importJson, clearAll, toast } = useApp();
  const s = data.settings;
  const [about, setAbout] = useState(false);
  const [lic, setLic] = useState(false);
  const [pinSheet, setPinSheet] = useState(false);
  const [pin, setPin] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const doExport = () => {
    const blob = new Blob([exportJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `inventlax-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    toast("نسخهٔ پشتیبان ذخیره شد 💾");
  };
  const doImport = async (file?: File) => {
    if (!file) return;
    const txt = await file.text();
    toast(importJson(txt) ? "بازیابی با موفقیت انجام شد ✅" : "فایل نامعتبر است ❌");
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <div className="max-w-2xl mx-auto px-4 pb-10 safe-t">
      <div className="pt-6 pb-4"><h1 className="text-3xl font-black">⚙️ <span className="title-grad">تنظیمات</span></h1></div>

      <section className="card3d px-5 py-2 divide-y divide-[var(--line)]">
        <Row title="تم برنامه" sub="تیره (سرمه‌ای) یا روشن">
          <div className="flex gap-1 p-1 rounded-2xl bg-[var(--soft)] border border-[var(--line)]" role="radiogroup" aria-label="تم">
            {([["dark", "🌙 تیره"], ["light", "☀️ روشن"]] as const).map(([k, l]) => (
              <button key={k} role="radio" aria-checked={s.theme === k} onClick={() => setSettings({ theme: k })} className={`min-h-11 px-4 rounded-xl font-black text-sm ${s.theme === k ? "bg-[var(--green)] text-[var(--on-accent)] shadow-lg" : ""}`}>{l}</button>
            ))}
          </div>
        </Row>
        <Row title="اندازهٔ متن" sub="برای خوانایی بهتر">
          <div className="flex gap-1 p-1 rounded-2xl bg-[var(--soft)] border border-[var(--line)]">
            {([0, 1, 2] as const).map((k) => (
              <button key={k} aria-label={`اندازه ${k + 1}`} aria-pressed={s.fontScale === k} onClick={() => setSettings({ fontScale: k })} className={`h-11 w-11 rounded-xl font-black ${s.fontScale === k ? "bg-[var(--yellow)] text-[#1b1300] shadow-lg" : ""}`} style={{ fontSize: 13 + k * 3 }}>آ</button>
            ))}
          </div>
        </Row>
        <Row title="قفل برنامه (اختیاری)" sub={s.pin ? "فعال — رمز عددی" : "غیرفعال"}>
          <div className="flex gap-2">
            {s.pin && <button className="chip" onClick={onLock}>🔒 قفل کن</button>}
            <button className="chip" onClick={() => { setPin(""); setPinSheet(true); }}>{s.pin ? "تغییر/حذف" : "تنظیم"}</button>
          </div>
        </Row>
      </section>

      <h2 className="font-black text-lg mt-6 mb-2">پشتیبان‌گیری از پیشرفت</h2>
      <section className="card3d p-5">
        <p className="text-sm text-[var(--muted)] font-semibold leading-7">علاقه‌مندی‌ها، آموخته‌ها و نتایج آزمون در یک فایل JSON ذخیره و بعداً بازیابی می‌شود. همه‌چیز روی دستگاه شما می‌ماند.</p>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button className="btn3d" onClick={doExport}>💾 ذخیره</button>
          <button className="btn3d ghost" onClick={() => fileRef.current?.click()}>📂 بازیابی</button>
          <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => doImport(e.target.files?.[0])} />
        </div>
      </section>

      <h2 className="font-black text-lg mt-6 mb-2">دربارهٔ برنامه</h2>
      <section className="card3d p-5 text-center overflow-hidden">
        <Logo size={96} className="mx-auto drop-shadow-[0_14px_12px_rgba(0,0,0,.45)]" />
        <div className="en text-2xl font-black title-grad mt-2" dir="ltr">{APP_NAME}</div>
        <div className="text-xs font-bold text-[var(--muted)]">نسخهٔ {fa(VERSION)} · {fa(INVENTIONS.length)} اختراع</div>
        <p className="mt-4 font-bold leading-8">{PURPOSE}</p>
        <div className="mt-4 rounded-2xl bg-[var(--soft)] p-3 text-sm font-bold">
          طراحی و توسعه: <span className="text-[var(--yellow)]">{AUTHOR_FA}</span> (<span className="en" dir="ltr">{AUTHOR_EN}</span>)
        </div>
        <div className="flex flex-wrap justify-center gap-2 mt-4">
          <button className="chip" onClick={() => setAbout(true)}>📚 منابع و سلب مسئولیت</button>
          <button className="chip" onClick={() => setLic(true)}>📄 MIT License</button>
        </div>
        <p className="text-[11px] text-[var(--muted)] mt-4">© 2025–2026 mohamadreza.lak · MIT License · ۱۰۰٪ آفلاین، بدون ردیابی و بدون مجوز اضافه</p>
      </section>

      <h2 className="font-black text-lg mt-6 mb-2">داده‌ها</h2>
      <section className="card3d p-5">
        <button className="btn3d w-full" style={{ ["--c" as string]: "var(--red)" } as React.CSSProperties} onClick={() => setConfirmClear(true)}>🗑️ پاک‌کردن همهٔ داده‌های من</button>
      </section>

      <Sheet open={about} onClose={() => setAbout(false)} title="منابع و سلب مسئولیت">
        <div className="pb-4 leading-8">
          <div className="card3d p-4 text-sm font-bold">{DISCLAIMER}</div>
          <h3 className="font-black mt-4">منابع بررسی‌شده</h3>
          <ul className="list-disc ps-6 text-sm mt-1">{SOURCES.map((x) => <li key={x} className="en" dir="ltr" style={{ textAlign: "start" }}>{x}</li>)}</ul>
          <h3 className="font-black mt-4">نکتهٔ دقت</h3>
          <p className="text-sm text-[var(--muted)]">این مجموعه شامل اختراعات برجسته و مستند است، نه همهٔ پتنت‌های جهان. در بسیاری از اختراعات، سال و نسبت‌دادن به یک نفر میان مورخان محل اختلاف است و با واژهٔ «حدود» یا توضیح مشخص شده است. دین/باور تنها برای چند شخصیتِ دارای مستندات روشن آمده و در بقیه خالی است.</p>
        </div>
      </Sheet>

      <Sheet open={lic} onClose={() => setLic(false)} title="MIT License">
        <pre className="en whitespace-pre-wrap text-xs leading-6 pb-4" dir="ltr">{MIT}</pre>
      </Sheet>

      <Sheet
        open={pinSheet}
        onClose={() => setPinSheet(false)}
        title="قفل برنامه"
        footer={
          <div className="flex gap-3">
            {s.pin && <button className="btn3d ghost" onClick={() => { setSettings({ pin: null }); setPinSheet(false); toast("قفل حذف شد"); }}>حذف قفل</button>}
            <button className="btn3d flex-1" disabled={pin.length < 4} onClick={() => { setSettings({ pin: hashPin(pin) }); setPinSheet(false); toast("قفل فعال شد 🔒"); }}>ذخیره</button>
          </div>
        }
      >
        <p className="text-sm text-[var(--muted)] font-semibold">رمز ۴ تا ۶ رقمی انتخاب کنید. این رمز فقط روی همین دستگاه ذخیره می‌شود (قابل‌بازیابی نیست؛ در صورت فراموشی، داده‌های برنامه را پاک کنید).</p>
        <input inputMode="numeric" type="password" maxLength={6} dir="ltr" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="••••" aria-label="رمز" className="mt-4 w-full min-h-14 rounded-2xl text-center text-2xl tracking-[.6em] font-black bg-[var(--soft)] border border-[var(--line)]" />
      </Sheet>

      <Sheet open={confirmClear} onClose={() => setConfirmClear(false)} title="مطمئنید؟" footer={<div className="flex gap-3"><button className="btn3d ghost flex-1" onClick={() => setConfirmClear(false)}>انصراف</button><button className="btn3d flex-1" style={{ ["--c" as string]: "var(--red)" } as React.CSSProperties} onClick={() => { clearAll(); setConfirmClear(false); toast("همهٔ داده‌ها پاک شد"); }}>بله، پاک کن</button></div>}>
        <p className="font-bold leading-8">علاقه‌مندی‌ها، آموخته‌ها، نتایج آزمون، فیلترها و قفل برنامه پاک می‌شود. این کار قابل بازگشت نیست.</p>
      </Sheet>
    </div>
  );
}
