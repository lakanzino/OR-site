import { useMemo, useState, type CSSProperties } from "react";
import { CATS, ERAS, countryEn, fa, flagOf } from "../data/meta";
import { COUNTRIES, INVENTORS, TAGS } from "../data";
import { EMPTY_FILTERS, norm, type CountryMode, type Filters } from "../lib/filter";
import { useApp } from "../lib/store";
import { Sheet } from "./ui";

const col = (c: string) => ({ "--c": c }) as CSSProperties;

function Block({ title, emoji, on, onToggle, count, children }: { title: string; emoji: string; on: boolean; onToggle: () => void; count: number; children: React.ReactNode }) {
  return (
    <section className={`card3d p-4 mb-3 transition-opacity ${on ? "" : "opacity-60"}`}>
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-black text-lg flex items-center gap-2">
          <span>{emoji}</span>
          {title}
          {count > 0 && <span className="rounded-full bg-[var(--green)] text-[var(--on-accent)] text-xs px-2 py-0.5 font-black">{fa(count)}</span>}
        </h3>
        <button role="switch" aria-checked={on} aria-label={`فعال/غیرفعال: ${title}`} onClick={onToggle} className="switch" />
      </div>
      <div className={`mt-3 ${on ? "" : "pointer-events-none"}`}>{children}</div>
    </section>
  );
}

const toggleIn = (arr: string[], v: string) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

export function FilterSheet({ open, onClose, total }: { open: boolean; onClose: () => void; total: number }) {
  const { data, setFilters } = useApp();
  const f = data.filters;
  const [invQ, setInvQ] = useState("");
  const [showAllC, setShowAllC] = useState(false);
  const set = (p: Partial<Filters>) => setFilters((s) => ({ ...s, ...p }));

  const invList = useMemo(() => {
    const q = norm(invQ);
    const sel = INVENTORS.filter((i) => f.inventors.includes(i.key));
    const rest = INVENTORS.filter((i) => !f.inventors.includes(i.key) && (!q || norm(i.fa + " " + i.en).includes(q)));
    return [...sel, ...rest.slice(0, q ? 40 : 12)];
  }, [invQ, f.inventors]);

  const modes: [CountryMode, string][] = [["both", "هر دو"], ["invention", "کشور اختراع"], ["inventor", "کشور مخترع"]];
  const countries = showAllC ? COUNTRIES : COUNTRIES.slice(0, 14);

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="فیلتر پیشرفته"
      full
      footer={
        <div className="flex gap-3">
          <button className="btn3d ghost" onClick={() => setFilters({ ...EMPTY_FILTERS, q: f.q })}>بازنشانی</button>
          <button className="btn3d flex-1" onClick={onClose}>نمایش {fa(total)} اختراع</button>
        </div>
      }
    >
      <p className="text-sm text-[var(--muted)] mb-3">هر بخش را با کلید روشن/خاموش کنید؛ فقط بخش‌های روشنِ دارای انتخاب اعمال می‌شوند. نتیجه همان لحظه به‌روز می‌شود.</p>

      <Block title="کشور" emoji="🌍" on={f.countryOn} onToggle={() => set({ countryOn: !f.countryOn })} count={f.countries.length}>
        <div className="flex gap-2 mb-3" role="radiogroup" aria-label="نوع تطبیق کشور">
          {modes.map(([m, l]) => (
            <button key={m} role="radio" aria-checked={f.countryMode === m} aria-pressed={f.countryMode === m} className="chip flex-1 justify-center" style={col("var(--yellow)")} onClick={() => set({ countryMode: m })}>
              {l}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          {countries.map((c) => (
            <button key={c.name} className="chip" aria-pressed={f.countries.includes(c.name)} style={col("var(--green)")} onClick={() => set({ countries: toggleIn(f.countries, c.name) })} title={countryEn(c.name)}>
              {flagOf(c.name)} {c.name} <span className="opacity-70 text-xs">{fa(c.count)}</span>
            </button>
          ))}
          <button className="chip" onClick={() => setShowAllC(!showAllC)}>{showAllC ? "کمتر" : `+ ${fa(COUNTRIES.length - 14)} مورد دیگر`}</button>
        </div>
      </Block>

      <Block title="دوره و سال" emoji="⏳" on={f.eraOn} onToggle={() => set({ eraOn: !f.eraOn })} count={f.eras.length + (f.yearFrom || f.yearTo ? 1 : 0)}>
        <div className="flex flex-wrap gap-2">
          {ERAS.map((e) => (
            <button key={e.key} className="chip" aria-pressed={f.eras.includes(e.key)} style={col("var(--yellow)")} onClick={() => set({ eras: toggleIn(f.eras, e.key) })}>
              {e.emoji} {e.fa}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3 mt-3">
          {([["yearFrom", "از سال"], ["yearTo", "تا سال"]] as const).map(([k, l]) => (
            <label key={k} className="block">
              <span className="text-xs font-bold text-[var(--muted)]">{l} (منفی = پیش از میلاد)</span>
              <input inputMode="numeric" dir="ltr" placeholder={k === "yearFrom" ? "-3000" : "2025"} value={f[k]} onChange={(e) => set({ [k]: e.target.value.replace(/[^\d\-۰-۹]/g, "") })} className="mt-1 w-full min-h-12 rounded-xl px-3 bg-[var(--soft)] border border-[var(--line)] font-bold" />
            </label>
          ))}
        </div>
      </Block>

      <Block title="دسته / حوزه" emoji="🧩" on={f.catOn} onToggle={() => set({ catOn: !f.catOn })} count={f.cats.length}>
        <div className="flex flex-wrap gap-2">
          {CATS.map((c) => (
            <button key={c.key} className="chip" aria-pressed={f.cats.includes(c.key)} style={col(c.color)} onClick={() => set({ cats: toggleIn(f.cats, c.key) })}>
              {c.emoji} {c.fa}
            </button>
          ))}
        </div>
      </Block>

      <Block title="مخترع" emoji="🧑‍🔬" on={f.inventorOn} onToggle={() => set({ inventorOn: !f.inventorOn })} count={f.inventors.length}>
        <input value={invQ} onChange={(e) => setInvQ(e.target.value)} placeholder="جست‌وجوی نام مخترع…" className="w-full min-h-12 rounded-xl px-3 bg-[var(--soft)] border border-[var(--line)] font-bold mb-3" />
        <div className="flex flex-wrap gap-2">
          {invList.map((i) => (
            <button key={i.key} className="chip" aria-pressed={f.inventors.includes(i.key)} style={col("var(--red)")} onClick={() => set({ inventors: toggleIn(f.inventors, i.key) })}>
              {i.fa}
            </button>
          ))}
        </div>
        {!invQ && <p className="text-xs text-[var(--muted)] mt-2">برای دیدن همهٔ مخترعان ({fa(INVENTORS.length)} نفر) نام را جست‌وجو کنید.</p>}
      </Block>

      <Block title="برچسب‌ها" emoji="🏷️" on={f.tagOn} onToggle={() => set({ tagOn: !f.tagOn })} count={f.tags.length}>
        <div className="flex flex-wrap gap-2">
          {TAGS.map((t) => (
            <button key={t.name} className="chip" aria-pressed={f.tags.includes(t.name)} style={col("var(--navy)")} onClick={() => set({ tags: toggleIn(f.tags, t.name) })}>
              {t.name} <span className="opacity-70 text-xs">{fa(t.count)}</span>
            </button>
          ))}
        </div>
      </Block>

      <section className="card3d p-4 mb-3 flex flex-col gap-3">
        {([["favOnly", "فقط علاقه‌مندی‌ها ⭐"], ["unlearnedOnly", "فقط آموخته‌نشده‌ها 📘"]] as const).map(([k, l]) => (
          <div key={k} className="flex items-center justify-between">
            <span className="font-black">{l}</span>
            <button role="switch" aria-checked={f[k]} aria-label={l} onClick={() => set({ [k]: !f[k] })} className="switch" />
          </div>
        ))}
      </section>
    </Sheet>
  );
}
