import { INVENTIONS } from "../data";
import { fa } from "../data/meta";
import { useApp } from "../lib/store";

export function Learn({ setMode }: { setMode: (m: "flash" | "quiz") => void }) {
  const { learned, data } = useApp();
  const pct = Math.round((learned.size / INVENTIONS.length) * 100);
  return (
    <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
      <div className="pt-6 pb-4">
        <h1 className="text-3xl font-black">🎓 <span className="title-grad">یادگیری و سرگرمی</span></h1>
        <p className="text-[var(--muted)] font-semibold mt-1">با فلش‌کارت‌های سه‌بعدی یاد بگیر و با آزمون خودت را بسنج.</p>
      </div>

      <div className="card3d p-5 flex items-center gap-5">
        <div className="relative h-24 w-24 shrink-0 rounded-full grid place-items-center" style={{ background: `conic-gradient(var(--green) ${pct * 3.6}deg, var(--soft) 0)` }}>
          <div className="h-[76px] w-[76px] rounded-full grid place-items-center font-black text-xl" style={{ background: "var(--card-b)" }}>{fa(pct)}٪</div>
        </div>
        <div>
          <div className="font-black text-lg">پیشرفت یادگیری</div>
          <div className="text-sm text-[var(--muted)] font-bold">{fa(learned.size)} از {fa(INVENTIONS.length)} اختراع را یاد گرفته‌ای</div>
          <div className="text-sm text-[var(--muted)] font-bold mt-1">آزمون‌ها: {fa(data.quiz.played)}</div>
        </div>
      </div>

      <div className="grid gap-4 mt-5">
        <button onClick={() => setMode("flash")} className="card3d press p-6 text-start flex items-center gap-4 overflow-hidden" style={{ background: "linear-gradient(145deg,#15803d,#064e3b)", color: "#fff" }}>
          <span className="text-6xl floaty">🃏</span>
          <span>
            <span className="block text-2xl font-black">فلش‌کارت</span>
            <span className="text-sm font-semibold opacity-90">کارت را برگردان و پاسخ را ببین؛ بر اساس دسته، دوره یا کشور.</span>
          </span>
        </button>
        <button onClick={() => setMode("quiz")} className="card3d press p-6 text-start flex items-center gap-4 overflow-hidden" style={{ background: "linear-gradient(145deg,#b91c1c,#4c0519)", color: "#fff" }}>
          <span className="text-6xl floaty">🎯</span>
          <span>
            <span className="block text-2xl font-black">آزمون ۱۰ سؤالی</span>
            <span className="text-sm font-semibold opacity-90">مخترع، سال، کشور و حوزه را حدس بزن و رکورد بزن.</span>
          </span>
        </button>
      </div>
    </div>
  );
}
