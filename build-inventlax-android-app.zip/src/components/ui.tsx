import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import { CAT_MAP } from "../data/meta";

/** Makes the Android/browser back button close an overlay (sheet / detail). */
export function useBackClose(open: boolean, close: () => void) {
  const closeRef = useRef(close);
  closeRef.current = close;
  useEffect(() => {
    if (!open) return;
    history.pushState({ layer: true }, "");
    let popped = false;
    const onPop = () => {
      popped = true;
      closeRef.current();
    };
    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
      if (!popped && history.state?.layer) history.back();
    };
  }, [open]);
}

export function Logo({ size = 64, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 128 128" className={className} role="img" aria-label="Invent.Lax">
      <defs>
        <linearGradient id="lg-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1b3a9a" />
          <stop offset="1" stopColor="#060e2e" />
        </linearGradient>
        <radialGradient id="lg-bulb" cx="0.38" cy="0.3" r="0.8">
          <stop offset="0" stopColor="#fff6b0" />
          <stop offset="0.45" stopColor="#ffd23f" />
          <stop offset="1" stopColor="#e89a00" />
        </radialGradient>
        <linearGradient id="lg-gear" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5df0a0" />
          <stop offset="1" stopColor="#0f9d46" />
        </linearGradient>
        <linearGradient id="lg-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff7a86" />
          <stop offset="1" stopColor="#d4122b" />
        </linearGradient>
      </defs>
      <rect width="128" height="128" rx="30" fill="url(#lg-bg)" />
      <rect x="3" y="3" width="122" height="122" rx="27" fill="none" stroke="#fff" strokeOpacity=".18" strokeWidth="2" />
      {/* gear behind the bulb */}
      <g transform="translate(64 68)">
        <g className="spin-slow" style={{ transformOrigin: "0px 0px" }}>
          {Array.from({ length: 10 }).map((_, i) => (
            <rect key={i} x="-6" y="-50" width="12" height="16" rx="3" fill="url(#lg-gear)" transform={`rotate(${i * 36})`} />
          ))}
          <circle r="42" fill="url(#lg-gear)" />
          <circle r="34" fill="#0a1a4d" opacity=".92" />
        </g>
      </g>
      {/* bulb */}
      <path d="M64 24c-17 0-29 12-29 28 0 10 5 17 11 23 3 3 4 6 4 10h28c0-4 1-7 4-10 6-6 11-13 11-23 0-16-12-28-29-28z" fill="url(#lg-bulb)" stroke="#fff" strokeOpacity=".35" strokeWidth="1.5" />
      <ellipse cx="52" cy="42" rx="8" ry="12" fill="#fff" opacity=".55" transform="rotate(25 52 42)" />
      <rect x="49" y="88" width="30" height="7" rx="3.5" fill="url(#lg-red)" />
      <rect x="53" y="97" width="22" height="7" rx="3.5" fill="url(#lg-red)" />
      {/* spark filament */}
      <path d="M56 78l5-16-8-6 22 0-6 8 7 14" fill="none" stroke="#d4122b" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M100 22l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#ffd23f" />
    </svg>
  );
}

export function CatBadge({ cat, small }: { cat: string; small?: boolean }) {
  const c = CAT_MAP[cat];
  if (!c) return null;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-extrabold ${small ? "px-2 py-0.5 text-[11px]" : "px-3 py-1 text-xs"}`}
      style={{ background: `color-mix(in srgb, ${c.color} 22%, transparent)`, color: c.color, border: `1px solid color-mix(in srgb, ${c.color} 45%, transparent)` }}
    >
      <span aria-hidden>{c.emoji}</span>
      {c.fa}
    </span>
  );
}

export function Sheet({ open, onClose, title, children, footer, full }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; full?: boolean }) {
  useBackClose(open, onClose);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/60 fade-in" onClick={onClose} />
      <div className={`sheet-up relative w-full max-w-2xl card3d flex flex-col rounded-b-none ${full ? "h-[94dvh]" : "max-h-[88dvh]"}`} style={{ borderRadius: "1.75rem 1.75rem 0 0" }}>
        <div className="flex items-center justify-between px-5 pt-4 pb-3">
          <div className="mx-auto absolute top-2 inset-x-0 h-1.5 w-12 rounded-full bg-[var(--line)]" />
          <h2 className="text-xl font-black">{title}</h2>
          <button onClick={onClose} aria-label="بستن" className="h-11 w-11 rounded-full bg-[var(--soft)] text-xl font-bold">✕</button>
        </div>
        <div className="overflow-y-auto px-5 pb-4 flex-1 overscroll-contain">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-[var(--line)] safe-b">{footer}</div>}
      </div>
    </div>
  );
}

/** Subtle pointer-driven 3D tilt (desktop); touch devices skip it for performance. */
export function Tilt({ children, className = "", style, max = 10 }: { children: ReactNode; className?: string; style?: CSSProperties; max?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const onMove = (e: React.PointerEvent) => {
    if (e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `perspective(900px) rotateY(${x * max}deg) rotateX(${-y * max}deg)`;
  };
  const reset = () => { if (ref.current) ref.current.style.transform = ""; };
  return (
    <div ref={ref} onPointerMove={onMove} onPointerLeave={reset} className={className} style={{ transition: "transform .25s ease-out", ...style }}>
      {children}
    </div>
  );
}

export function SectionTitle({ children, extra }: { children: ReactNode; extra?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 mb-3 mt-6">
      <h2 className="text-xl font-black">{children}</h2>
      {extra}
    </div>
  );
}

export function Empty({ emoji = "🕵️", text, action }: { emoji?: string; text: string; action?: ReactNode }) {
  return (
    <div className="text-center py-14 px-6">
      <div className="text-6xl floaty">{emoji}</div>
      <p className="mt-4 font-bold text-[var(--muted)]">{text}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
