import { memo } from "react";
import { CAT_MAP, flagOf, fmtYear, fmtYearShort } from "../data/meta";
import type { Invention } from "../data/types";
import { CatBadge } from "./ui";

interface Props {
  inv: Invention;
  onOpen: (id: string) => void;
  variant?: "grid" | "list";
  fav?: boolean;
  learned?: boolean;
  index?: number;
}

const who = (i: Invention) => (i.inventors.length ? i.inventors.map((v) => v.fa).slice(0, 2).join("، ") : "مخترع ناشناس / جمعی");

export const InventionCard = memo(function InventionCard({ inv, onOpen, variant = "grid", fav, learned, index = 0 }: Props) {
  const c = CAT_MAP[inv.cat];
  const delay = Math.min(index, 8) * 40;

  if (variant === "list") {
    return (
      <button
        onClick={() => onOpen(inv.id)}
        className="card3d press card-cv w-full text-start flex items-center gap-3 p-3 pop-in"
        style={{ animationDelay: `${delay}ms` }}
      >
        <div className="relative h-16 w-16 shrink-0 rounded-2xl grid place-items-center text-3xl" style={{ background: `linear-gradient(145deg, color-mix(in srgb, ${c.color} 55%, transparent), color-mix(in srgb, ${c.color} 12%, transparent))`, boxShadow: `inset 0 1px 0 rgba(255,255,255,.35), 0 6px 14px -6px ${c.color}` }}>
          <span style={{ filter: "drop-shadow(0 4px 4px rgba(0,0,0,.35))" }}>{inv.emoji}</span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-[11px] font-extrabold" style={{ color: c.color }}>
            <span>{fmtYear(inv.year, inv.approx)}</span>
          </div>
          <div className="font-black leading-tight truncate">{inv.fa}</div>
          <div className="en text-sm font-bold text-[var(--muted)] truncate text-start" dir="ltr" style={{ textAlign: "start" }}>{inv.en}</div>
          <div className="text-xs text-[var(--muted)] truncate mt-0.5">{flagOf(inv.country)} {inv.country} · {who(inv)}</div>
        </div>
        <div className="flex flex-col items-center gap-1 text-lg">
          {fav && <span aria-label="علاقه‌مندی">⭐</span>}
          {learned && <span aria-label="آموخته‌شده">✅</span>}
        </div>
      </button>
    );
  }

  return (
    <button
      onClick={() => onOpen(inv.id)}
      className="card3d press card-cv w-full text-start overflow-hidden pop-in flex flex-col"
      style={{ animationDelay: `${delay}ms`, minHeight: 210 }}
    >
      <div className="absolute inset-x-0 top-0 h-1.5" style={{ background: c.color, boxShadow: `0 0 16px ${c.color}` }} />
      <div className="absolute -top-8 -left-8 h-28 w-28 rounded-full opacity-40 blur-2xl" style={{ background: c.color }} />
      <div className="relative p-4 pb-3 flex-1 flex flex-col">
        <div className="flex items-start justify-between">
          <span className="rounded-full px-2.5 py-0.5 text-[11px] font-black" style={{ background: "var(--soft)", border: "1px solid var(--line)" }}>
            {fmtYearShort(inv.year)}
          </span>
          <div className="flex gap-1 text-sm">{fav && <span>⭐</span>}{learned && <span>✅</span>}</div>
        </div>
        <div className={`text-5xl text-center my-2 ${index < 6 ? "floaty" : ""}`} style={{ filter: "drop-shadow(0 10px 8px rgba(0,0,0,.4))", animationDelay: `${(index % 5) * 300}ms` }}>
          {inv.emoji}
        </div>
        <div className="font-black text-[17px] leading-tight text-center">{inv.fa}</div>
        <div className="en text-xs font-extrabold text-center text-[var(--muted)] mt-0.5 truncate" dir="ltr">{inv.en}</div>
        <div className="mt-auto pt-2 flex items-center justify-between gap-1 text-[11px] text-[var(--muted)] font-bold">
          <span className="truncate">{flagOf(inv.country)} {inv.country}</span>
          <CatBadge cat={inv.cat} small />
        </div>
      </div>
    </button>
  );
});
