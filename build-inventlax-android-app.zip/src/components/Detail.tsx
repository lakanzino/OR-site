import { useEffect, useMemo, useRef } from "react";
import { BY_ID, INVENTIONS } from "../data";
import { CAT_MAP, countryEn, eraOf, fa, flagOf, fmtYear } from "../data/meta";
import { useApp } from "../lib/store";
import { CatBadge, Tilt, useBackClose } from "./ui";

interface Props {
  id: string | null;
  list: string[];
  onClose: () => void;
  onNavigate: (id: string) => void;
  onPick: (patch: { country?: string; inventor?: string; cat?: string }) => void;
}

export function Detail({ id, list, onClose, onNavigate, onPick }: Props) {
  const { fav, learned, toggleFav, toggleLearned, toast } = useApp();
  const scroller = useRef<HTMLDivElement>(null);
  useBackClose(id !== null, onClose);
  const inv = id ? BY_ID[id] : null;

  const idx = id ? list.indexOf(id) : -1;
  const prev = idx > 0 ? list[idx - 1] : null;
  const next = idx >= 0 && idx < list.length - 1 ? list[idx + 1] : null;

  useEffect(() => { scroller.current?.scrollTo({ top: 0 }); }, [id]);

  const related = useMemo(() => {
    if (!inv) return [];
    return INVENTIONS.filter((x) => x.id !== inv.id && (x.cat === inv.cat || x.country === inv.country))
      .sort((a, b) => Math.abs(a.year - inv.year) - Math.abs(b.year - inv.year))
      .slice(0, 8);
  }, [inv]);

  const touch = useRef<number | null>(null);

  if (!inv) return null;
  const c = CAT_MAP[inv.cat];
  const era = eraOf(inv.year);

  const share = async () => {
    const text = `${inv.fa} (${inv.en}) — ${fmtYear(inv.year, inv.approx)}\n${inv.intro}\n\nInvent.Lax — طراحی و توسعه: محمدرضا لک`;
    try {
      if (navigator.share) await navigator.share({ title: `${inv.fa} | Invent.Lax`, text });
      else { await navigator.clipboard.writeText(text); toast("متن در کلیپ‌بورد کپی شد 📋"); }
    } catch { /* user cancelled */ }
  };

  const sections: [string, string, string][] = [
    ["💡", "چه کار می‌کند؟", inv.intro],
    ["🧰", "کاربرد و بیشترین استفاده", inv.uses],
    ["🌟", "تأثیر و اهمیت", inv.impact],
  ];

  return (
    <div
      className="fixed inset-0 z-[60] flex flex-col zoom-in"
      style={{ background: "var(--bg)" }}
      role="dialog"
      aria-modal="true"
      aria-label={inv.fa}
      onTouchStart={(e) => (touch.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touch.current === null) return;
        const dx = e.changedTouches[0].clientX - touch.current;
        touch.current = null;
        if (Math.abs(dx) > 90) { if (dx > 0 && next) onNavigate(next); else if (dx < 0 && prev) onNavigate(prev); }
      }}
    >
      <div ref={scroller} className="flex-1 overflow-y-auto overscroll-contain">
        <div className="relative overflow-hidden safe-t" style={{ background: `linear-gradient(160deg, color-mix(in srgb, ${c.color} 70%, #000) 0%, color-mix(in srgb, ${c.color} 25%, var(--bg)) 70%, var(--bg) 100%)` }}>
          <div className="absolute -top-24 -end-16 h-72 w-72 rounded-full blur-3xl opacity-50" style={{ background: c.color }} />
          <div className="absolute top-24 -start-10 text-[12rem] opacity-[.07] select-none leading-none" aria-hidden>{inv.emoji}</div>
          <div className="relative max-w-2xl mx-auto px-5 pt-4 pb-8">
            <div className="flex items-center justify-between">
              <button onClick={onClose} aria-label="بازگشت" className="h-12 w-12 rounded-2xl glass text-xl font-black">→</button>
              <div className="flex gap-2">
                <button onClick={() => prev && onNavigate(prev)} disabled={!prev} aria-label="قبلی" className="h-12 px-4 rounded-2xl glass font-black disabled:opacity-30">قبلی</button>
                <button onClick={() => next && onNavigate(next)} disabled={!next} aria-label="بعدی" className="h-12 px-4 rounded-2xl glass font-black disabled:opacity-30">بعدی</button>
              </div>
            </div>
            <Tilt className="mt-5 text-center" max={14}>
              <div className="text-[7rem] leading-none floaty" style={{ filter: "drop-shadow(0 22px 18px rgba(0,0,0,.5))", transform: "translateZ(40px)" }}>{inv.emoji}</div>
            </Tilt>
            <h1 className="text-3xl font-black text-center mt-3 text-white" style={{ textShadow: "0 2px 12px rgba(0,0,0,.4)" }}>{inv.fa}</h1>
            <div className="en text-xl font-extrabold text-center text-white/85 mt-1" dir="ltr">{inv.en}</div>
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
              <span className="rounded-full px-4 py-1.5 font-black text-sm bg-[var(--yellow)] text-[#1b1300] shadow-lg">📅 {fmtYear(inv.year, inv.approx)}</span>
              <CatBadge cat={inv.cat} />
              <span className="rounded-full px-3 py-1 text-xs font-extrabold bg-black/30 text-white">{era.emoji} {era.fa}</span>
            </div>
            <button onClick={() => onPick({ country: inv.country })} className="mt-3 mx-auto flex items-center gap-2 rounded-full px-4 py-1.5 bg-black/30 text-white text-sm font-bold">
              {flagOf(inv.country)} {inv.country} <span className="en opacity-70" dir="ltr">· {countryEn(inv.country)}</span>
            </button>
          </div>
        </div>

        <div className="max-w-2xl mx-auto px-5 -mt-4 relative pb-32">
          <div className="grid grid-cols-3 gap-3">
            <button onClick={() => toggleFav(inv.id)} aria-pressed={fav.has(inv.id)} className="btn3d ghost flex-col !min-h-[72px] !gap-0 text-sm" style={fav.has(inv.id) ? ({ color: "var(--yellow)" } as React.CSSProperties) : undefined}>
              <span className="text-2xl">{fav.has(inv.id) ? "⭐" : "☆"}</span>علاقه‌مندی
            </button>
            <button onClick={() => { toggleLearned(inv.id); toast(learned.has(inv.id) ? "از آموخته‌ها حذف شد" : "آفرین! به آموخته‌ها اضافه شد 🎉"); }} aria-pressed={learned.has(inv.id)} className="btn3d ghost flex-col !min-h-[72px] !gap-0 text-sm" style={learned.has(inv.id) ? ({ color: "var(--green)" } as React.CSSProperties) : undefined}>
              <span className="text-2xl">{learned.has(inv.id) ? "✅" : "📘"}</span>یاد گرفتم
            </button>
            <button onClick={share} className="btn3d ghost flex-col !min-h-[72px] !gap-0 text-sm"><span className="text-2xl">📤</span>اشتراک</button>
          </div>

          {sections.map(([e, t, body], k) => (
            <section key={t} className="card3d p-5 mt-4 pop-in" style={{ animationDelay: `${k * 70}ms` }}>
              <h2 className="font-black text-lg flex items-center gap-2" style={{ color: c.color }}><span className="text-2xl">{e}</span>{t}</h2>
              <p className="mt-2 leading-8 text-[1.02rem]">{body}</p>
            </section>
          ))}

          <h2 className="font-black text-xl mt-8 mb-3">🧑‍🔬 {inv.inventors.length > 1 ? "مخترعان" : "مخترع"}</h2>
          {inv.inventors.length === 0 && <div className="card3d p-5 text-[var(--muted)] font-bold">مخترع مشخصی ثبت نشده؛ این فناوری حاصل تلاش جمعی انسان‌های اولیه یا تمدن‌های باستانی بوده است.</div>}
          <div className="flex flex-col gap-3">
            {inv.inventors.map((v) => (
              <article key={v.en} className="card3d p-5">
                <div className="flex items-start gap-3">
                  <div className="h-14 w-14 shrink-0 rounded-2xl grid place-items-center text-3xl" style={{ background: `color-mix(in srgb, ${c.color} 25%, transparent)` }}>🧑‍🔬</div>
                  <div className="min-w-0">
                    <div className="font-black text-lg leading-tight">{v.fa}</div>
                    <div className="en font-bold text-[var(--muted)]" dir="ltr">{v.en}</div>
                  </div>
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div className="rounded-xl bg-[var(--soft)] p-2.5"><dt className="text-xs text-[var(--muted)] font-bold">محل تولد</dt><dd className="font-black">{v.born ?? "—"}</dd></div>
                  <button onClick={() => onPick({ inventor: v.en })} className="rounded-xl bg-[var(--soft)] p-2.5 text-start"><dt className="text-xs text-[var(--muted)] font-bold">کشور / ملیت</dt><dd className="font-black">{flagOf(v.country)} {v.country}</dd></button>
                </dl>
                <p className="mt-3 text-sm leading-7">{v.bio}</p>
                {v.religion && (
                  <p className="mt-3 text-xs rounded-xl p-2.5 bg-[var(--soft)] border border-[var(--line)]">
                    <b>دین/باور (مستند):</b> {v.religion}
                    <span className="block text-[var(--muted)] mt-0.5">درج بی‌طرفانه و فقط به‌دلیل مستندبودن در منابع معتبر.</span>
                  </p>
                )}
                <button onClick={() => onPick({ inventor: v.en })} className="chip mt-3" style={{ ["--c" as string]: c.color }}>🔎 همهٔ اختراعات این مخترع</button>
              </article>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {inv.tags.map((t) => <span key={t} className="chip !min-h-8 text-xs"># {t}</span>)}
          </div>
          <p className="mt-4 text-xs text-[var(--muted)] leading-6">
            منابع: Wikipedia «Timeline of historic inventions»، Britannica، مجموعه‌دادهٔ Timeline-of-historic-inventions و دایره‌المعارف‌های معتبر. تاریخ‌ها و نسبت‌دادن‌ها در برخی موارد مورد اختلاف مورخان است («حدود» = تقریبی).
          </p>

          {related.length > 0 && (
            <>
              <h2 className="font-black text-xl mt-8 mb-3">🔗 مرتبط‌ها</h2>
              <div className="flex gap-3 overflow-x-auto noscroll pb-3 -mx-5 px-5 snap-x">
                {related.map((r) => (
                  <button key={r.id} onClick={() => onNavigate(r.id)} className="card3d press snap-start shrink-0 w-36 p-3 text-center">
                    <div className="text-4xl">{r.emoji}</div>
                    <div className="font-black text-sm mt-1 leading-tight">{r.fa}</div>
                    <div className="text-[11px] text-[var(--muted)] font-bold">{fmtYear(r.year, r.approx)}</div>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="glass border-t px-4 py-3 safe-b flex items-center justify-between gap-3">
        <button className="btn3d ghost !min-h-12" disabled={!prev} onClick={() => prev && onNavigate(prev)}>→ قبلی</button>
        <span className="text-xs font-black text-[var(--muted)]">{idx >= 0 ? `${fa(idx + 1)} / ${fa(list.length)}` : ""}</span>
        <button className="btn3d !min-h-12" style={{ ["--c" as string]: c.color }} disabled={!next} onClick={() => next && onNavigate(next)}>بعدی ←</button>
      </div>
    </div>
  );
}
