import { useState } from "react";
import { INVENTIONS } from "../data";
import { CATS, fa } from "../data/meta";
import { useApp } from "../lib/store";
import { InventionCard } from "./InventionCard";
import { Empty } from "./ui";

export function Saved({ onOpen }: { onOpen: (id: string, list: string[]) => void }) {
  const { fav, learned } = useApp();
  const [tab, setTab] = useState<"fav" | "learned">("fav");
  const list = INVENTIONS.filter((i) => (tab === "fav" ? fav.has(i.id) : learned.has(i.id)));
  const ids = list.map((i) => i.id);

  return (
    <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
      <div className="pt-6 pb-4">
        <h1 className="text-3xl font-black">⭐ <span className="title-grad">مجموعهٔ من</span></h1>
      </div>
      <div className="flex gap-2 p-1 rounded-2xl bg-[var(--soft)] border border-[var(--line)]" role="tablist">
        {([["fav", `⭐ علاقه‌مندی (${fa(fav.size)})`], ["learned", `✅ آموخته (${fa(learned.size)})`]] as const).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`flex-1 min-h-11 rounded-xl font-black text-sm transition-all ${tab === k ? "bg-[var(--green)] text-[var(--on-accent)] shadow-lg" : ""}`}>{l}</button>
        ))}
      </div>

      {tab === "learned" && (
        <div className="card3d p-4 mt-4">
          <h2 className="font-black mb-3">پیشرفت به تفکیک حوزه</h2>
          <div className="flex flex-col gap-2">
            {CATS.map((c) => {
              const tot = INVENTIONS.filter((i) => i.cat === c.key);
              const done = tot.filter((i) => learned.has(i.id)).length;
              return (
                <div key={c.key} className="flex items-center gap-3 text-sm font-bold">
                  <span className="w-32 shrink-0 truncate">{c.emoji} {c.fa}</span>
                  <div className="flex-1 h-3 rounded-full bg-[var(--soft)] overflow-hidden"><div className="h-full rounded-full transition-all" style={{ width: `${(done / tot.length) * 100}%`, background: c.color }} /></div>
                  <span className="w-12 text-end text-xs text-[var(--muted)]">{fa(done)}/{fa(tot.length)}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-4">
        {list.length === 0 ? (
          <Empty emoji={tab === "fav" ? "⭐" : "📘"} text={tab === "fav" ? "هنوز چیزی را به علاقه‌مندی‌ها اضافه نکرده‌ای. در صفحهٔ هر اختراع ☆ را بزن." : "هنوز اختراعی را «یاد گرفتم» نکرده‌ای. با فلش‌کارت شروع کن!"} />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {list.map((r, i) => <InventionCard key={r.id} inv={r} onOpen={(id) => onOpen(id, ids)} fav={fav.has(r.id)} learned={learned.has(r.id)} index={i} />)}
          </div>
        )}
      </div>
    </div>
  );
}
