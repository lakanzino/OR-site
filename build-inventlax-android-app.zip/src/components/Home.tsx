import { useDeferredValue, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { COUNTRIES, INVENTIONS } from "../data";
import { CATS, CAT_MAP, ERAS, fa } from "../data/meta";
import { EMPTY_FILTERS, activeDims, applyFilters } from "../lib/filter";
import { useApp } from "../lib/store";
import { FilterSheet } from "./FilterSheet";
import { InventionCard } from "./InventionCard";
import { Timeline } from "./Timeline";
import { Empty, Logo, Sheet, Tilt } from "./ui";
import { INVENTORS } from "../data";

interface Props {
  onOpen: (id: string, list: string[]) => void;
  go: (t: "tops" | "saved", ) => void;
  learn: (m: "flash" | "quiz") => void;
}

export function Home({ onOpen, go, learn }: Props) {
  const { data, fav, learned, setFilters, setView } = useApp();
  const f = data.filters;
  const view = data.view;
  const [filterOpen, setFilterOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const deferredF = useDeferredValue(f);
  const heroRef = useRef<HTMLDivElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const results = useMemo(() => applyFilters(INVENTIONS, deferredF, fav, learned), [deferredF, fav, learned]);
  const ids = useMemo(() => results.map((r) => r.id), [results]);
  const dims = activeDims(f);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const y = Math.min(window.scrollY, 400);
        if (heroRef.current) heroRef.current.style.transform = `translate3d(0,${y * 0.25}px,0)`;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, []);

  const scrollToResults = () => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  const learnedPct = Math.round((learned.size / INVENTIONS.length) * 100);

  const chips: { key: string; label: string; remove: () => void }[] = [];
  if (f.countryOn) f.countries.forEach((c) => chips.push({ key: "c" + c, label: `🌍 ${c}`, remove: () => setFilters((s) => ({ ...s, countries: s.countries.filter((x) => x !== c) })) }));
  if (f.eraOn) {
    f.eras.forEach((e) => chips.push({ key: "e" + e, label: `${ERAS.find((x) => x.key === e)?.emoji} ${ERAS.find((x) => x.key === e)?.fa}`, remove: () => setFilters((s) => ({ ...s, eras: s.eras.filter((x) => x !== e) })) }));
    if (f.yearFrom || f.yearTo) chips.push({ key: "y", label: `📅 ${f.yearFrom || "…"} تا ${f.yearTo || "…"}`, remove: () => setFilters((s) => ({ ...s, yearFrom: "", yearTo: "" })) });
  }
  if (f.catOn) f.cats.forEach((c) => chips.push({ key: "k" + c, label: `${CAT_MAP[c].emoji} ${CAT_MAP[c].fa}`, remove: () => setFilters((s) => ({ ...s, cats: s.cats.filter((x) => x !== c) })) }));
  if (f.inventorOn) f.inventors.forEach((n) => chips.push({ key: "i" + n, label: `🧑‍🔬 ${INVENTORS.find((i) => i.key === n)?.fa ?? n}`, remove: () => setFilters((s) => ({ ...s, inventors: s.inventors.filter((x) => x !== n) })) }));
  if (f.tagOn) f.tags.forEach((t) => chips.push({ key: "t" + t, label: `# ${t}`, remove: () => setFilters((s) => ({ ...s, tags: s.tags.filter((x) => x !== t) })) }));
  if (f.favOnly) chips.push({ key: "fav", label: "⭐ علاقه‌مندی‌ها", remove: () => setFilters((s) => ({ ...s, favOnly: false })) });
  if (f.unlearnedOnly) chips.push({ key: "unl", label: "📘 آموخته‌نشده", remove: () => setFilters((s) => ({ ...s, unlearnedOnly: false })) });

  const tiles: [string, string, string, () => void][] = [
    ["⏳", "خط زمان", "var(--yellow)", () => { setView("timeline"); setTimeout(scrollToResults, 60); }],
    ["🧩", "دسته‌ها", "var(--green)", () => setCatOpen(true)],
    ["🏆", "ترین‌ها", "var(--red)", () => go("tops")],
    ["🎯", "آزمون", "var(--navy)", () => learn("quiz")],
    ["🃏", "فلش‌کارت", "var(--green)", () => learn("flash")],
    ["⭐", "علاقه‌مندی", "var(--yellow)", () => go("saved")],
  ];

  const stats: [string, string][] = [
    [fa(INVENTIONS.length), "اختراع"],
    [fa(COUNTRIES.length), "کشور/ناحیه"],
    [fa(INVENTORS.length), "مخترع"],
    [`${fa(learnedPct)}٪`, "یادگرفته‌ای"],
  ];

  return (
    <div>
      {/* 3D hero header */}
      <header className="relative overflow-hidden safe-t">
        <div className="absolute inset-0" style={{ background: "linear-gradient(160deg, #1d3fae 0%, #0a1a4d 55%, var(--bg) 100%)", opacity: data.settings.theme === "dark" ? 1 : 0.96 }} />
        <div className="absolute -top-10 -start-10 h-52 w-52 rounded-full blur-3xl opacity-50" style={{ background: "var(--green)" }} />
        <div className="absolute top-16 -end-12 h-44 w-44 rounded-full blur-3xl opacity-40" style={{ background: "var(--red)" }} />
        <div className="absolute bottom-0 start-1/3 h-36 w-36 rounded-full blur-3xl opacity-30" style={{ background: "var(--yellow)" }} />
        <div ref={heroRef} className="relative max-w-3xl mx-auto px-5 pt-6 pb-10 will-change-transform">
          <div className="flex items-center gap-4">
            <Tilt max={18}><Logo size={76} className="drop-shadow-[0_14px_14px_rgba(0,0,0,.5)]" /></Tilt>
            <div>
              <h1 className="en text-3xl font-black title-grad leading-tight" dir="ltr">Invent.Lax</h1>
              <p className="text-white/90 font-bold text-sm mt-0.5">از آتش تا هوش مصنوعی؛ اختراعات بشر</p>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-2 mt-5">
            {stats.map(([n, l], i) => (
              <div key={l} className="rounded-2xl py-2 text-center text-white" style={{ background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.18)", boxShadow: "0 6px 0 -3px rgba(0,0,0,.35)", transform: `translateY(${i % 2 ? 4 : 0}px)` }}>
                <div className="text-xl font-black leading-tight">{n}</div>
                <div className="text-[11px] font-bold opacity-80">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 -mt-5 relative">
        {/* Search */}
        <div className="card3d flex items-center gap-2 p-2 ps-4">
          <span className="text-xl" aria-hidden>🔍</span>
          <input
            type="search"
            value={f.q}
            onChange={(e) => setFilters((s) => ({ ...s, q: e.target.value }))}
            placeholder="جست‌وجو: اختراع، مخترع، کشور، سال…"
            aria-label="جست‌وجو"
            className="flex-1 min-h-12 bg-transparent outline-none font-bold placeholder:text-[var(--muted)] placeholder:font-semibold"
          />
          {f.q && <button onClick={() => setFilters((s) => ({ ...s, q: "" }))} aria-label="پاک‌کردن جست‌وجو" className="h-10 w-10 rounded-full bg-[var(--soft)] font-bold">✕</button>}
          <button onClick={() => setFilterOpen(true)} aria-label="فیلتر پیشرفته" className="btn3d !min-h-12 !px-4 relative" style={{ ["--c" as string]: "var(--yellow)" } as CSSProperties}>
            ⚙️ فیلتر
            {dims.length > 0 && <span className="absolute -top-2 -start-2 h-6 min-w-6 px-1 rounded-full bg-[var(--red)] text-white text-xs grid place-items-center font-black">{fa(dims.length)}</span>}
          </button>
        </div>

        {/* quick access */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 mt-5">
          {tiles.map(([e, l, c, fn]) => (
            <button key={l} onClick={fn} className="card3d press py-3 flex flex-col items-center gap-1" style={{ boxShadow: `inset 0 1px 0 var(--hi), 0 5px 0 -1px color-mix(in srgb, ${c} 55%, var(--edge)), 0 16px 24px -12px var(--shadow)` }}>
              <span className="text-3xl" style={{ filter: "drop-shadow(0 4px 3px rgba(0,0,0,.35))" }}>{e}</span>
              <span className="font-black text-[13px]">{l}</span>
            </button>
          ))}
        </div>

        {/* Era strip = horizontal timeline preview */}
        <h2 className="text-lg font-black mt-6 mb-2">⏱️ سفر در زمان</h2>
        <div className="flex gap-2 overflow-x-auto noscroll pb-2 -mx-4 px-4 snap-x relative">
          {ERAS.map((e, i) => {
            const n = INVENTIONS.filter((x) => x.year >= e.from && x.year < e.to).length;
            const on = f.eras.includes(e.key);
            const colr = ["var(--yellow)", "var(--green)", "var(--red)", "var(--navy)"][i % 4];
            return (
              <button key={e.key} aria-pressed={on} onClick={() => setFilters((s) => ({ ...s, eraOn: true, eras: on ? s.eras.filter((x) => x !== e.key) : [...s.eras, e.key] }))}
                className="chip snap-start !min-h-14 !rounded-2xl flex-col !gap-0 !px-4" style={{ ["--c" as string]: colr } as CSSProperties}>
                <span className="text-xl">{e.emoji}</span>
                <span className="text-[12px] font-black">{e.fa.split("،")[0]}</span>
                <span className="text-[10px] opacity-70">{fa(n)} اختراع</span>
              </button>
            );
          })}
        </div>

        {/* toolbar */}
        <div ref={resultsRef} className="scroll-mt-4 flex items-center justify-between gap-2 mt-4">
          <div className="font-black">{fa(results.length)} <span className="text-[var(--muted)] font-bold">اختراع{dims.length || f.q ? " (فیلترشده)" : ""}</span></div>
          <div className="flex gap-1 p-1 rounded-2xl bg-[var(--soft)] border border-[var(--line)]" role="tablist" aria-label="نوع نمایش">
            {([["grid", "▦", "شبکه‌ای"], ["list", "☰", "فهرست"], ["timeline", "⏳", "خط زمان"]] as const).map(([v, ic, l]) => (
              <button key={v} role="tab" aria-selected={view === v} aria-label={l} onClick={() => setView(v)} className={`h-10 px-3 rounded-xl font-black text-sm transition-all ${view === v ? "bg-[var(--green)] text-[var(--on-accent)] shadow-lg" : ""}`}>
                {ic}<span className="hidden sm:inline ms-1">{l}</span>
              </button>
            ))}
          </div>
        </div>

        {(chips.length > 0 || f.q) && (
          <div className="flex gap-2 overflow-x-auto noscroll py-3 -mx-4 px-4">
            {chips.map((c) => (
              <button key={c.key} onClick={c.remove} className="chip" aria-pressed style={{ ["--c" as string]: "var(--navy)" } as CSSProperties} aria-label={`حذف فیلتر ${c.label}`}>
                {c.label} <span aria-hidden>✕</span>
              </button>
            ))}
            <button onClick={() => setFilters(EMPTY_FILTERS)} className="chip" style={{ color: "var(--red)" }}>پاک‌کردن همه</button>
          </div>
        )}

        <div className="mt-3 pb-8">
          {results.length === 0 ? (
            <Empty text="اختراعی با این فیلترها پیدا نشد. یکی از فیلترها را خاموش کنید یا بازنشانی کنید." action={<button className="btn3d" onClick={() => setFilters(EMPTY_FILTERS)}>بازنشانی فیلترها</button>} />
          ) : view === "timeline" ? (
            <Timeline items={results} onOpen={(id) => onOpen(id, ids)} fav={fav} learned={learned} />
          ) : view === "list" ? (
            <div className="flex flex-col gap-3">
              {results.map((r, i) => <InventionCard key={r.id} inv={r} variant="list" onOpen={(id) => onOpen(id, ids)} fav={fav.has(r.id)} learned={learned.has(r.id)} index={i} />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {results.map((r, i) => <InventionCard key={r.id} inv={r} onOpen={(id) => onOpen(id, ids)} fav={fav.has(r.id)} learned={learned.has(r.id)} index={i} />)}
            </div>
          )}
        </div>
      </div>

      <FilterSheet open={filterOpen} onClose={() => setFilterOpen(false)} total={results.length} />
      <Sheet open={catOpen} onClose={() => setCatOpen(false)} title="دسته‌ها">
        <div className="grid grid-cols-2 gap-3 pb-4">
          {CATS.map((c) => {
            const n = INVENTIONS.filter((i) => i.cat === c.key).length;
            return (
              <button key={c.key} className="card3d press p-4 text-start" style={{ borderColor: c.color }} onClick={() => { setFilters({ ...EMPTY_FILTERS, cats: [c.key] }); setCatOpen(false); setView("grid"); setTimeout(scrollToResults, 120); }}>
                <div className="text-4xl">{c.emoji}</div>
                <div className="font-black mt-1" style={{ color: c.color }}>{c.fa}</div>
                <div className="text-xs text-[var(--muted)] font-bold en" dir="ltr">{c.en} · {n}</div>
              </button>
            );
          })}
        </div>
      </Sheet>
    </div>
  );
}
