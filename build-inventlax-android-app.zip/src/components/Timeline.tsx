import { memo, useMemo } from "react";
import { CAT_MAP, ERAS, flagOf, fmtYear } from "../data/meta";
import type { Invention } from "../data/types";

export const Timeline = memo(function Timeline({ items, onOpen, fav, learned }: { items: Invention[]; onOpen: (id: string) => void; fav: Set<string>; learned: Set<string> }) {
  const groups = useMemo(
    () => ERAS.map((e) => ({ era: e, list: items.filter((i) => i.year >= e.from && i.year < e.to) })).filter((g) => g.list.length),
    [items]
  );
  return (
    <div className="relative pe-1">
      {groups.map((g) => (
        <section key={g.era.key} id={`era-${g.era.key}`} className="mb-6 scroll-mt-24">
          <div className="sticky top-0 z-10 py-2">
            <div className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 font-black shadow-lg">
              <span className="text-xl">{g.era.emoji}</span>
              {g.era.fa}
              <span className="text-xs text-[var(--muted)] en">{g.era.en}</span>
            </div>
          </div>
          <ol className="relative mt-2 ms-0 border-s-0 pe-0">
            <div className="absolute top-0 bottom-0 start-[15px] w-1 rounded-full" style={{ background: "linear-gradient(180deg,var(--green),var(--yellow),var(--red))", opacity: 0.55 }} />
            {g.list.map((i) => {
              const c = CAT_MAP[i.cat];
              return (
                <li key={i.id} className="relative ps-10 mb-3 content-auto">
                  <span className="absolute start-[6px] top-5 h-5 w-5 rounded-full border-4" style={{ background: c.color, borderColor: "var(--bg)", boxShadow: `0 0 12px ${c.color}` }} />
                  <button onClick={() => onOpen(i.id)} className="card3d press w-full text-start p-3 flex items-center gap-3">
                    <span className="text-3xl shrink-0" style={{ filter: "drop-shadow(0 4px 3px rgba(0,0,0,.4))" }}>{i.emoji}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[11px] font-black" style={{ color: c.color }}>{fmtYear(i.year, i.approx)}</span>
                      <span className="block font-black leading-tight">{i.fa} {fav.has(i.id) && "⭐"}{learned.has(i.id) && " ✅"}</span>
                      <span className="block en text-xs font-bold text-[var(--muted)]" dir="ltr">{i.en}</span>
                      <span className="block text-xs text-[var(--muted)]">{flagOf(i.country)} {i.country}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </section>
      ))}
    </div>
  );
});
