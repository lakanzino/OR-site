import { useMemo, useState, type CSSProperties } from "react";
import { COUNTRIES, INVENTIONS } from "../data";
import { CATS, CAT_MAP, ERAS, countryEn, fa, flagOf, fmtYear } from "../data/meta";
import type { Invention } from "../data/types";
import { useApp } from "../lib/store";
import { CatBadge } from "./ui";

type Deck = { kind: "all" | "unlearned" | "fav" | "cat" | "country" | "era"; value?: string };

function shuffle<T>(a: T[]): T[] {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}

export function Flashcards({ onExit }: { onExit: () => void }) {
  const { fav, learned, toggleLearned, toggleFav, toast } = useApp();
  const [deck, setDeck] = useState<Invention[] | null>(null);
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState(0);

  const start = (d: Deck) => {
    let list = INVENTIONS;
    if (d.kind === "unlearned") list = list.filter((x) => !learned.has(x.id));
    if (d.kind === "fav") list = list.filter((x) => fav.has(x.id));
    if (d.kind === "cat") list = list.filter((x) => x.cat === d.value);
    if (d.kind === "country") list = list.filter((x) => x.country === d.value || x.inventors.some((v) => v.country === d.value));
    if (d.kind === "era") { const e = ERAS.find((x) => x.key === d.value)!; list = list.filter((x) => x.year >= e.from && x.year < e.to); }
    if (!list.length) { toast("این دسته خالی است"); return; }
    setDeck(shuffle(list).slice(0, 40));
    setI(0); setFlipped(false); setKnown(0);
  };

  const counts = useMemo(() => ({ unl: INVENTIONS.filter((x) => !learned.has(x.id)).length, fav: fav.size }), [learned, fav]);

  if (!deck) {
    return (
      <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
        <div className="flex items-center gap-3 pt-6">
          <button onClick={onExit} className="h-12 w-12 rounded-2xl card3d text-xl font-black" aria-label="بازگشت">→</button>
          <h1 className="text-2xl font-black">🃏 فلش‌کارت</h1>
        </div>
        <p className="text-[var(--muted)] font-semibold mt-3">دسته‌ای را انتخاب کنید؛ هر بار تا ۴۰ کارت به‌صورت تصادفی می‌آید.</p>
        <div className="grid grid-cols-3 gap-3 mt-4">
          {([["🎲", "همه", { kind: "all" }], ["📘", `آموخته‌نشده (${fa(counts.unl)})`, { kind: "unlearned" }], ["⭐", `علاقه‌مندی (${fa(counts.fav)})`, { kind: "fav" }]] as [string, string, Deck][]).map(([e, l, d]) => (
            <button key={l} className="card3d press py-4 text-center font-black text-sm" onClick={() => start(d)}><div className="text-3xl">{e}</div>{l}</button>
          ))}
        </div>
        <h2 className="font-black text-lg mt-6 mb-2">بر اساس دسته</h2>
        <div className="flex flex-wrap gap-2">
          {CATS.map((c) => <button key={c.key} className="chip" style={{ ["--c" as string]: c.color } as CSSProperties} onClick={() => start({ kind: "cat", value: c.key })}>{c.emoji} {c.fa}</button>)}
        </div>
        <h2 className="font-black text-lg mt-6 mb-2">بر اساس دوره</h2>
        <div className="flex flex-wrap gap-2">
          {ERAS.map((e) => <button key={e.key} className="chip" onClick={() => start({ kind: "era", value: e.key })}>{e.emoji} {e.fa}</button>)}
        </div>
        <h2 className="font-black text-lg mt-6 mb-2">بر اساس کشور</h2>
        <div className="flex flex-wrap gap-2">
          {COUNTRIES.filter((c) => c.count >= 2).map((c) => <button key={c.name} className="chip" title={countryEn(c.name)} onClick={() => start({ kind: "country", value: c.name })}>{flagOf(c.name)} {c.name}</button>)}
        </div>
      </div>
    );
  }

  const done = i >= deck.length;
  if (done) {
    return (
      <div className="max-w-md mx-auto px-4 pt-16 text-center safe-t">
        <div className="text-8xl floaty">🎉</div>
        <h1 className="text-3xl font-black mt-4">آفرین!</h1>
        <p className="mt-2 font-bold text-[var(--muted)]">{fa(known)} کارت از {fa(deck.length)} را یاد گرفتی.</p>
        <div className="flex gap-3 mt-8 justify-center">
          <button className="btn3d ghost" onClick={() => setDeck(null)}>دسته‌های دیگر</button>
          <button className="btn3d" onClick={() => { setDeck(shuffle(deck)); setI(0); setFlipped(false); setKnown(0); }}>دوباره</button>
        </div>
      </div>
    );
  }

  const inv = deck[i];
  const c = CAT_MAP[inv.cat];
  const go = (d: number) => { setFlipped(false); setTimeout(() => setI((x) => Math.max(0, x + d)), flipped ? 200 : 0); };

  return (
    <div className="max-w-md mx-auto px-4 pb-8 safe-t flex flex-col" style={{ minHeight: "calc(100dvh - 80px)" }}>
      <div className="flex items-center gap-3 pt-5">
        <button onClick={() => setDeck(null)} className="h-12 w-12 rounded-2xl card3d text-xl font-black" aria-label="خروج">✕</button>
        <div className="flex-1">
          <div className="h-3 rounded-full bg-[var(--soft)] overflow-hidden"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${(i / deck.length) * 100}%`, background: "linear-gradient(90deg,var(--green),var(--yellow))" }} /></div>
          <div className="text-xs font-black text-[var(--muted)] mt-1">{fa(i + 1)} از {fa(deck.length)}</div>
        </div>
        <button onClick={() => toggleFav(inv.id)} className="h-12 w-12 rounded-2xl card3d text-xl" aria-label="علاقه‌مندی" aria-pressed={fav.has(inv.id)}>{fav.has(inv.id) ? "⭐" : "☆"}</button>
      </div>

      <div className="scene flex-1 my-5" style={{ minHeight: 430 }}>
        <div className={`flip ${flipped ? "on" : ""}`} onClick={() => setFlipped((v) => !v)} role="button" tabIndex={0} aria-label="برگرداندن کارت" onKeyDown={(e) => (e.key === " " || e.key === "Enter") && setFlipped((v) => !v)}>
          <div className="face card3d overflow-hidden grid place-items-center text-center p-6" style={{ background: `linear-gradient(160deg, color-mix(in srgb, ${c.color} 55%, var(--card-a)), var(--card-b))` }}>
            <div>
              <div className="inline-block rounded-full px-4 py-1 bg-[var(--yellow)] text-[#1b1300] font-black text-sm shadow-lg">📅 {fmtYear(inv.year, inv.approx)}</div>
              <div className="text-[8rem] leading-none my-4 floaty" style={{ filter: "drop-shadow(0 20px 14px rgba(0,0,0,.45))" }}>{inv.emoji}</div>
              <h2 className="text-3xl font-black">{inv.fa}</h2>
              <div className="en text-xl font-extrabold text-[var(--muted)] mt-1" dir="ltr">{inv.en}</div>
              <div className="mt-3 font-bold">{flagOf(inv.country)} {inv.country}</div>
              <div className="mt-3"><CatBadge cat={inv.cat} /></div>
              <p className="mt-6 text-xs font-bold text-[var(--muted)]">برای دیدن پاسخ ضربه بزنید 👆</p>
            </div>
          </div>
          <div className="face back card3d overflow-hidden flex flex-col" style={{ background: `linear-gradient(160deg, var(--card-a), color-mix(in srgb, ${c.color} 30%, var(--card-b)))` }}>
            <div className="p-5 overflow-y-auto flex-1 text-start">
              <div className="flex items-center gap-2"><span className="text-3xl">{inv.emoji}</span><b className="text-lg">{inv.fa}</b></div>
              <div className="mt-3 rounded-xl bg-[var(--soft)] p-3 text-sm">
                <b>🧑‍🔬 مخترع: </b>
                {inv.inventors.length ? inv.inventors.map((v) => `${v.fa}${v.born ? ` (${v.born})` : ""}`).join("، ") : "ناشناس / جمعی"}
              </div>
              <p className="mt-3 text-sm leading-7"><b style={{ color: c.color }}>💡 چه کار می‌کند؟</b><br />{inv.intro}</p>
              <p className="mt-3 text-sm leading-7"><b style={{ color: c.color }}>🧰 کاربرد:</b><br />{inv.uses}</p>
              <p className="mt-3 text-sm leading-7"><b style={{ color: c.color }}>🌟 اهمیت:</b><br />{inv.impact}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <button className="btn3d ghost" disabled={i === 0} onClick={() => go(-1)}>→ قبلی</button>
        <button className="btn3d" style={{ ["--c" as string]: "var(--red)" } as CSSProperties} onClick={() => go(1)}>مرور بعدی</button>
        <button className="btn3d" onClick={() => { if (!learned.has(inv.id)) toggleLearned(inv.id); setKnown((k) => k + 1); go(1); }}>✅ بلدم</button>
      </div>
    </div>
  );
}

