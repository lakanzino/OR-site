import { useState } from "react";
import { hashPin, useApp } from "../lib/store";
import { DISCLAIMER, PURPOSE, AUTHOR_FA, AUTHOR_EN } from "../lib/texts";
import { Logo } from "./ui";

export function Onboarding() {
  const { setSettings } = useApp();
  const [step, setStep] = useState(0);
  const slides = [
    { e: null, t: "به Invent.Lax خوش آمدی!", b: PURPOSE, s: "از سنگ و آتش تا هوش مصنوعی؛ داستان اختراعاتی که دنیا را ساختند." },
    { e: "🧭", t: "کاوش کن، فیلتر کن، یاد بگیر", b: "فیلتر قدرتمند بر اساس کشور، سال، دسته و مخترع؛ خط زمان؛ «ترین‌ها»؛ فلش‌کارت سه‌بعدی و آزمون.", s: "همه‌چیز کاملاً آفلاین است و هیچ اطلاعاتی از دستگاه شما خارج نمی‌شود." },
    { e: "📚", t: "دقت و بی‌طرفی", b: DISCLAIMER, s: `طراحی و توسعه: ${AUTHOR_FA} (${AUTHOR_EN})` },
  ];
  const sl = slides[step];
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 text-center" style={{ background: "var(--bg)" }}>
      <div className="absolute inset-0 -z-10" style={{ background: "radial-gradient(40rem 30rem at 50% 0%, color-mix(in srgb, var(--navy) 40%, transparent), transparent)" }} />
      <div key={step} className="zoom-in max-w-md">
        {sl.e ? <div className="text-8xl floaty">{sl.e}</div> : <Logo size={140} className="mx-auto floaty drop-shadow-[0_20px_20px_rgba(0,0,0,.5)]" />}
        <h1 className="text-3xl font-black mt-6">{sl.t}</h1>
        <p className="mt-4 leading-9 font-bold">{sl.b}</p>
        <p className="mt-3 text-sm text-[var(--muted)] font-semibold leading-7">{sl.s}</p>
      </div>
      <div className="flex gap-2 mt-8">{slides.map((_, k) => <i key={k} className="h-2.5 rounded-full transition-all" style={{ width: k === step ? 28 : 10, background: k === step ? "var(--green)" : "var(--line)" }} />)}</div>
      <button className="btn3d mt-8 w-full max-w-xs" onClick={() => (step < slides.length - 1 ? setStep(step + 1) : setSettings({ onboarded: true }))}>
        {step < slides.length - 1 ? "ادامه ←" : "شروع کنیم 🚀"}
      </button>
    </div>
  );
}

export function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const { data } = useApp();
  const [pin, setPin] = useState("");
  const [bad, setBad] = useState(false);
  const submit = () => {
    if (hashPin(pin) === data.settings.pin) onUnlock();
    else { setBad(true); setPin(""); setTimeout(() => setBad(false), 400); }
  };
  return (
    <div className="fixed inset-0 z-[110] flex flex-col items-center justify-center p-6 text-center" style={{ background: "var(--bg)" }}>
      <Logo size={96} className="floaty" />
      <h1 className="text-2xl font-black mt-4">برنامه قفل است 🔒</h1>
      <input autoFocus inputMode="numeric" type="password" maxLength={6} dir="ltr" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} onKeyDown={(e) => e.key === "Enter" && submit()} aria-label="رمز" placeholder="••••" className={`mt-6 w-48 min-h-14 rounded-2xl text-center text-2xl tracking-[.6em] font-black bg-[var(--soft)] border border-[var(--line)] ${bad ? "shake" : ""}`} />
      <button className="btn3d mt-5 w-48" onClick={submit} disabled={pin.length < 4}>ورود</button>
      {bad && <p className="mt-3 font-bold text-[var(--red)]">رمز نادرست است</p>}
    </div>
  );
}
