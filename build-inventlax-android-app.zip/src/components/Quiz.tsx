import { useMemo, useState, type CSSProperties } from "react";
import { COUNTRIES, INVENTIONS } from "../data";
import { CATS, CAT_MAP, fa, fmtYear } from "../data/meta";
import type { Invention } from "../data/types";
import { useApp } from "../lib/store";

type Mode = "who" | "year" | "country" | "cat" | "mixed";
const MODES: { key: Mode; emoji: string; title: string; sub: string; color: string }[] = [
  { key: "who", emoji: "🧑‍🔬", title: "چه کسی اختراع کرد؟", sub: "مخترع را حدس بزن", color: "var(--red)" },
  { key: "year", emoji: "📅", title: "چه سالی؟", sub: "زمان اختراع", color: "var(--yellow)" },
  { key: "country", emoji: "🌍", title: "کدام کشور؟", sub: "جای اختراع", color: "var(--green)" },
  { key: "cat", emoji: "🧩", title: "کدام حوزه؟", sub: "دسته‌بندی", color: "var(--navy)" },
  { key: "mixed", emoji: "🎰", title: "ترکیبی", sub: "همه با هم", color: "var(--green)" },
];

interface Q { inv: Invention; text: string; options: string[]; answer: string; kind: Exclude<Mode, "mixed"> }

const pick = <T,>(a: T[], n: number): T[] => {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
  return r.slice(0, n);
};

function makeQ(kind: Exclude<Mode, "mixed">, used: Set<string>): Q | null {
  const pool = INVENTIONS.filter((i) => !used.has(i.id) && (kind === "who" ? i.inventors.length > 0 : kind === "country" ? i.country !== "نامشخص" : true));
  if (!pool.length) return null;
  const inv = pool[Math.floor(Math.random() * pool.length)];
  let answer = "";
  let wrong: string[] = [];
  let text = "";
  if (kind === "who") {
    answer = inv.inventors[0].fa;
    const names = [...new Set(INVENTIONS.flatMap((i) => i.inventors.map((v) => v.fa)))].filter((n) => n !== answer && !inv.inventors.some((v) => v.fa === n));
    wrong = pick(names, 3);
    text = `چه کسی «${inv.fa}» را اختراع کرد؟`;
  } else if (kind === "year") {
    answer = fmtYear(inv.year, inv.approx);
    const idx = INVENTIONS.indexOf(inv);
    const near = INVENTIONS.slice(Math.max(0, idx - 14), idx + 15).filter((o) => o.id !== inv.id).map((o) => fmtYear(o.year, o.approx)).filter((l) => l !== answer);
    wrong = pick([...new Set(near)], 3);
    text = `«${inv.fa}» مربوط به چه زمانی است؟`;
  } else if (kind === "country") {
    answer = inv.country;
    wrong = pick(COUNTRIES.map((c) => c.name).filter((c) => c !== answer && c !== "نامشخص" && !inv.inventors.some((v) => v.country === c)), 3);
    text = `«${inv.fa}» در کدام کشور/ناحیه پدید آمد یا ثبت شد؟`;
  } else {
    answer = CAT_MAP[inv.cat].fa;
    wrong = pick(CATS.filter((c) => c.key !== inv.cat).map((c) => c.fa), 3);
    text = `«${inv.fa}» در کدام حوزه جای می‌گیرد؟`;
  }
  if (wrong.length < 3) return null;
  return { inv, text, answer, options: pick([answer, ...wrong], 4), kind };
}

function build(mode: Mode, n = 10): Q[] {
  const used = new Set<string>();
  const out: Q[] = [];
  const kinds: Exclude<Mode, "mixed">[] = ["who", "year", "country", "cat"];
  let guard = 0;
  while (out.length < n && guard++ < 200) {
    const k = mode === "mixed" ? kinds[Math.floor(Math.random() * 4)] : mode;
    const q = makeQ(k, used);
    if (q) { used.add(q.inv.id); out.push(q); }
  }
  return out;
}

export function Quiz({ onExit }: { onExit: () => void }) {
  const { data, addQuiz } = useApp();
  const [mode, setMode] = useState<Mode | null>(null);
  const [qs, setQs] = useState<Q[]>([]);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [finished, setFinished] = useState(false);

  const start = (m: Mode) => {
    setMode(m); setQs(build(m)); setI(0); setPicked(null); setScore(0); setStreak(0); setFinished(false);
  };

  const acc = data.quiz.total ? Math.round((data.quiz.correct / data.quiz.total) * 100) : 0;
  const confetti = useMemo(() => Array.from({ length: 28 }, (_, k) => ({ k, left: Math.random() * 100, d: 2 + Math.random() * 2.5, delay: Math.random() * 1.2, c: ["#22e07a", "#ffd23f", "#ff4d5e", "#6f8cff"][k % 4] })), [finished]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!mode) {
    return (
      <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
        <div className="flex items-center gap-3 pt-6">
          <button onClick={onExit} className="h-12 w-12 rounded-2xl card3d text-xl font-black" aria-label="بازگشت">→</button>
          <h1 className="text-2xl font-black">🎯 آزمون</h1>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4 text-center">
          {[[fa(data.quiz.played), "آزمون"], [`${fa(acc)}٪`, "درستی کل"], [fa(Math.max(0, ...Object.values(data.quiz.best), 0)), "بهترین (از ۱۰)"]].map(([n, l]) => (
            <div key={l} className="card3d py-3"><div className="text-2xl font-black">{n}</div><div className="text-xs font-bold text-[var(--muted)]">{l}</div></div>
          ))}
        </div>
        <div className="flex flex-col gap-3 mt-5">
          {MODES.map((m) => (
            <button key={m.key} onClick={() => start(m.key)} className="card3d press p-4 flex items-center gap-4 text-start" style={{ boxShadow: `inset 0 1px 0 var(--hi), 0 6px 0 -1px color-mix(in srgb, ${m.color} 60%, var(--edge)), 0 16px 24px -12px var(--shadow)` }}>
              <span className="text-4xl">{m.emoji}</span>
              <span className="flex-1"><span className="block font-black text-lg">{m.title}</span><span className="text-sm text-[var(--muted)] font-bold">{m.sub}</span></span>
              <span className="text-xs font-black rounded-full px-3 py-1 bg-[var(--soft)]">رکورد: {fa(data.quiz.best[m.key] ?? 0)}/۱۰</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (finished) {
    const stars = score >= 9 ? 3 : score >= 6 ? 2 : score >= 3 ? 1 : 0;
    return (
      <div className="max-w-md mx-auto px-4 pt-14 text-center safe-t relative">
        {score >= 6 && <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden>{confetti.map((c) => <i key={c.k} className="absolute top-0 h-3 w-2 rounded-sm" style={{ left: `${c.left}%`, background: c.c, animation: `confetti ${c.d}s ${c.delay}s linear forwards` }} />)}</div>}
        <div className="relative z-10">
          <div className="text-7xl">{["😅", "🙂", "😎", "🏆"][stars]}</div>
          <div className="text-4xl mt-3">{[0, 1, 2].map((s) => <span key={s} style={{ opacity: s < stars ? 1 : 0.25 }}>⭐</span>)}</div>
          <h1 className="text-5xl font-black title-grad mt-3">{fa(score)} / {fa(qs.length)}</h1>
          <p className="mt-3 font-bold text-[var(--muted)]">{score >= 9 ? "فوق‌العاده! تو یک مخترع‌شناس واقعی هستی." : score >= 6 ? "عالی! کمی دیگر و می‌شوی استاد." : "ایرادی ندارد؛ با فلش‌کارت مرور کن و دوباره امتحان کن."}</p>
          <div className="flex gap-3 mt-8 justify-center">
            <button className="btn3d ghost" onClick={() => setMode(null)}>حالت‌ها</button>
            <button className="btn3d" onClick={() => start(mode)}>دوباره 🔁</button>
          </div>
        </div>
      </div>
    );
  }

  const q = qs[i];
  if (!q) return null;
  const answered = picked !== null;

  const choose = (o: string) => {
    if (answered) return;
    setPicked(o);
    if (o === q.answer) { setScore((s) => s + 1); setStreak((s) => s + 1); } else setStreak(0);
  };
  const next = () => {
    if (i + 1 >= qs.length) {
      addQuiz(mode, score, qs.length);
      setFinished(true);
    } else { setI(i + 1); setPicked(null); }
  };

  return (
    <div className="max-w-md mx-auto px-4 pb-8 safe-t">
      <div className="flex items-center gap-3 pt-5">
        <button onClick={() => setMode(null)} className="h-12 w-12 rounded-2xl card3d text-xl font-black" aria-label="خروج">✕</button>
        <div className="flex-1">
          <div className="h-3 rounded-full bg-[var(--soft)] overflow-hidden"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${((i + (answered ? 1 : 0)) / qs.length) * 100}%`, background: "linear-gradient(90deg,var(--green),var(--yellow))" }} /></div>
          <div className="flex justify-between text-xs font-black text-[var(--muted)] mt-1"><span>سؤال {fa(i + 1)} از {fa(qs.length)}</span><span>امتیاز {fa(score)} {streak >= 3 && `🔥${fa(streak)}`}</span></div>
        </div>
      </div>

      <div key={i} className="card3d p-6 mt-5 text-center pop-in">
        <div className="text-7xl floaty">{q.inv.emoji}</div>
        <h2 className="text-xl font-black mt-3 leading-9">{q.text}</h2>
      </div>

      <div className="flex flex-col gap-3 mt-5">
        {q.options.map((o) => {
          const right = answered && o === q.answer;
          const wrong = answered && o === picked && o !== q.answer;
          const c = right ? "var(--green)" : wrong ? "var(--red)" : "";
          return (
            <button
              key={o}
              onClick={() => choose(o)}
              disabled={answered && !right && !wrong}
              className={`card3d press min-h-14 p-4 font-black text-start flex items-center justify-between gap-2 ${wrong ? "shake" : ""}`}
              style={c ? ({ background: `linear-gradient(145deg, color-mix(in srgb, ${c} 80%, #000), ${c})`, color: "#fff", borderColor: c, opacity: 1 } as CSSProperties) : answered ? { opacity: 0.55 } : undefined}
            >
              <span>{o}</span>
              <span aria-hidden>{right ? "✅" : wrong ? "❌" : ""}</span>
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="mt-5 pop-in">
          <div className="card3d p-4 text-sm leading-7">
            <b>{picked === q.answer ? "🎉 درست!" : `پاسخ درست: ${q.answer}`}</b>
            <p className="mt-1 text-[var(--muted)]">{q.inv.intro}</p>
          </div>
          <button className="btn3d w-full mt-4" onClick={next}>{i + 1 >= qs.length ? "پایان و نتیجه" : "سؤال بعدی ←"}</button>
        </div>
      )}
    </div>
  );
}
