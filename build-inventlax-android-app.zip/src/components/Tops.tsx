import { useState } from "react";
import { BY_ID, TOPS } from "../data";
import { CAT_MAP, fa, flagOf, fmtYear } from "../data/meta";
import { Tilt, useBackClose } from "./ui";

export function Tops({ onOpen }: { onOpen: (id: string, list: string[]) => void }) {
  const [sel, setSel] = useState<string | null>(null);
  useBackClose(sel !== null, () => setSel(null));
  const cur = TOPS.find((t) => t.key === sel);

  if (cur) {
    const ids = cur.items.map(([id]) => id);
    return (
      <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
        <div className="relative overflow-hidden rounded-b-[2rem] -mx-4 px-6 pt-6 pb-8 text-white" style={{ background: `linear-gradient(150deg, ${cur.from}, ${cur.to})` }}>
          <button onClick={() => setSel(null)} className="h-12 w-12 rounded-2xl bg-black/25 text-xl font-black" aria-label="بازگشت">→</button>
          <div className="text-center mt-2">
            <div className="text-7xl floaty" style={{ filter: "drop-shadow(0 14px 10px rgba(0,0,0,.4))" }}>{cur.emoji}</div>
            <h1 className="text-2xl font-black mt-2">{cur.title}</h1>
            <div className="en font-bold opacity-80" dir="ltr">{cur.en}</div>
            <p className="mt-2 text-sm font-semibold opacity-95">{cur.blurb}</p>
          </div>
        </div>
        <ol className="mt-5 flex flex-col gap-3">
          {cur.items.map(([id, why], i) => {
            const inv = BY_ID[id];
            const c = CAT_MAP[inv.cat];
            return (
              <li key={id + i}>
                <button onClick={() => onOpen(id, ids)} className="card3d press w-full text-start p-3 flex items-center gap-3 pop-in" style={{ animationDelay: `${i * 50}ms` }}>
                  <span className="h-12 w-12 shrink-0 rounded-2xl grid place-items-center font-black text-xl text-white" style={{ background: `linear-gradient(145deg, ${cur.from}, ${cur.to})`, boxShadow: "0 5px 0 -1px rgba(0,0,0,.35)" }}>{fa(i + 1)}</span>
                  <span className="text-4xl shrink-0">{inv.emoji}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-black leading-tight">{inv.fa} <span className="en text-xs font-bold text-[var(--muted)]" dir="ltr">{inv.en}</span></span>
                    <span className="block text-sm mt-0.5" style={{ color: c.color }}>💬 {why}</span>
                    <span className="block text-[11px] text-[var(--muted)] font-bold">{fmtYear(inv.year, inv.approx)} · {flagOf(inv.country)} {inv.country}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
        <p className="text-xs text-[var(--muted)] mt-5 leading-6">این فهرست بر پایهٔ معیارهای تاریخی و اثر اجتماعی مستند، با هدف آموزش تنظیم شده و جنبهٔ بی‌طرفانه دارد؛ نظر شخصی قطعی نیست.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 pb-8 safe-t">
      <div className="pt-6 pb-4">
        <h1 className="text-3xl font-black">🏆 <span className="title-grad">ترین‌ها</span></h1>
        <p className="text-[var(--muted)] font-semibold mt-1">فهرست‌های ویژه با توضیح کوتاه برای هر انتخاب؛ روی هر کدام بزنید.</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {TOPS.map((t, i) => (
          <Tilt key={t.key}>
            <button onClick={() => setSel(t.key)} className="press card3d w-full overflow-hidden text-start text-white pop-in h-full" style={{ background: `linear-gradient(150deg, ${t.from}, ${t.to})`, animationDelay: `${i * 50}ms`, border: "1px solid rgba(255,255,255,.2)" }}>
              <div className="p-4 min-h-[170px] flex flex-col">
                <div className="text-5xl floaty" style={{ filter: "drop-shadow(0 10px 8px rgba(0,0,0,.4))", animationDelay: `${i * 200}ms` }}>{t.emoji}</div>
                <div className="mt-auto pt-3">
                  <div className="font-black text-lg leading-tight">{t.title}</div>
                  <div className="en text-[11px] opacity-80 font-bold" dir="ltr">{t.en}</div>
                  <div className="text-xs mt-1 font-bold opacity-90">{fa(t.items.length)} مورد</div>
                </div>
              </div>
            </button>
          </Tilt>
        ))}
      </div>
    </div>
  );
}
