export type CatKey =
  | "transport"
  | "medicine"
  | "comm"
  | "energy"
  | "computing"
  | "agri"
  | "military"
  | "daily"
  | "science"
  | "industry"
  | "space"
  | "game";

export interface Inventor {
  fa: string;
  en: string;
  born?: string | null;
  country: string;
  bio: string;
  /** Only when reliably documented from multiple reputable sources; otherwise null. */
  religion?: string | null;
}

export interface Invention {
  id: string;
  fa: string;
  en: string;
  year: number; // negative = BCE
  approx: boolean;
  cat: CatKey;
  country: string; // country / region of invention (or registration)
  inventors: Inventor[];
  intro: string;
  uses: string;
  impact: string;
  emoji: string;
  tags: string[];
}

// [fa, en, born, country, bio, religion?]
export type RawInventor = [string, string, string | null, string, string, string?];

// [id, fa, en, year, approx(0|1), cat, country, inventors, intro, uses, impact, emoji, tags]
export type Raw = [
  string,
  string,
  string,
  number,
  0 | 1,
  CatKey,
  string,
  RawInventor[],
  string,
  string,
  string,
  string,
  string[],
];

export function hydrate(r: Raw): Invention {
  return {
    id: r[0],
    fa: r[1],
    en: r[2],
    year: r[3],
    approx: r[4] === 1,
    cat: r[5],
    country: r[6],
    inventors: r[7].map((i) => ({
      fa: i[0],
      en: i[1],
      born: i[2],
      country: i[3],
      bio: i[4],
      religion: i[5] ?? null,
    })),
    intro: r[8],
    uses: r[9],
    impact: r[10],
    emoji: r[11],
    tags: r[12],
  };
}
