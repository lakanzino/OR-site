import { A } from "./inventionsA";
import { B } from "./inventionsB";
import { C } from "./inventionsC";
import { hydrate, type Invention } from "./types";

export const INVENTIONS: Invention[] = [...A, ...B, ...C].map(hydrate).sort((a, b) => a.year - b.year);

export const BY_ID: Record<string, Invention> = Object.fromEntries(INVENTIONS.map((i) => [i.id, i]));

export const COUNTRIES: { name: string; count: number }[] = (() => {
  const m = new Map<string, number>();
  for (const i of INVENTIONS) {
    const set = new Set<string>([i.country, ...i.inventors.map((v) => v.country)]);
    set.forEach((c) => m.set(c, (m.get(c) ?? 0) + 1));
  }
  return [...m.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
})();

export const INVENTORS: { key: string; fa: string; en: string; count: number }[] = (() => {
  const m = new Map<string, { key: string; fa: string; en: string; count: number }>();
  for (const i of INVENTIONS)
    for (const v of i.inventors) {
      const e = m.get(v.en) ?? { key: v.en, fa: v.fa, en: v.en, count: 0 };
      e.count++;
      m.set(v.en, e);
    }
  return [...m.values()].sort((a, b) => a.en.localeCompare(b.en));
})();

export const TAGS: { name: string; count: number }[] = (() => {
  const m = new Map<string, number>();
  for (const i of INVENTIONS) for (const t of i.tags) m.set(t, (m.get(t) ?? 0) + 1);
  return [...m.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
})();

export type { Invention } from "./types";
export { TOPS } from "./tops";
