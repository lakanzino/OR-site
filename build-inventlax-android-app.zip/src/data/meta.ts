import type { CatKey } from "./types";

export interface CatMeta {
  key: CatKey;
  fa: string;
  en: string;
  emoji: string;
  color: string;
}

export const CATS: CatMeta[] = [
  { key: "transport", fa: "حمل‌ونقل", en: "Transport", emoji: "🚆", color: "#f43f5e" },
  { key: "medicine", fa: "پزشکی", en: "Medicine", emoji: "💉", color: "#ef4444" },
  { key: "comm", fa: "ارتباطات", en: "Communication", emoji: "📡", color: "#5c7cfa" },
  { key: "energy", fa: "انرژی", en: "Energy", emoji: "⚡", color: "#84cc16" },
  { key: "computing", fa: "محاسبات و فناوری", en: "Computing", emoji: "💻", color: "#3b5bdb" },
  { key: "agri", fa: "کشاورزی و غذا", en: "Agriculture", emoji: "🌾", color: "#22c55e" },
  { key: "military", fa: "نظامی", en: "Military", emoji: "🛡️", color: "#b91c1c" },
  { key: "daily", fa: "زندگی روزمره", en: "Daily life", emoji: "🏠", color: "#f5b400" },
  { key: "science", fa: "علم و ابزار", en: "Science & tools", emoji: "🔬", color: "#10b981" },
  { key: "industry", fa: "صنعت و ساخت", en: "Industry", emoji: "🏭", color: "#f59e0b" },
  { key: "space", fa: "فضا و هوا", en: "Air & space", emoji: "🚀", color: "#364fc7" },
  { key: "game", fa: "سرگرمی و فرهنگ", en: "Fun & culture", emoji: "🎲", color: "#eab308" },
];

export const CAT_MAP: Record<string, CatMeta> = Object.fromEntries(CATS.map((c) => [c.key, c]));

export const COUNTRY_META: Record<string, { en: string; flag: string }> = {
  ایران: { en: "Iran", flag: "🇮🇷" },
  چین: { en: "China", flag: "🇨🇳" },
  هند: { en: "India", flag: "🇮🇳" },
  یونان: { en: "Greece", flag: "🇬🇷" },
  مصر: { en: "Egypt", flag: "🇪🇬" },
  ایتالیا: { en: "Italy", flag: "🇮🇹" },
  آلمان: { en: "Germany", flag: "🇩🇪" },
  فرانسه: { en: "France", flag: "🇫🇷" },
  بریتانیا: { en: "United Kingdom", flag: "🇬🇧" },
  آمریکا: { en: "United States", flag: "🇺🇸" },
  ژاپن: { en: "Japan", flag: "🇯🇵" },
  "روسیه/شوروی": { en: "Russia / USSR", flag: "🇷🇺" },
  اتریش: { en: "Austria", flag: "🇦🇹" },
  سوئد: { en: "Sweden", flag: "🇸🇪" },
  هلند: { en: "Netherlands", flag: "🇳🇱" },
  سوئیس: { en: "Switzerland", flag: "🇨🇭" },
  کانادا: { en: "Canada", flag: "🇨🇦" },
  دانمارک: { en: "Denmark", flag: "🇩🇰" },
  لهستان: { en: "Poland", flag: "🇵🇱" },
  مجارستان: { en: "Hungary", flag: "🇭🇺" },
  بلژیک: { en: "Belgium", flag: "🇧🇪" },
  استرالیا: { en: "Australia", flag: "🇦🇺" },
  ترکیه: { en: "Türkiye (Lydia)", flag: "🇹🇷" },
  "بین‌النهرین": { en: "Mesopotamia", flag: "🏺" },
  "جهان اسلام": { en: "Islamic world", flag: "🕌" },
  آفریقا: { en: "Africa", flag: "🌍" },
  "هلال حاصلخیز": { en: "Fertile Crescent", flag: "🌾" },
  "چک/اتریش": { en: "Czech lands", flag: "🇨🇿" },
  نامشخص: { en: "Unknown / many", flag: "🌐" },
};

export const flagOf = (c: string) => COUNTRY_META[c]?.flag ?? "🌐";
export const countryEn = (c: string) => COUNTRY_META[c]?.en ?? c;

export interface Era {
  key: string;
  fa: string;
  en: string;
  from: number;
  to: number;
  emoji: string;
}

export const ERAS: Era[] = [
  { key: "pre", fa: "پیش‌ازتاریخ", en: "Prehistory", from: -Infinity, to: -3500, emoji: "🦴" },
  { key: "ancient", fa: "جهان باستان", en: "Ancient world", from: -3500, to: 500, emoji: "🏛️" },
  { key: "medieval", fa: "قرون وسطا و عصر زرین اسلام", en: "Middle Ages", from: 500, to: 1500, emoji: "🏰" },
  { key: "renaissance", fa: "رنسانس و روشنگری", en: "Renaissance", from: 1500, to: 1760, emoji: "🎨" },
  { key: "industrial", fa: "انقلاب صنعتی", en: "Industrial Revolution", from: 1760, to: 1870, emoji: "🏭" },
  { key: "electric", fa: "عصر برق و ماشین", en: "Electric age", from: 1870, to: 1945, emoji: "💡" },
  { key: "atomic", fa: "عصر اتم، فضا و رایانه", en: "Atomic & space age", from: 1945, to: 1990, emoji: "🛰️" },
  { key: "digital", fa: "عصر دیجیتال", en: "Digital age", from: 1990, to: Infinity, emoji: "🤖" },
];

export const eraOf = (y: number) => ERAS.find((e) => y >= e.from && y < e.to) ?? ERAS[ERAS.length - 1];

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
export const fa = (n: number | string) => String(n).replace(/\d/g, (d) => FA_DIGITS[+d]);

export function fmtYear(y: number, approx: boolean): string {
  const pre = approx ? "حدود " : "";
  if (y <= -10000) {
    const ago = y * -1 + 2025;
    if (ago >= 1_000_000) {
      const m = Math.round(ago / 100_000) / 10;
      return `${pre}${fa(m).replace(".", "٫")} میلیون سال پیش`;
    }
    return `${pre}${fa(Math.round(ago / 1000))} هزار سال پیش`;
  }
  if (y < 0) return `${pre}${fa(-y)} پیش از میلاد`;
  return `${pre}${fa(y)} میلادی`;
}

export function fmtYearShort(y: number): string {
  if (y <= -10000) {
    const ago = y * -1 + 2025;
    return ago >= 1_000_000 ? `${fa((ago / 1_000_000).toFixed(1).replace(".0", ""))}M پ` : `${fa(Math.round(ago / 1000))}K پ`;
  }
  if (y < 0) return `${fa(-y)} پ.م`;
  return fa(y);
}
