import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { EMPTY_FILTERS, type Filters } from "./filter";

const K = "inventlax.v1";

export interface Settings {
  theme: "dark" | "light";
  fontScale: 0 | 1 | 2;
  pin: string | null; // simple local app-lock (hashed)
  onboarded: boolean;
}
export interface QuizStats {
  best: Record<string, number>;
  played: number;
  correct: number;
  total: number;
}
export interface Persisted {
  settings: Settings;
  fav: string[];
  learned: string[];
  quiz: QuizStats;
  filters: Filters;
  view: "grid" | "list" | "timeline";
}

const DEFAULTS: Persisted = {
  settings: { theme: "dark", fontScale: 0, pin: null, onboarded: false },
  fav: [],
  learned: [],
  quiz: { best: {}, played: 0, correct: 0, total: 0 },
  filters: EMPTY_FILTERS,
  view: "grid",
};

function load(): Persisted {
  try {
    const raw = localStorage.getItem(K);
    if (!raw) return DEFAULTS;
    const p = JSON.parse(raw);
    return {
      ...DEFAULTS,
      ...p,
      settings: { ...DEFAULTS.settings, ...p.settings },
      quiz: { ...DEFAULTS.quiz, ...p.quiz },
      filters: { ...EMPTY_FILTERS, ...p.filters },
    };
  } catch {
    return DEFAULTS;
  }
}

export function hashPin(p: string) {
  let h = 5381;
  for (let i = 0; i < p.length; i++) h = ((h << 5) + h + p.charCodeAt(i)) | 0;
  return "h" + (h >>> 0).toString(36) + p.length;
}

interface Ctx {
  data: Persisted;
  fav: Set<string>;
  learned: Set<string>;
  setSettings: (s: Partial<Settings>) => void;
  toggleFav: (id: string) => void;
  toggleLearned: (id: string) => void;
  setFilters: (f: Filters | ((p: Filters) => Filters)) => void;
  setView: (v: Persisted["view"]) => void;
  addQuiz: (mode: string, score: number, total: number) => void;
  exportJson: () => string;
  importJson: (txt: string) => boolean;
  clearAll: () => void;
  toast: (m: string) => void;
}

const C = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(C);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Persisted>(load);
  const [msg, setMsg] = useState<string | null>(null);
  const timer = useRef<number>(0);

  // persist (debounced) — safe against process death
  useEffect(() => {
    const t = window.setTimeout(() => {
      try { localStorage.setItem(K, JSON.stringify(data)); } catch { /* storage full/blocked */ }
    }, 150);
    return () => clearTimeout(t);
  }, [data]);

  useEffect(() => {
    const flush = () => { try { localStorage.setItem(K, JSON.stringify(data)); } catch { /* noop */ } };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", flush);
    return () => { window.removeEventListener("pagehide", flush); document.removeEventListener("visibilitychange", flush); };
  }, [data]);

  useEffect(() => {
    const h = document.documentElement;
    h.dataset.theme = data.settings.theme;
    h.style.setProperty("--fs", ["100%", "112%", "125%"][data.settings.fontScale]);
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", data.settings.theme === "dark" ? "#07102b" : "#eef2ff");
  }, [data.settings.theme, data.settings.fontScale]);

  const fav = useMemo(() => new Set(data.fav), [data.fav]);
  const learned = useMemo(() => new Set(data.learned), [data.learned]);

  const toast = useCallback((m: string) => {
    setMsg(m);
    clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setMsg(null), 2200);
  }, []);

  const toggle = (key: "fav" | "learned") => (id: string) =>
    setData((d) => ({ ...d, [key]: d[key].includes(id) ? d[key].filter((x) => x !== id) : [...d[key], id] }));

  const value: Ctx = {
    data,
    fav,
    learned,
    setSettings: (s) => setData((d) => ({ ...d, settings: { ...d.settings, ...s } })),
    toggleFav: toggle("fav"),
    toggleLearned: toggle("learned"),
    setFilters: (f) => setData((d) => ({ ...d, filters: typeof f === "function" ? f(d.filters) : f })),
    setView: (view) => setData((d) => ({ ...d, view })),
    addQuiz: (mode, score, total) =>
      setData((d) => ({
        ...d,
        quiz: {
          best: { ...d.quiz.best, [mode]: Math.max(d.quiz.best[mode] ?? 0, score) },
          played: d.quiz.played + 1,
          correct: d.quiz.correct + score,
          total: d.quiz.total + total,
        },
      })),
    exportJson: () =>
      JSON.stringify({ app: "Invent.Lax", version: "1.0.0", exportedAt: new Date().toISOString(), fav: data.fav, learned: data.learned, quiz: data.quiz }, null, 2),
    importJson: (txt) => {
      try {
        const j = JSON.parse(txt);
        if (j?.app !== "Invent.Lax" || !Array.isArray(j.fav) || !Array.isArray(j.learned)) return false;
        setData((d) => ({
          ...d,
          fav: j.fav.filter((x: unknown) => typeof x === "string"),
          learned: j.learned.filter((x: unknown) => typeof x === "string"),
          quiz: { ...DEFAULTS.quiz, ...(j.quiz ?? {}) },
        }));
        return true;
      } catch {
        return false;
      }
    },
    clearAll: () => {
      try { localStorage.removeItem(K); } catch { /* noop */ }
      setData({ ...DEFAULTS, settings: { ...DEFAULTS.settings, theme: data.settings.theme, onboarded: true } });
    },
    toast,
  };

  return (
    <C.Provider value={value}>
      {children}
      {msg && (
        <div role="status" className="fixed bottom-24 inset-x-0 z-[90] flex justify-center px-4 pointer-events-none">
          <div className="pop-in glass rounded-2xl px-5 py-3 font-bold text-sm shadow-2xl">{msg}</div>
        </div>
      )}
    </C.Provider>
  );
}
