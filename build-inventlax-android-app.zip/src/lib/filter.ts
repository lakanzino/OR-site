import { ERAS } from "../data/meta";
import type { Invention } from "../data/types";

export type CountryMode = "both" | "invention" | "inventor";

export interface Filters {
  q: string;
  countryOn: boolean;
  countries: string[];
  countryMode: CountryMode;
  eraOn: boolean;
  eras: string[];
  yearFrom: string;
  yearTo: string;
  catOn: boolean;
  cats: string[];
  inventorOn: boolean;
  inventors: string[];
  tagOn: boolean;
  tags: string[];
  favOnly: boolean;
  unlearnedOnly: boolean;
}

export const EMPTY_FILTERS: Filters = {
  q: "",
  countryOn: true,
  countries: [],
  countryMode: "both",
  eraOn: true,
  eras: [],
  yearFrom: "",
  yearTo: "",
  catOn: true,
  cats: [],
  inventorOn: true,
  inventors: [],
  tagOn: true,
  tags: [],
  favOnly: false,
  unlearnedOnly: false,
};

const FA2EN: Record<string, string> = { "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9", "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9" };

export const norm = (s: string) =>
  s
    .replace(/[۰-۹٠-٩]/g, (d) => FA2EN[d])
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[\u200c\u200d\u064b-\u065f]/g, "")
    .toLowerCase()
    .trim();

const hayCache = new Map<string, string>();
function hay(i: Invention): string {
  let h = hayCache.get(i.id);
  if (!h) {
    h = norm(
      [i.fa, i.en, i.country, i.intro, i.uses, i.tags.join(" "), String(i.year), ...i.inventors.map((v) => `${v.fa} ${v.en} ${v.born ?? ""} ${v.country}`)].join(" | ")
    );
    hayCache.set(i.id, h);
  }
  return h;
}

export function numOrNull(s: string): number | null {
  const t = norm(s);
  if (!t) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function activeDims(f: Filters): string[] {
  const out: string[] = [];
  if (f.countryOn && f.countries.length) out.push("country");
  if (f.eraOn && (f.eras.length || numOrNull(f.yearFrom) !== null || numOrNull(f.yearTo) !== null)) out.push("era");
  if (f.catOn && f.cats.length) out.push("cat");
  if (f.inventorOn && f.inventors.length) out.push("inventor");
  if (f.tagOn && f.tags.length) out.push("tag");
  if (f.favOnly) out.push("fav");
  if (f.unlearnedOnly) out.push("unlearned");
  return out;
}

export function applyFilters(list: Invention[], f: Filters, fav: Set<string>, learned: Set<string>): Invention[] {
  const q = norm(f.q);
  const words = q ? q.split(/\s+/) : [];
  const from = numOrNull(f.yearFrom);
  const to = numOrNull(f.yearTo);
  const eraSel = ERAS.filter((e) => f.eras.includes(e.key));
  const useCountry = f.countryOn && f.countries.length > 0;
  const useEra = f.eraOn && (eraSel.length > 0 || from !== null || to !== null);
  const useCat = f.catOn && f.cats.length > 0;
  const useInv = f.inventorOn && f.inventors.length > 0;
  const useTag = f.tagOn && f.tags.length > 0;

  return list.filter((i) => {
    if (words.length) {
      const h = hay(i);
      for (const w of words) if (!h.includes(w)) return false;
    }
    if (useCountry) {
      const byInv = f.countryMode !== "inventor" && f.countries.includes(i.country);
      const byPerson = f.countryMode !== "invention" && i.inventors.some((v) => f.countries.includes(v.country));
      if (!byInv && !byPerson) return false;
    }
    if (useEra) {
      if (eraSel.length && !eraSel.some((e) => i.year >= e.from && i.year < e.to)) return false;
      if (from !== null && i.year < from) return false;
      if (to !== null && i.year > to) return false;
    }
    if (useCat && !f.cats.includes(i.cat)) return false;
    if (useInv && !i.inventors.some((v) => f.inventors.includes(v.en))) return false;
    if (useTag && !f.tags.some((t) => i.tags.includes(t))) return false;
    if (f.favOnly && !fav.has(i.id)) return false;
    if (f.unlearnedOnly && learned.has(i.id)) return false;
    return true;
  });
}
