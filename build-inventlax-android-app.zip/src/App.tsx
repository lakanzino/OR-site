import { useCallback, useEffect, useState } from "react";
import { Detail } from "./components/Detail";
import { Flashcards } from "./components/Flashcards";
import { LockScreen, Onboarding } from "./components/Gate";
import { Home } from "./components/Home";
import { Learn } from "./components/Learn";
import { Quiz } from "./components/Quiz";
import { Saved } from "./components/Saved";
import { Settings } from "./components/Settings";
import { Tops } from "./components/Tops";
import { useBackClose } from "./components/ui";
import { EMPTY_FILTERS } from "./lib/filter";
import { StoreProvider, useApp } from "./lib/store";

type Tab = "home" | "tops" | "learn" | "saved" | "settings";
type LearnMode = "hub" | "flash" | "quiz";

const NAV: [Tab, string, string][] = [
  ["home", "🏠", "خانه"],
  ["tops", "🏆", "ترین‌ها"],
  ["learn", "🎓", "یادگیری"],
  ["saved", "⭐", "من"],
  ["settings", "⚙️", "تنظیمات"],
];

function Shell() {
  const { data, setFilters, setView } = useApp();
  const [tab, setTab] = useState<Tab>("home");
  const [mode, setMode] = useState<LearnMode>("hub");
  const [detail, setDetail] = useState<{ id: string; list: string[] } | null>(null);
  const [locked, setLocked] = useState(() => !!data.settings.pin);

  useBackClose(tab === "learn" && mode !== "hub", () => setMode("hub"));

  useEffect(() => { window.scrollTo({ top: 0 }); }, [tab, mode]);

  const open = useCallback((id: string, list: string[]) => setDetail({ id, list }), []);

  const pick = (p: { country?: string; inventor?: string; cat?: string }) => {
    setFilters({ ...EMPTY_FILTERS, countries: p.country ? [p.country] : [], inventors: p.inventor ? [p.inventor] : [], cats: p.cat ? [p.cat] : [] });
    setView("grid");
    setDetail(null);
    setTab("home");
  };

  const learnTo = (m: "flash" | "quiz") => { setTab("learn"); setMode(m); };

  if (!data.settings.onboarded) return <Onboarding />;
  if (locked && data.settings.pin) return <LockScreen onUnlock={() => setLocked(false)} />;

  return (
    <div className="min-h-dvh pb-28">
      <main>
        {tab === "home" && <Home onOpen={open} go={(t) => setTab(t)} learn={learnTo} />}
        {tab === "tops" && <Tops onOpen={open} />}
        {tab === "learn" && (mode === "hub" ? <Learn setMode={setMode} /> : mode === "flash" ? <Flashcards onExit={() => setMode("hub")} /> : <Quiz onExit={() => setMode("hub")} />)}
        {tab === "saved" && <Saved onOpen={open} />}
        {tab === "settings" && <Settings onLock={() => setLocked(true)} />}
      </main>

      <nav className="fixed bottom-0 inset-x-0 z-50 flex justify-center px-3 pb-2 safe-b pointer-events-none" aria-label="ناوبری اصلی">
        <div className="glass pointer-events-auto w-full max-w-lg rounded-[1.6rem] grid grid-cols-5 p-1.5 shadow-[0_18px_40px_-12px_rgba(0,0,0,.7)]">
          {NAV.map(([k, e, l]) => {
            const on = tab === k;
            return (
              <button
                key={k}
                onClick={() => { if (k === tab && k === "learn") setMode("hub"); setTab(k); }}
                aria-current={on ? "page" : undefined}
                className={`relative min-h-14 rounded-2xl flex flex-col items-center justify-center transition-all duration-300 ${on ? "-translate-y-1.5" : ""}`}
                style={on ? { background: "linear-gradient(180deg, var(--green), color-mix(in srgb, var(--green) 70%, #000))", color: "var(--on-accent)", boxShadow: "0 8px 0 -3px color-mix(in srgb, var(--green) 45%, #000), 0 14px 20px -8px var(--green)" } : undefined}
              >
                <span className={`text-2xl leading-none transition-transform ${on ? "scale-110" : ""}`}>{e}</span>
                <span className="text-[11px] font-black mt-0.5">{l}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <Detail id={detail?.id ?? null} list={detail?.list ?? []} onClose={() => setDetail(null)} onNavigate={(id) => setDetail((d) => (d ? { ...d, id } : d))} onPick={pick} />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
