# Invent.Lax — اختراعات بشر / Human Inventions

> **هدف:** این اپلیکیشن جهت آموزش و سرگرمی نسل جوان و نوجوانان ایران عزیز ساخته شده است.
> *Purpose: built for the education and entertainment of the young generation of Iran.*

**طراحی و توسعه / Designer & Developer:** محمدرضا لک (mohamadreza.lak)
**Version:** 1.0.0 · **License:** MIT · © 2025–2026 mohamadreza.lak

---

## ⚠️ وضعیت این تحویل / What this delivery is (please read)

این مخزن، نسخهٔ **وب آفلاین (React + Vite + Tailwind CSS)** از Invent.Lax است؛ یک فایل `dist/index.html` کاملاً مستقل
(فونت وزیرمتن، داده‌ها و تصاویر داخل خود فایل) که بدون اینترنت اجرا می‌شود و می‌توان آن را به APK/AAB تبدیل کرد.

**پروژهٔ بومی Kotlin + Jetpack Compose + Room در این مخزن وجود ندارد.** محیطی که این پروژه در آن ساخته شد فقط
امکان ساخت و اجرای پروژهٔ وب را داشت و Gradle/Android SDK در آن نبود؛ بنابراین هیچ کد کاتلینی ننوشته‌ام که نتوانم
کامپایل و آزمایشش کنم. همهٔ قابلیت‌های محصول (فیلتر، ترین‌ها، فلش‌کارت، آزمون، علاقه‌مندی/آموخته، تنظیمات، پشتیبان‌گیری،
قفل برنامه، تم تیره/روشن، RTL کامل) در نسخهٔ وب پیاده شده‌اند و مدل داده (`src/data/types.ts`) برای انتقال به Room آماده است.

This repo is the **offline web build** of Invent.Lax. It does **not** contain a native Kotlin / Compose / Room project
(no Gradle or Android SDK was available to compile one). All features are implemented in the web app; the data model maps
1-to-1 to a Room entity if you later want a native port.

---

## ✨ قابلیت‌ها / Features

- ۱۶۴ اختراع برجسته و مستند، از ابزار سنگی (حدود ۲٫۶ میلیون سال پیش) تا هوش مصنوعی مولد (۲۰۲۲)
- فیلتر چندبعدی لحظه‌ای: **کشور** (کشور اختراع / کشور مخترع / هر دو)، **دوره و بازهٔ سال** (منفی = پیش از میلاد)، **دسته**، **مخترع**، **برچسب**؛ هر بعد کلید روشن/خاموش جدا دارد
- نمایش شبکه‌ای، فهرستی و **خط زمان** + نوار دوره‌ها
- صفحهٔ جزئیات کامل: مخترع (محل تولد، کشور، زندگی‌نامهٔ کوتاه، دین/باور **فقط در صورت مستند بودن**)، کاربرد، تأثیر، قبلی/بعدی، اشتراک
- **ترین‌ها:** ۱۲ فهرست (موثرترین، کاربردی‌ترین، جذاب‌ترین، خطرناک‌ترین، بحث‌برانگیزترین، قدیمی‌ترین‌های هنوز در استفاده، دست‌کم‌گرفته‌شده‌ترین، ریشه‌های ایرانی، نجات‌بخش‌ترین، اتفاقی‌ترین، نوبلی‌ترین، نوین‌ترین) با توضیح کوتاه
- فلش‌کارت ۳بعدی (چرخش) بر اساس دسته/دوره/کشور/علاقه‌مندی
- آزمون ۱۰ سؤالی: مخترع، سال، کشور، حوزه، ترکیبی + رکورد محلی
- علاقه‌مندی و «یاد گرفتم» (ذخیرهٔ محلی)، پشتیبان‌گیری/بازیابی JSON، قفل برنامهٔ اختیاری (رمز عددی)، پاک‌کردن داده‌ها
- تم تیره (سرمه‌ای) و روشن؛ اندازهٔ متن قابل‌تنظیم؛ فونت **Vazirmatn** داخل برنامه؛ RTL کامل؛ اعداد فارسی
- ۱۰۰٪ آفلاین، بدون ردیابی، بدون درخواست مجوز، بدون تبلیغ؛ دکمهٔ «بازگشت» دستگاه لایه‌های باز (جزئیات/فیلتر) را می‌بندد؛ وضعیت فیلترها و نما پس از بستن/ری‌استارت حفظ می‌شود

## 🛠 ساخت و اجرا / Build

```bash
npm install
npm run dev        # توسعه
npm run build      # خروجی: dist/index.html (تک‌فایل، آفلاین)
```

## 📱 تبدیل به APK / AAB (Capacitor)

پیش‌نیاز: Node 20+، JDK 17، Android Studio (Android SDK).

```bash
npm run build
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Invent.Lax" com.inventlax.app --web-dir dist
npx cap add android
npx cap sync android
```

در `android/app/src/main/res/values/strings.xml` مقدار `app_name` را دقیقاً `Invent.Lax` بگذارید. در `AndroidManifest.xml` هیچ
`<uses-permission>` اضافه نکنید (Capacitor به‌صورت پیش‌فرض `INTERNET` اضافه می‌کند؛ برای «بدون مجوز» آن خط را حذف کنید — برنامه آفلاین است).
`minSdkVersion` را در `android/variables.gradle` روی ۲۱ نگه دارید.

### آیکون (app-logo)
`public/app-logo.svg` منبع لوگو است (لامپ + چرخ‌دنده + جرقه با پالت سبز/زرد/قرمز/سرمه‌ای). برای جایگزینی:
در Android Studio → *New → Image Asset* فایل SVG/PNG جدید را انتخاب کنید تا آیکون‌های mipmap و Adaptive Icon ساخته شود. در وب هم
کامپوننت `Logo` در `src/components/ui.tsx` و favicon در `index.html` را تغییر دهید.

### ساخت APK امضاشده

```bash
# ۱) ساخت کلید (فقط یک‌بار؛ فایل و رمز را امن نگه دارید)
keytool -genkeypair -v -keystore inventlax.jks -alias inventlax -keyalg RSA -keysize 2048 -validity 10000

# ۲) ساخت نسخهٔ release
cd android && ./gradlew assembleRelease      # APK  (برای بازار/مایکت)
./gradlew bundleRelease                      # AAB  (برای Google Play)

# ۳) امضا و هم‌ترازسازی APK
zipalign -v -p 4 app/build/outputs/apk/release/app-release-unsigned.apk app-aligned.apk
apksigner sign --ks inventlax.jks --out Invent.Lax-1.0.0.apk app-aligned.apk
apksigner verify Invent.Lax-1.0.0.apk
```

## 🗂 ساختار داده / Data

```
src/data/types.ts         مدل داده (Invention / Inventor) — tuple فشرده + hydrate()
src/data/inventionsA.ts   پیش‌ازتاریخ → قرون وسطا
src/data/inventionsB.ts   رنسانس → عصر برق (۱۴۹۸–۱۸۹۷)
src/data/inventionsC.ts   ۱۹۰۲ → ۲۰۲۲
src/data/tops.ts          فهرست‌های «ترین‌ها» با دلیل
src/data/meta.ts          دسته‌ها، دوره‌ها، پرچم کشورها، قالب سال
```

هر اختراع: `nameFa, nameEn, year (منفی = ق.م), approx, category, country, inventors[{fa,en,born,country,bio,religion?}], intro, uses, impact, emoji, tags`.
برای افزودن اختراع، یک ردیف به یکی از فایل‌ها اضافه کنید؛ فیلترها، خط زمان و آزمون خودکار آن را می‌شناسند.

## 📚 منابع و دقت / Sources & accuracy

داده‌ها با تکیه بر این منابع گردآوری و تطبیق داده شده‌اند:
Wikipedia «Timeline of historic inventions»، Britannica، مجموعه‌دادهٔ GitHub `manjunath5496/Timeline-of-historic-inventions`
و `sharmadhiraj/free-json-datasets`، و سایت جایزهٔ نوبل برای برندگان.

**یادداشت صادقانه:**
- این برنامه **۱۶۴ ورودی** دارد، نه ۴۰۰–۸۰۰. من متن و صحت هر ورودی را دستی بررسی کردم و ترجیح دادم تعداد کمتر ولی دقیق‌تر باشد
  تا اینکه ردیف‌های ناصحیح تولید شود. قالب داده برای افزودن ورودی‌های بیشتر ساخته شده است.
- من در این محیط دسترسی زنده به مخازن GitHub ذکرشده نداشتم؛ داده‌ها از دانش و بازبینی خودم بر پایهٔ همان منابع نوشته شده‌اند، **نه** واردکردن خودکار فایل JSON آن‌ها. پیش از انتشار، نمونه‌برداری از ورودی‌ها با منابع بالا توصیه می‌شود.
- در بسیاری از اختراعات، سال و نسبت‌دادن به یک نفر مورد اختلاف است؛ با «حدود» یا توضیح در متن مشخص شده است.
- **دین/باور** فقط برای چند شخصیتِ دارای مستندات روشن (مثلاً فارادی، پاسکال، ولتا و دانشمندان مسلمان دورهٔ اسلامی) درج شده و در بقیه خالی (`null`) است.

> اطلاعات از منابع معتبر استخراج و بررسی شده‌اند. دین/باور مخترعان تنها در صورت مستند و قابل‌اثبات بودن درج شده و جنبه بی‌طرفانه دارد. مسئولیت استفاده نهایی با کاربر است.

## 🏪 متن معرفی فروشگاه (بازار / مایکت / Google Play)

**عنوان:** Invent.Lax — اختراعات بشر

**توضیح کوتاه (۸۰ نویسه):**
از آتش تا هوش مصنوعی؛ آموزش و سرگرمی با اختراعات بشر، آفلاین و رایگان.

**توضیح کامل:**
Invent.Lax سفری سرگرم‌کننده و آموزشی در تاریخ اختراعات بشر است؛ از ابزار سنگی و کشف آتش تا واکسن، ترانزیستور، اینترنت و هوش مصنوعی.

• ۱۶۴ اختراع مهم با توضیح ساده، مخترع، کشور، کاربرد و تأثیر
• فیلتر قدرتمند بر اساس کشور، سال و دوره، دسته، مخترع و برچسب
• خط زمان زیبا و گرافیک سه‌بعدی
• بخش «ترین‌ها»: موثرترین، کاربردی‌ترین، جذاب‌ترین، خطرناک‌ترین، بحث‌برانگیزترین و…
• ریشه‌های ایرانی: قنات، یخچال، بادگیر، تقویم جلالی، خوارزمی و…
• فلش‌کارت سه‌بعدی و آزمون‌های چندگزینه‌ای با رکورد
• علاقه‌مندی‌ها و پیشرفت یادگیری، تم تیره و روشن، فونت وزیرمتن، راست‌به‌چپ کامل
• ۱۰۰٪ آفلاین، بدون تبلیغ، بدون ردیابی و بدون نیاز به مجوزهای حساس

این اپلیکیشن جهت آموزش و سرگرمی نسل جوان و نوجوانان ایران عزیز ساخته شده است.
طراحی و توسعه: محمدرضا لک (mohamadreza.lak) — متن‌باز با مجوز MIT.

**رده‌بندی محتوا:** آموزشی / همهٔ سنین · **دسته:** آموزش · **حریم خصوصی:** هیچ داده‌ای جمع‌آوری یا ارسال نمی‌شود.

## 📦 ساخت زیپ و آپلود در GitHub (نام مخزن: Invent.Lax)

```bash
# زیپ کل پروژه (بدون node_modules)
zip -r Invent.Lax-1.0.0.zip . -x "node_modules/*" ".git/*"

# یا مستقیم در گیت‌هاب
git init && git add . && git commit -m "Invent.Lax 1.0.0"
git branch -M main
git remote add origin https://github.com/<USERNAME>/Invent.Lax.git
git push -u origin main
```

## 📄 مجوز / License

MIT — Copyright (c) 2025-2026 mohamadreza.lak. متن کامل در فایل [LICENSE](./LICENSE).

## 🧰 کتابخانه‌ها / Libraries
React 19, Vite 7, Tailwind CSS 4, `@fontsource-variable/vazirmatn` (OFL), `vite-plugin-singlefile`. بدون SDK تبلیغاتی/آنالیتیکس.
